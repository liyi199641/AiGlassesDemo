package com.fission.wear.glasses.sdk.live

import android.net.Network
import com.fission.wear.glasses.sdk.manager.WifiApConnectManager
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import kotlinx.coroutines.delay
import java.net.InetSocketAddress

/** 通过 AP [Network.socketFactory] 探测眼镜 RTSP 端口是否就绪。 */
internal object LyLiveNetworkProbe {

    private const val TAG = "LyLiveNetworkProbe"
    private const val RTSP_PORT = 554
    private const val PROBE_CONNECT_TIMEOUT_MS = 2_000

    suspend fun waitForRtspReady(
        host: String,
        timeoutMs: Long = 10_000L,
        pollIntervalMs: Long = 300L,
    ): Boolean {
        val network = WifiApConnectManager.getBoundApNetwork()
        if (network == null) {
            FissionLogUtils.w(TAG, "waitForRtspReady: boundApNetwork 为空")
            return false
        }
        val deadline = System.currentTimeMillis() + timeoutMs
        var attempt = 0
        while (System.currentTimeMillis() < deadline) {
            attempt++
            if (probeTcp(network, host, RTSP_PORT)) {
                FissionLogUtils.i(
                    TAG,
                    "RTSP 端口就绪 host=$host port=$RTSP_PORT attempt=$attempt",
                )
                return true
            }
            delay(pollIntervalMs)
        }
        FissionLogUtils.w(
            TAG,
            "RTSP 端口在 ${timeoutMs}ms 内未就绪 host=$host port=$RTSP_PORT",
        )
        return false
    }

    private fun probeTcp(network: Network, host: String, port: Int): Boolean =
        runCatching {
            network.socketFactory.createSocket().use { socket ->
                socket.soTimeout = PROBE_CONNECT_TIMEOUT_MS
                socket.connect(InetSocketAddress(host, port), PROBE_CONNECT_TIMEOUT_MS)
                true
            }
        }.getOrDefault(false)
}
