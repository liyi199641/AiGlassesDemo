package com.fission.wear.glasses.sdk.manager

import android.annotation.SuppressLint
import android.content.Context
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.util.BlePacketUtils.bytesToHex
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.polidea.rxandroidble3.RxBleConnection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import java.util.concurrent.TimeUnit

/**
 * describe:
 * author: wl
 * createTime: 2025/9/9
 */
object BleManager {
    @Volatile
    var currentDeviceManager: BleDeviceManager? = null

    private const val DISCONNECT_SETTLE_TIMEOUT_SEC = 3L
    private const val POST_DISCONNECT_SETTLE_MS = 800L
    private const val PRE_CONNECT_SETTLE_MS = 400L

    fun connectDevice(
        context: Context, mac: String,
        scope: CoroutineScope,
        eventBus: MutableSharedFlow<GlassesEvent>,
        isOtaMode: Boolean = false
    ) {
        val previousManager = currentDeviceManager
        if (previousManager != null) {
            val previousMac = previousManager.rxBleDevice.macAddress
            previousManager.disconnect()
            currentDeviceManager = null
            awaitBleDisconnected(context, previousMac)
        }

        val newManager = BleDeviceManager(context, mac, scope, eventBus)
        currentDeviceManager = newManager

//        Thread.sleep(PRE_CONNECT_SETTLE_MS)
        newManager.connect(isOtaMode)
    }

    @SuppressLint("CheckResult")
    private fun awaitBleDisconnected(context: Context, macAddress: String) {
        val device = RxBleClientProvider.get(context).getBleDevice(macAddress)
        if (device.connectionState == RxBleConnection.RxBleConnectionState.DISCONNECTED) {
            return
        }
        FissionLogUtils.d("BleManager", "等待上一次 BLE 连接释放: ${macAddress.substring(macAddress.length-5)}")
        try {
            device.observeConnectionStateChanges()
                .filter { it == RxBleConnection.RxBleConnectionState.DISCONNECTED }
                .timeout(DISCONNECT_SETTLE_TIMEOUT_SEC, TimeUnit.SECONDS)
                .blockingFirst()
        } catch (error: Exception) {
            FissionLogUtils.w(
                "BleManager",
                "等待 BLE 断开超时，继续尝试连接: ${error.message}"
            )
        }
        Thread.sleep(POST_DISCONNECT_SETTLE_MS)
    }

    fun sendData(data: ByteArray) {
        val manager = currentDeviceManager
        if (manager == null) {
            FissionLogUtils.w("BleManager", "sendData: 无 BLE 连接，丢弃写入: ${bytesToHex(data)}")
            return
        }
        val queueSizeBefore = manager.pendingWriteQueueSize()
        manager.sendData(data)
        val queueSizeAfter = manager.pendingWriteQueueSize()
        if (queueSizeAfter > 1 || queueSizeBefore > 0) {
            FissionLogUtils.w(
                "BleManager",
                "sendData: 写入队列积压 queueSize=$queueSizeAfter (before=$queueSizeBefore)"
            )
        }
    }

    suspend fun sendDataAndAwait(data: ByteArray, timeoutMs: Long = 3_000L): Boolean {
        val manager = currentDeviceManager
        if (manager == null) {
            FissionLogUtils.w("BleManager", "sendDataAndAwait: 无 BLE 连接，丢弃写入: ${bytesToHex(data)}")
            return false
        }
        return manager.sendDataAndAwait(data, timeoutMs)
    }

    fun sendOtaAuthData(data: ByteArray) {
        currentDeviceManager?.sendOtaAuthData(data)
    }

    fun disconnect() {
        currentDeviceManager?.disconnect()
        currentDeviceManager = null
    }

    fun isOtaMode(): Boolean = currentDeviceManager?.isOtaMode() == true

    fun enterOtaMode() {
        currentDeviceManager?.enterOtaMode()
    }

    fun exitOtaMode() {
        currentDeviceManager?.exitOtaMode()
    }

}
