package com.fission.wear.glasses.sdk.bt

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import androidx.core.app.ActivityCompat
import com.fission.wear.glasses.sdk.config.BtConnectionConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.data.cache.GlassesSpUtil
import com.fission.wear.glasses.sdk.events.BtConnectEvent
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.manager.BleManager
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

object BtManager {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private const val TAG = "BtManager"
    /**
     * STATE_ON ≠ Stack Ready。厂商在 Adapter ON 后仍需恢复 Bond/UUID/Profile 数据库，
     * 固定短延时后立刻 createBond 在三星等机型上极易失败。
     */
    private const val stackReadyMinWaitMs = 2000L
    private const val stackReadyMaxWaitMs = 8000L
    private const val stackReadyPollMs = 400L
    /** 等待经典蓝牙（BR/EDR）设备信息就绪；超时上报上层，不再次数重试 createBond */
    private const val btClassicPrepTimeoutMs = 8000L
    private const val btClassicPrepPollMs = 300L
    private const val btDiscoveryTimeoutMs = 12000L
    /** Classic Ready 等待期内，SDP 主动刷新次数（不是 createBond 重试） */
    private const val classicReadySdpRefreshMax = 3
    /** BLE 连接稳定后再开始 BR/EDR 配对 */
    private const val bleSettleBeforeBondMs = 800L
    private const val maxRetry = 10
    private const val retryInterval = 2000L
    private const val unpairBondTimeoutMs = 12_000L
    private const val unpairBondRetryTimeoutMs = 8_000L
    /** BLE 就绪后等待 BT 栈稳定再连 A2DP/HFP，减轻双模共存冲突 */
    private const val btProfileConnectSettleDelayMs = 1000L
    /** Profile 意外断开后延迟恢复，避免与系统重连抢占 */
    private const val btProfileRecoveryDelayMs = 1500L
    /** 合并短时间内的重复 Profile 连接请求 */
    private const val btProfileConnectDebounceMs = 1500L

    /**
     * 经典蓝牙栈恢复状态机。
     * Adapter OFF → WAIT_ADAPTER_ON → WAIT_STACK_READY → WAIT_BREDR_READY → READY → createBond(一次/代)
     */
    private enum class ClassicStackState {
        OFF,
        WAIT_ADAPTER_ON,
        WAIT_STACK_READY,
        WAIT_BREDR_READY,
        READY,
    }

    private var appContext: Context? = null
    private var events: MutableSharedFlow<GlassesEvent>? = null
    @Volatile
    private var btConnectionConfig: BtConnectionConfig = BtConnectionConfig()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val initialized = AtomicBoolean(false)
    private val receiversRegistered = AtomicBoolean(false)
    /** 防止 release 异步清理覆盖后续 init */
    private val initGeneration = AtomicInteger(0)

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private var a2dpProxy: BluetoothA2dp? = null
    private var hfpProxy: BluetoothHeadset? = null
    private var a2dpListener: BluetoothProfile.ServiceListener? = null
    private var hfpListener: BluetoothProfile.ServiceListener? = null

    private val sppConnections = mutableMapOf<String, BluetoothSocket>()
    private val retryJobs = mutableMapOf<String, Job>()
    private var btDiscoveryJob: Job? = null
    private var btPairJob: Job? = null
    private var sdpRetryJob: Job? = null
    private var unpairJob: Job? = null
    private var profileConnectJob: Job? = null
    private var profileRecoveryJob: Job? = null
    private var stackReadyJob: Job? = null
    @Volatile
    private var lastProfileConnectAtMs = 0L
    @Volatile
    private var classicStackState: ClassicStackState = ClassicStackState.OFF
    /** Adapter 进入 STATE_ON 的时间，用于 Stack Ready 最短等待 */
    @Volatile
    private var adapterOnAtMs = 0L

    /**
     * 恢复代数：STATE_ON / BLE Connected / Classic Ready 信号等事件递增。
     * 每一代最多真正发起一次 createBond（createBond 返回 false 时允许刷新对象再试一次）。
     */
    private val recoveryGeneration = AtomicInteger(0)
    /** 已消费 createBond 的代数；等于当前 generation 则不再自动配对，除非新事件开新一代 */
    @Volatile
    private var bondAttemptedGeneration = -1
    /** 本代 createBond 已失败（BOND_NONE 或启动失败），等待新恢复事件 */
    @Volatile
    private var bondFailedThisGeneration = false

    /**
     * 将 ACTION_UUID / ACTION_FOUND 转为协程可 await 的同步通知，
     * 避免 Receiver 与 createBond 协程各自抢着配对。
     */
    private val classicStackMonitor = ClassicStackMonitor()

    /** 仅在本端主动发起配对流程时为 true，避免断连/重连时 BOND_NONE 误触发系统配对弹窗 */
    @Volatile
    private var isActivePairingRequest = false

    /** 蓝牙关闭时 BLE 仍连着且未完成经典蓝牙配对，需在蓝牙重新开启后恢复配对 */
    @Volatile
    private var pendingBondResume = false

    /** 当前处于蓝牙开关后的恢复配对路径（不再做次数重试，仅作日志/策略标记） */
    @Volatile
    private var bondResumeInProgress = false

    /** 主动解绑进行中，避免解绑过程中 UUID/BOND 广播再次触发配对 */
    @Volatile
    private var isUnpairingInProgress = false

    /** OTA/解绑等场景下暂停 BT 自动配对与 Profile 重连，避免与 OTA 栈抢连 */
    private fun isBtAutoConnectSuspended(): Boolean =
        isUnpairingInProgress || BleManager.isOtaMode()

    /** 串行化配对，避免并发 createBond 导致部分机型 BT 栈异常 */
    private val pairingLock = Any()
    private val profileConnectLock = Any()

    private data class BtLinkState(
        val bondState: Int,
        val a2dpState: Int,
        val hfpState: Int,
    )

    /** BR/EDR 栈事件：UUID 恢复 / Classic 扫描发现 */
    private data class ClassicStackEvent(
        val address: String,
        val type: Int,
        val hasUuids: Boolean,
        val source: String,
    )

    /**
     * 经典蓝牙栈监视器：Receiver 只负责投递事件，配对协程统一 await。
     */
    private class ClassicStackMonitor {
        private val events = MutableSharedFlow<ClassicStackEvent>(
            extraBufferCapacity = 8,
            onBufferOverflow = BufferOverflow.DROP_OLDEST,
        )

        fun notifyUuid(address: String, type: Int, hasUuids: Boolean) {
            events.tryEmit(
                ClassicStackEvent(
                    address = address,
                    type = type,
                    hasUuids = hasUuids,
                    source = "ACTION_UUID",
                )
            )
        }

        fun notifyFound(address: String, type: Int) {
            events.tryEmit(
                ClassicStackEvent(
                    address = address,
                    type = type,
                    hasUuids = false,
                    source = "ACTION_FOUND",
                )
            )
        }

        suspend fun awaitReadySignal(address: String, timeoutMs: Long): ClassicStackEvent? {
            return withTimeoutOrNull(timeoutMs) {
                events.first { event ->
                    event.address.equals(address, ignoreCase = true) &&
                        (event.hasUuids ||
                            event.type == BluetoothDevice.DEVICE_TYPE_DUAL ||
                            event.type == BluetoothDevice.DEVICE_TYPE_CLASSIC ||
                            (event.source == "ACTION_FOUND" &&
                                event.type != BluetoothDevice.DEVICE_TYPE_UNKNOWN))
                }
            }
        }
    }

    fun isInitialized(): Boolean = initialized.get()

    private fun ensureInitialized(caller: String): Boolean {
        if (initialized.get() && appContext != null) return true
        FissionLogUtils.w(TAG, "$caller skipped: BtManager not initialized")
        return false
    }

    /** App 侧已绑定设备，或配对过程中关蓝牙时用于判断是否恢复配对 */
    private fun hasBoundDevice(): Boolean {
        return !GlassesSpUtil.getMacAddress(null).isNullOrBlank()
    }

    private fun clearPendingBondResume(reason: String) {
        synchronized(pairingLock) {
            pendingBondResume = false
            bondResumeInProgress = false
        }
        FissionLogUtils.d(TAG, reason)
    }

    private fun updateClassicStackState(state: ClassicStackState, reason: String = "") {
        if (classicStackState == state) return
        val from = classicStackState
        classicStackState = state
        val suffix = if (reason.isNotEmpty()) " ($reason)" else ""
        FissionLogUtils.d(TAG, "ClassicStackState $from -> $state$suffix")
    }

    /** 新恢复事件开启一代：本代最多 createBond 一次 */
    private fun beginRecoveryGeneration(reason: String): Int {
        val gen = recoveryGeneration.incrementAndGet()
        synchronized(pairingLock) {
            bondAttemptedGeneration = -1
            bondFailedThisGeneration = false
        }
        FissionLogUtils.d(TAG, "recoveryGeneration=$gen reason=$reason")
        return gen
    }

    private fun hasBondAttemptThisGeneration(): Boolean {
        return bondAttemptedGeneration == recoveryGeneration.get()
    }

    private fun markBondAttemptThisGeneration() {
        bondAttemptedGeneration = recoveryGeneration.get()
    }

    private fun markBondFailedThisGeneration() {
        synchronized(pairingLock) {
            bondFailedThisGeneration = true
            isActivePairingRequest = false
            bondResumeInProgress = false
        }
    }

    private suspend fun reportBondTerminalFailure(
        device: BluetoothDevice,
        reason: String,
        message: String = reason,
    ) {
        markBondFailedThisGeneration()
        FissionLogUtils.w(TAG, "BT配对终止 gen=${recoveryGeneration.get()} reason=$reason（等待 STATE_ON/BLE/UUID 等新恢复事件）")
        emitEvent(BtConnectEvent.BondFailed(device, reason))
        emitEvent(
            BtConnectEvent.Failed(device = device, message = message)
        )
    }

    fun init(context: Context, eventBus: MutableSharedFlow<GlassesEvent>, config: BtConnectionConfig) {
        synchronized(this) {
            initGeneration.incrementAndGet()
            appContext = context.applicationContext
            events = eventBus
            btConnectionConfig = config
            if (!receiversRegistered.get()) {
                registerBondReceiver()
                receiversRegistered.set(true)
            }
            initA2dpProxy()
            initHfpProxy()
            initialized.set(true)
        }
    }

    private fun btConfig(): BtConnectionConfig = btConnectionConfig

    private fun isProfileEnabled(profile: GlassesConstant.BtProfileType): Boolean {
        return when (profile) {
            GlassesConstant.BtProfileType.A2DP -> btConfig().connectA2dp
            GlassesConstant.BtProfileType.HFP -> btConfig().connectHfp
            GlassesConstant.BtProfileType.SPP -> btConfig().connectSpp
            else -> false
        }
    }

    private fun areConfiguredProfilesConnected(link: BtLinkState): Boolean {
        val config = btConfig()
        if (config.connectA2dp && link.a2dpState != BluetoothProfile.STATE_CONNECTED) return false
        if (config.connectHfp && link.hfpState != BluetoothProfile.STATE_CONNECTED) return false
        return true
    }

    /** A2DP/HFP 已连接或连接中时不再 createBond，避免系统弹出「BT 已连接，是否再次配对」 */
    private fun hasConnectedOrConnectingClassicProfiles(link: BtLinkState): Boolean {
        val config = btConfig()
        if (!config.hasAnyProfile()) return false
        if (config.connectA2dp) {
            val a2dp = link.a2dpState
            if (a2dp == BluetoothProfile.STATE_CONNECTED || a2dp == BluetoothProfile.STATE_CONNECTING) {
                return true
            }
        }
        if (config.connectHfp) {
            val hfp = link.hfpState
            if (hfp == BluetoothProfile.STATE_CONNECTED || hfp == BluetoothProfile.STATE_CONNECTING) {
                return true
            }
        }
        return false
    }

    @SuppressLint("MissingPermission")
    internal fun areConfiguredProfilesConnected(device: BluetoothDevice): Boolean {
        if (!ensureInitialized("areConfiguredProfilesConnected") || !hasBondPermission()) return false
        return areConfiguredProfilesConnected(queryLinkState(refreshRemoteDevice(device)))
    }

    @SuppressLint("MissingPermission")
    fun removeBondFromPairedDevicesByAddress(context: Context, onComplete: (() -> Unit)? = null) {
        if (!hasBondPermission()) {
            FissionLogUtils.w(TAG, "removeBond skipped: no bond permission")
            onComplete?.invoke()
            return
        }
        val appCtx = context.applicationContext
        val devices = collectDevicesToUnpair(appCtx)
        if (devices.isEmpty()) {
            FissionLogUtils.w(TAG, "removeBond: no bonded device found")
            onComplete?.invoke()
            return
        }
        unpairJob?.cancel()
        unpairJob = scope.launch(Dispatchers.IO) {
            try {
                unpairDevices(devices)
            } finally {
                onComplete?.invoke()
            }
        }
    }

    /** 在后台 BT 解绑任务结束后执行（如 [GlassesManage.release]）。 */
    fun whenUnpairFinished(action: () -> Unit) {
        val job = unpairJob
        if (job == null || job.isCompleted) {
            action()
        } else {
            job.invokeOnCompletion { action() }
        }
    }

    /**
     * 解绑指定设备：先断开 A2DP/HFP/SPP，再 removeBond 并等待系统完成。
     * 部分机型（如 Moto G7 / Android 10）在 Profile 仍连接时无法成功 removeBond。
     */
    @SuppressLint("MissingPermission")
    private suspend fun unpairDevices(devices: List<BluetoothDevice>): Boolean {
        if (!hasBondPermission()) {
            FissionLogUtils.w(TAG, "unpairDevices skipped: no bond permission")
            return false
        }

        synchronized(pairingLock) {
            isUnpairingInProgress = true
            isActivePairingRequest = false
            pendingBondResume = false
            bondResumeInProgress = false
        }
        // 解绑一开始就注销长期 BroadcastReceiver，避免 adapterReceiver 在解绑过程中仍响应开关机
        synchronized(this) {
            unregisterReceiversLocked()
        }
        cancelPendingJobs()
        bluetoothAdapter?.cancelDiscovery()

        try {
            waitForProfileProxy()

            var allRemoved = true
            for (device in devices) {
                val resolved = resolveBondedDevice(device)
                if (resolved.bondState != BluetoothDevice.BOND_BONDED) {
                    FissionLogUtils.d(TAG, "unpairDevices: ${resolved.address} not bonded, skip")
                    continue
                }

                FissionLogUtils.d(TAG, "unpairDevices: disconnect profiles for ${resolved.address}")
                disconnectA2dpInternal(resolved)
                disconnectHfpInternal(resolved)
                disconnectSppInternal(resolved)
                waitForProfilesDisconnected(resolved)
                delay(500)
                BleManager.disconnect()
                delay(800)

                if (!removeBondAndWait(resolved)) {
                    FissionLogUtils.w(TAG, "unpairDevices: bond removal failed for ${resolved.address}")
                    allRemoved = false
                } else {
                    FissionLogUtils.d(TAG, "unpairDevices: bond removed for ${resolved.address}")
                }
            }
            return allRemoved
        } finally {
            synchronized(pairingLock) {
                isUnpairingInProgress = false
            }
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun removeBondAndWait(device: BluetoothDevice): Boolean {
        val address = device.address
        if (!removeBondReflect(resolveBondedDevice(device))) {
            FissionLogUtils.e(TAG, "unpairDevices: removeBond returned false for $address")
            return false
        }
        if (waitForBondRemoved(address)) return true

        FissionLogUtils.d(TAG, "unpairDevices: retry removeBond for $address")
        delay(500)
        val bonded = getBondedDevice(address) ?: return true
        if (!removeBondReflect(bonded)) {
            FissionLogUtils.e(TAG, "unpairDevices: removeBond retry returned false for $address")
            return false
        }
        return waitForBondRemoved(address, unpairBondRetryTimeoutMs)
    }

    @SuppressLint("MissingPermission")
    fun getCurBluetoothDevice(context: Context): BluetoothDevice? {
        if (!hasBondPermission()) {
            return null
        }
        val targetAddress = GlassesSpUtil.getMacAddress(null) ?: return null
        val bluetoothManager: BluetoothManager =
            context.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        return bluetoothManager.adapter?.bondedDevices?.firstOrNull { device ->
            device.address.equals(targetAddress, ignoreCase = true)
        }
    }

    @SuppressLint("MissingPermission")
    private fun collectDevicesToUnpair(context: Context): List<BluetoothDevice> {
        val result = linkedSetOf<BluetoothDevice>()
        val savedMac = GlassesSpUtil.getMacAddress(null)
        val bleMac = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice?.address
            ?: BleManager.currentDeviceManager?.rxBleDevice?.macAddress

        savedMac?.let { mac -> getBondedDevice(mac)?.let { result.add(it) } }
        bleMac?.let { mac -> getBondedDevice(mac)?.let { result.add(it) } }

        BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice?.let { bleDevice ->
            if (bleDevice.bondState == BluetoothDevice.BOND_BONDED) {
                result.add(bleDevice)
            }
        }

        a2dpProxy?.connectedDevices
            ?.filter { isTargetDevice(it) }
            ?.forEach { result.add(resolveBondedDevice(it)) }
        hfpProxy?.connectedDevices
            ?.filter { isTargetDevice(it) }
            ?.forEach { result.add(resolveBondedDevice(it)) }

        val adapter = context.applicationContext
            .getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        adapter.adapter?.bondedDevices?.forEach { device ->
            val matchesSaved = savedMac != null && device.address.equals(savedMac, ignoreCase = true)
            val matchesBle = bleMac != null && device.address.equals(bleMac, ignoreCase = true)
            if (matchesSaved || matchesBle) {
                result.add(device)
            }
        }
        return result.toList()
    }

    @SuppressLint("MissingPermission")
    private suspend fun waitForProfilesDisconnected(device: BluetoothDevice, timeoutMs: Long = 3000L) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val link = queryLinkState(device)
            val a2dpIdle = link.a2dpState == BluetoothProfile.STATE_DISCONNECTED ||
                link.a2dpState == BluetoothProfile.STATE_DISCONNECTING
            val hfpIdle = link.hfpState == BluetoothProfile.STATE_DISCONNECTED ||
                link.hfpState == BluetoothProfile.STATE_DISCONNECTING
            if (a2dpIdle && hfpIdle) return
            delay(150)
        }
        FissionLogUtils.w(TAG, "waitForProfilesDisconnected timeout for ${device.address}")
    }

    @SuppressLint("MissingPermission")
    private suspend fun waitForBondRemoved(address: String, timeoutMs: Long = unpairBondTimeoutMs): Boolean {
        if (getBondedDevice(address) == null) return true
        val ctx = appContext ?: return false

        return try {
            withTimeout(timeoutMs) {
                suspendCancellableCoroutine { cont ->
                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(context: Context?, intent: Intent?) {
                            if (intent?.action != BluetoothDevice.ACTION_BOND_STATE_CHANGED) return
                            val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                                ?: return
                            if (!device.address.equals(address, ignoreCase = true)) return
                            if (intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR) ==
                                BluetoothDevice.BOND_NONE
                            ) {
                                unregisterBondWaiter(ctx, this)
                                if (cont.isActive) cont.resume(getBondedDevice(address) == null)
                            }
                        }
                    }
                    ctx.registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED))
                    cont.invokeOnCancellation { unregisterBondWaiter(ctx, receiver) }
                    if (getBondedDevice(address) == null) {
                        unregisterBondWaiter(ctx, receiver)
                        cont.resume(true)
                    }
                }
            }
        } catch (_: Exception) {
            getBondedDevice(address) == null
        }
    }

    private fun unregisterBondWaiter(context: Context, receiver: BroadcastReceiver) {
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Exception) {
        }
    }

    private val adapterReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            // 解绑/已 release 后不应再响应开关机广播，否则会误触发 Classic Ready / 回连
            if (!initialized.get() || isUnpairingInProgress) return
            if (!hasBondPermission()) return
            if (intent?.action == BluetoothAdapter.ACTION_STATE_CHANGED) {
                when (intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                    BluetoothAdapter.STATE_OFF -> {
                        FissionLogUtils.d(TAG, "蓝牙关闭，清理状态")
                        val device = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice
                        synchronized(pairingLock) {
                            // 配对过程中关蓝牙：即使尚未写入绑定 MAC，也要在开蓝牙后恢复配对
                            pendingBondResume = (hasBoundDevice() || isActivePairingRequest) &&
                                device != null &&
                                isCurrentConnectedDevice(device) &&
                                refreshRemoteDevice(device).bondState != BluetoothDevice.BOND_BONDED
                            isActivePairingRequest = false
                            bondResumeInProgress = false
                            bondAttemptedGeneration = -1
                            bondFailedThisGeneration = false
                        }
                        updateClassicStackState(ClassicStackState.OFF, "adapter_off")
                        stackReadyJob?.cancel()
                        stackReadyJob = null
                        scope.launch {
                            stopClassicDiscovery()
                            btPairJob?.cancel()
                            btPairJob = null
                            sdpRetryJob?.cancel()
                            sdpRetryJob = null
                            btDiscoveryJob?.cancel()
                            btDiscoveryJob = null
                            retryJobs.values.forEach { it.cancel() }
                            retryJobs.clear()
                        }
                    }

                    BluetoothAdapter.STATE_TURNING_ON -> {
                        updateClassicStackState(ClassicStackState.WAIT_ADAPTER_ON, "turning_on")
                    }

                    BluetoothAdapter.STATE_ON -> {
                        FissionLogUtils.d(TAG, "蓝牙重新开启")
                        adapterOnAtMs = System.currentTimeMillis()
                        beginRecoveryGeneration("STATE_ON")
                        updateClassicStackState(ClassicStackState.WAIT_STACK_READY, "adapter_on")
                        stackReadyJob?.cancel()
                        stackReadyJob = scope.launch {
                            if (!ensureInitialized("STATE_ON") || isUnpairingInProgress) return@launch
                            initA2dpProxy()
                            initHfpProxy()
                            // Proxy Ready ≠ Classic Ready：先完成独立 Classic Ready，再决定是否 createBond
                            val resumeMac = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice?.address
                                ?: BleManager.currentDeviceManager?.rxBleDevice?.macAddress
                                ?: GlassesSpUtil.getMacAddress(null)
                            if (pendingBondResume || !resumeMac.isNullOrBlank()) {
                                ensureClassicReadyBeforeBond(resumeMac)
                            } else {
                                awaitBluetoothStackReady()
                            }
                            if (!isBluetoothOn() || isUnpairingInProgress || !initialized.get()) return@launch
                            when {
                                pendingBondResume -> {
                                    synchronized(pairingLock) {
                                        bondResumeInProgress = true
                                        pendingBondResume = false
                                    }
                                    syncConnectionState()
                                    val device = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice
                                    if (device != null && isCurrentConnectedDevice(device) && isBleConnected()) {
                                        if (isActivePairingRequest) {
                                            FissionLogUtils.d(TAG, "蓝牙恢复后配对已由外部触发，跳过重复 onBleConnected")
                                        } else {
                                            FissionLogUtils.d(TAG, "Classic Ready 后重新发起 BT 连接")
                                            onBleConnected(device)
                                        }
                                    } else {
                                        FissionLogUtils.d(TAG, "Classic Ready 后等待 BLE 连接再配对")
                                    }
                                }

                                else -> syncConnectionState()
                            }
                        }
                    }
                }
            }
        }
    }

    private val bondedReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            if (!hasBondPermission()) return
            val action = intent?.action ?: return
            val device: BluetoothDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                ?: return
            if (!isTargetDevice(device)) return
            when (action) {
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    // 必须用 Intent extras：createBond 失败极快时 device.bondState 可能已跳到 NONE，
                    // 会把 BONDING 广播误判成 BOND_NONE，导致一次失败计两次重试。
                    val bondState = intent.getIntExtra(
                        BluetoothDevice.EXTRA_BOND_STATE,
                        BluetoothDevice.ERROR
                    )
                    val previousBondState = intent.getIntExtra(
                        BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE,
                        BluetoothDevice.ERROR
                    )
                    when (bondState) {
                        BluetoothDevice.BOND_BONDING -> scope.launch {
                            FissionLogUtils.d(
                                TAG,
                                "回调状态： 绑定中。。。 prev=$previousBondState"
                            )
                            emitEvent(BtConnectEvent.Bonding(device))
                        }

                        BluetoothDevice.BOND_BONDED -> scope.launch {
                            synchronized(pairingLock) {
                                isActivePairingRequest = false
                                pendingBondResume = false
                                bondResumeInProgress = false
                                bondFailedThisGeneration = false
                            }
                            updateClassicStackState(ClassicStackState.READY, "bonded")
                            FissionLogUtils.d(TAG, "回调状态： 绑定成功 gen=${recoveryGeneration.get()}")
                            val resolved = refreshRemoteDevice(device)
                            emitEvent(BtConnectEvent.Bonded(resolved))
                            if (isBleConnected() && isCurrentConnectedDevice(resolved) && btConfig().hasAnyProfile()) {
                                scheduleConnectConfiguredProfiles(resolved, reason = "bond_success")
                            }
                        }

                        BluetoothDevice.BOND_NONE -> scope.launch {
                            FissionLogUtils.d(
                                TAG,
                                "回调状态： 未绑定 prev=$previousBondState isActivePairingRequest=$isActivePairingRequest bondResumeInProgress=$bondResumeInProgress isUnpairingInProgress=$isUnpairingInProgress gen=${recoveryGeneration.get()}"
                            )
                            if (isUnpairingInProgress) return@launch
                            // 仅在「配对中 → 未绑定」时视为配对失败；忽略无关的 NONE 广播
                            if (previousBondState != BluetoothDevice.BOND_BONDING) {
                                FissionLogUtils.d(TAG, "忽略非配对失败的 BOND_NONE (prev=$previousBondState)")
                                return@launch
                            }
                            if (getBondedDevice(device.address) != null) {
                                FissionLogUtils.d(TAG, "系统配对列表仍包含该设备，跳过自动重配对")
                                return@launch
                            }
                            if (!isActivePairingRequest && !bondResumeInProgress && !hasBondAttemptThisGeneration()) {
                                FissionLogUtils.d(TAG, "忽略非本端发起的 BOND_NONE")
                                return@launch
                            }
                            // Classic Ready 后仍失败：不再次数重试，等待新恢复事件
                            reportBondTerminalFailure(
                                device = refreshRemoteDevice(device),
                                reason = "Bond failed after Classic Ready",
                                message = "Bond failed; waiting for next recovery event",
                            )
                        }
                    }
                }
            }
        }
    }

    private val a2dpReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            scope.launch {
                if (intent?.action == BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED) {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    device?.let {
                        if (!isTargetDevice(it)) return@let
                            val state = intent.getIntExtra(
                                BluetoothProfile.EXTRA_STATE,
                                BluetoothProfile.STATE_DISCONNECTED
                            )
                            when (state) {
                                BluetoothProfile.STATE_CONNECTING -> {
                                    FissionLogUtils.d(TAG, "A2DP 连接中")
                                }

                                BluetoothProfile.STATE_CONNECTED -> {
                                    FissionLogUtils.d(TAG, "A2DP 已连接")
                                    emitEvent(BtConnectEvent.A2dpConnected(it))
                                    if (!isUnpairingInProgress) syncConnectionState(it)
                                }

                                BluetoothProfile.STATE_DISCONNECTING -> {
                                    FissionLogUtils.d(TAG, "A2DP 断开中")
                                }

                                BluetoothProfile.STATE_DISCONNECTED -> {
                                    FissionLogUtils.d(TAG, "A2DP 已断开")
                                    if (!isUnpairingInProgress) {
                                        emitEvent(BtConnectEvent.A2dpDisconnected(it))
                                        syncConnectionState(it)
                                        if (btConfig().connectA2dp) {
                                            scheduleProfileRecovery(it, "A2DP")
                                        }
                                    }
                                }
                            }
                    }
                }
            }
        }
    }

    private val hfpReceiver = object : BroadcastReceiver() {
        @SuppressLint("SuspiciousIndentation")
        override fun onReceive(context: Context?, intent: Intent?) {
            scope.launch {
                if (intent?.action == BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED) {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    device?.let {
                        if (!isTargetDevice(it)) return@let
                            val state = intent.getIntExtra(
                                BluetoothProfile.EXTRA_STATE,
                                BluetoothProfile.STATE_DISCONNECTED
                            )
                            when (state) {
                                BluetoothProfile.STATE_CONNECTING -> {
                                    FissionLogUtils.d(TAG, "HFP 连接中")
                                }

                                BluetoothProfile.STATE_CONNECTED -> {
                                    FissionLogUtils.d(TAG, "HFP 已连接")
                                    emitEvent(BtConnectEvent.HfpConnected(it))
                                    if (!isUnpairingInProgress) syncConnectionState(it)
                                }

                                BluetoothProfile.STATE_DISCONNECTING -> {
                                    FissionLogUtils.d(TAG, "HFP 断开中")
                                }

                                BluetoothProfile.STATE_DISCONNECTED -> {
                                    FissionLogUtils.d(TAG, "HFP 已断开")
                                    if (!isUnpairingInProgress) {
                                        emitEvent(BtConnectEvent.HfpDisconnected(it))
                                        syncConnectionState(it)
                                        if (btConfig().connectHfp) {
                                            scheduleProfileRecovery(it, "HFP")
                                        }
                                    }
                                }
                            }
                    }
                }
            }
        }
    }

    private val uuidReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BluetoothDevice.ACTION_UUID) {
                val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                val uuidExtra = intent.getParcelableArrayExtra(BluetoothDevice.EXTRA_UUID)
                val uuids = uuidExtra?.map { it as ParcelUuid }
                device?.let {
                    if (!isTargetDevice(it)) return@let
                    val resolved = refreshRemoteDevice(it)
                    val hasUuids = !uuids.isNullOrEmpty() || !resolved.uuids.isNullOrEmpty()
                    // 同步通知等待中的 awaitClassicDeviceReady，不在此直接 createBond
                    classicStackMonitor.notifyUuid(resolved.address, resolved.type, hasUuids)
                    FissionLogUtils.d(
                        TAG,
                        "收到UUID广播: ${uuids?.joinToString()}  type: ${resolved.type} 配对state: ${resolved.bondState}"
                    )
                    if (resolved.bondState == BluetoothDevice.BOND_BONDED) {
                        sdpRetryJob?.cancel()
                        if (hasUuids && btConfig().hasAnyProfile()) {
                            scheduleConnectConfiguredProfiles(resolved, reason = "uuid_broadcast")
                        } else if (!hasUuids) {
                            scheduleSdpUuidRetry(resolved)
                        }
                    } else if (
                        !isClassicStackNotReady(resolved) &&
                        getBondedDevice(resolved.address) == null &&
                        !isUnpairingInProgress &&
                        btConfig().enableBond &&
                        isBleConnected()
                    ) {
                        val link = queryLinkState(resolved)
                        if (hasConnectedOrConnectingClassicProfiles(link)) {
                            FissionLogUtils.d(
                                TAG,
                                "UUID 广播：经典蓝牙 Profile 已活跃，跳过重复配对 a2dp=${link.a2dpState} hfp=${link.hfpState}"
                            )
                            scope.launch { syncConnectionState(resolved) }
                        } else if (bondFailedThisGeneration || !hasBondAttemptThisGeneration()) {
                            // Classic Ready 信号：本代失败后或尚未尝试时，开新一代再 createBond 一次
                            if (bondFailedThisGeneration) {
                                beginRecoveryGeneration("ACTION_UUID")
                            }
                            FissionLogUtils.d(TAG, "ACTION_UUID Classic Ready，发起配对")
                            scheduleCreateBond(resolved)
                        }
                    }
                }
            }
        }
    }

    private val foundReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BluetoothDevice.ACTION_FOUND) {
                val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                device?.let {
                    if (!isTargetDevice(it)) return@let
                    if (!hasScanPermission()) return@let
                    val refreshed = refreshRemoteDevice(it)
                    FissionLogUtils.d(TAG, "发现目标设备，Type: ${refreshed.type} name=${refreshed.name}")
                    // 同步通知等待中的 awaitClassicDeviceReady
                    classicStackMonitor.notifyFound(refreshed.address, refreshed.type)
                    bluetoothAdapter?.cancelDiscovery()
                    btDiscoveryJob?.cancel()
                    if (refreshed.type != BluetoothDevice.DEVICE_TYPE_UNKNOWN) {
                        FissionLogUtils.d(TAG, "经典蓝牙设备已就绪，fetchUuidsWithSdp")
                        refreshed.fetchUuidsWithSdp()
                    }
                }
            }
        }
    }

    fun isBluetoothOn(): Boolean = bluetoothAdapter?.isEnabled == true

    /**
     * BLE 连接成功后的唯一 BT 回连入口：先校验 BLE 已就绪，再按 [BtConnectionConfig] 发起配对/Profile 连接。
     */
    @SuppressLint("MissingPermission")
    internal fun onBleConnected(device: BluetoothDevice?) {
        if (!ensureInitialized("onBleConnected")) return
        if (device == null) return
        if (BleManager.isOtaMode()) return
        if (!btConfig().needsBtConnection()) {
            FissionLogUtils.d(TAG, "onBleConnected skipped: BT disabled by config")
            return
        }
        if (!isBleConnected()) {
            FissionLogUtils.w(TAG, "onBleConnected skipped: BLE not connected")
            return
        }
        if (!isBluetoothOn()) {
            updateClassicStackState(ClassicStackState.WAIT_ADAPTER_ON, "ble_connected_adapter_off")
            scope.launch { emitEvent(BtConnectEvent.Failed(device, "Bluetooth is not enabled")) }
            return
        }
        if (!hasBondPermission()) {
            scope.launch { emitEvent(BtConnectEvent.Failed(device, "No Bluetooth permission")) }
            return
        }
        val resolved = refreshRemoteDevice(device)
        val link = queryLinkState(resolved)
        if (areConfiguredProfilesConnected(link)) {
            FissionLogUtils.d(
                TAG,
                "onBleConnected skipped: configured BT profiles already connected, a2dp=${link.a2dpState} hfp=${link.hfpState}"
            )
            scope.launch { syncConnectionState(device) }
            return
        }
        profileRecoveryJob?.cancel()
        // 新 BLE 连接开启一代；若刚由 STATE_ON 开启且本代尚未 createBond，则复用该代
        val reuseAdapterGeneration = bondResumeInProgress && !hasBondAttemptThisGeneration()
        if (!reuseAdapterGeneration) {
            beginRecoveryGeneration("ble_connected")
        } else {
            FissionLogUtils.d(TAG, "复用 STATE_ON 恢复代数 gen=${recoveryGeneration.get()}")
        }
        startBtConnectionAfterBle(device, "ble_connected")
        scope.launch {
            delay(500)
            if (isCurrentConnectedDevice(device)) {
                syncConnectionState(device)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBtConnectionAfterBle(device: BluetoothDevice, source: String) {
        val config = btConfig()
        when {
            config.enableBond -> {
                adoptBondResumeIntent(source)
                scheduleCreateBond(device)
            }

            device.bondState == BluetoothDevice.BOND_BONDED && config.hasAnyProfile() -> {
                scheduleConnectConfiguredProfiles(
                    refreshRemoteDevice(device),
                    reason = source,
                )
            }

            else -> {
                FissionLogUtils.d(TAG, "startBtConnectionAfterBle skipped: bond disabled and device not bonded")
            }
        }
    }

    /** 解绑/释放已连接的经典蓝牙 Profile（按配置项）。 */
    internal fun disconnectConfiguredProfiles(device: BluetoothDevice) {
        if (!ensureInitialized("disconnectConfiguredProfiles")) return
        profileRecoveryJob?.cancel()
        profileConnectJob?.cancel()
        cancelProfileRetryJobs(device.address)
        val config = btConfig()
        if (config.connectA2dp) disconnectProfile(device, GlassesConstant.BtProfileType.A2DP)
        if (config.connectHfp) disconnectProfile(device, GlassesConstant.BtProfileType.HFP)
        if (config.connectSpp) disconnectProfile(device, GlassesConstant.BtProfileType.SPP)
    }

    @SuppressLint("MissingPermission")
    private fun createBond(device: BluetoothDevice?) {
        if (!ensureInitialized("createBond")) return
        adoptBondResumeIntent("createBond")
        scheduleCreateBond(device)
    }

    /** 查询系统 BT 实际连接状态并上报事件，SDK 内部用于重启/Profile 就绪后同步。 */
    internal fun syncConnectionState(device: BluetoothDevice? = null) {
        if (isUnpairingInProgress) return
        if (!ensureInitialized("syncConnectionState")) return
        scope.launch {
            if (!isBluetoothOn() || !hasBondPermission()) return@launch

            waitForProfileProxy()

            val target = resolveTargetDevice(device) ?: return@launch
            val resolved = refreshRemoteDevice(target)
            val link = queryLinkState(resolved)
            FissionLogUtils.d(
                TAG,
                "syncConnectionState: ${resolved.address} bond=${link.bondState} a2dp=${link.a2dpState} hfp=${link.hfpState}"
            )
            emitLinkStateEvents(resolved, link)
        }
    }

    @SuppressLint("MissingPermission")
    private fun resolveTargetDevice(explicit: BluetoothDevice?): BluetoothDevice? {
        explicit?.let { return it }
        BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice?.let { return it }
        val mac = GlassesSpUtil.getMacAddress(null) ?: return null
        return getBondedDevice(mac) ?: bluetoothAdapter?.getRemoteDevice(mac)
    }

    private suspend fun waitForProfileProxy(maxWaitMs: Long = 2500L) {
        val deadline = System.currentTimeMillis() + maxWaitMs
        while (System.currentTimeMillis() < deadline) {
            if (a2dpProxy != null || hfpProxy != null) return
            delay(100)
        }
    }

    private suspend fun emitLinkStateEvents(device: BluetoothDevice, link: BtLinkState) {
        when {
            link.bondState == BluetoothDevice.BOND_BONDING -> {
                emitEvent(BtConnectEvent.Bonding(device))
            }

            link.bondState == BluetoothDevice.BOND_BONDED &&
                link.a2dpState == BluetoothProfile.STATE_CONNECTED -> {
                emitEvent(BtConnectEvent.A2dpConnected(device))
                if (link.hfpState == BluetoothProfile.STATE_CONNECTED) {
                    emitEvent(BtConnectEvent.HfpConnected(device))
                }
            }

            link.bondState == BluetoothDevice.BOND_BONDED &&
                (link.a2dpState == BluetoothProfile.STATE_CONNECTING ||
                    link.hfpState == BluetoothProfile.STATE_CONNECTING) -> {
                emitEvent(BtConnectEvent.Bonded(device))
            }

            link.bondState == BluetoothDevice.BOND_BONDED -> {
                emitEvent(BtConnectEvent.Bonded(device))
            }
        }
    }

    /** BLE 连接成功等外部入口接管蓝牙恢复后的配对 */
    private fun adoptBondResumeIntent(source: String) {
        synchronized(pairingLock) {
            if (!pendingBondResume) return
            bondResumeInProgress = true
            pendingBondResume = false
            FissionLogUtils.d(TAG, "接管蓝牙恢复配对流程 source=$source")
        }
    }

    /** 串行调度配对；同一 recoveryGeneration 只允许一次真正的 createBond */
    @SuppressLint("MissingPermission")
    private fun scheduleCreateBond(device: BluetoothDevice?) {
        if (device == null) return
        if (isBtAutoConnectSuspended()) {
            FissionLogUtils.d(TAG, "BT 自动连接已暂停，跳过 createBond")
            return
        }
        scope.launch {
            if (!isCurrentConnectedDevice(device)) {
                FissionLogUtils.d(TAG, "非当前连接设备，跳过 scheduleCreateBond: ${device.address}")
                return@launch
            }
            val resolved = refreshRemoteDevice(device)
            when (resolved.bondState) {
                BluetoothDevice.BOND_BONDED -> {
                    createBondInternal(resolved)
                    return@launch
                }

                BluetoothDevice.BOND_BONDING -> {
                    FissionLogUtils.d(TAG, "配对进行中，跳过重复 createBond")
                    isActivePairingRequest = true
                    return@launch
                }
            }
            if (hasBondAttemptThisGeneration()) {
                FissionLogUtils.d(
                    TAG,
                    "本代(gen=${recoveryGeneration.get()})已发起过 createBond，等待新恢复事件"
                )
                return@launch
            }
            if (isActivePairingRequest || btPairJob?.isActive == true) {
                FissionLogUtils.d(TAG, "配对任务进行中，跳过重复 createBond")
                return@launch
            }
            btPairJob?.cancel()
            btPairJob = scope.launch {
                createBondInternal(device)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun scheduleConnectConfiguredProfiles(
        device: BluetoothDevice,
        delayMs: Long = btProfileConnectSettleDelayMs,
        reason: String = "",
    ) {
        if (!ensureInitialized("scheduleConnectConfiguredProfiles")) return
        if (isBtAutoConnectSuspended()) {
            FissionLogUtils.d(TAG, "scheduleConnectConfiguredProfiles skipped: BT auto-connect suspended, reason=$reason")
            return
        }
        if (!btConfig().hasAnyProfile()) {
            FissionLogUtils.d(TAG, "scheduleConnectConfiguredProfiles skipped: no profile enabled, reason=$reason")
            return
        }
        profileConnectJob?.cancel()
        profileConnectJob = scope.launch {
            if (delayMs > 0) delay(delayMs)
            if (!isCurrentConnectedDevice(device)) {
                FissionLogUtils.d(TAG, "scheduleConnectConfiguredProfiles skipped: not current device, reason=$reason")
                return@launch
            }
            val resolved = refreshRemoteDevice(device)
            if (resolved.bondState != BluetoothDevice.BOND_BONDED) {
                FissionLogUtils.d(TAG, "scheduleConnectConfiguredProfiles skipped: not bonded, reason=$reason")
                return@launch
            }
            val bypassDebounce = reason == "profile_recovery" || reason == "ble_connected"
            if (!bypassDebounce) {
                synchronized(profileConnectLock) {
                    val elapsed = System.currentTimeMillis() - lastProfileConnectAtMs
                    if (elapsed in 0 until btProfileConnectDebounceMs) {
                        FissionLogUtils.d(TAG, "scheduleConnectConfiguredProfiles debounced ${elapsed}ms, reason=$reason")
                        return@launch
                    }
                    lastProfileConnectAtMs = System.currentTimeMillis()
                }
            } else {
                synchronized(profileConnectLock) {
                    lastProfileConnectAtMs = System.currentTimeMillis()
                }
            }
            connectConfiguredProfilesInternal(resolved, reason)
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectConfiguredProfilesInternal(device: BluetoothDevice, reason: String) {
        val config = btConfig()
        if (!config.hasAnyProfile()) return
        bluetoothAdapter?.cancelDiscovery()
        btDiscoveryJob?.cancel()
        val link = queryLinkState(device)
        if (areConfiguredProfilesConnected(link)) {
            FissionLogUtils.d(TAG, "connectConfiguredProfiles skipped: profiles already connected, reason=$reason")
            return
        }
        FissionLogUtils.d(
            TAG,
            "connectConfiguredProfiles start: a2dp=${link.a2dpState} hfp=${link.hfpState} sppEnabled=${config.connectSpp} reason=$reason"
        )
        cancelProfileRetryJobs(device.address)
        if (config.connectA2dp) connectA2dpIfNeeded(device)
        scope.launch {
            delay(500)
            if (!isCurrentConnectedDevice(device)) return@launch
            if (config.connectHfp) connectHfpIfNeeded(device)
            if (config.connectSpp) connectSppIfNeeded(device)
        }
    }

    @SuppressLint("MissingPermission")
    private fun scheduleProfileRecovery(device: BluetoothDevice, profile: String) {
        if (isBtAutoConnectSuspended()) return
        if (!isBleConnected()) return
        if (!isCurrentConnectedDevice(device)) return
        if (!btConfig().hasAnyProfile()) return
        profileRecoveryJob?.cancel()
        profileRecoveryJob = scope.launch {
            delay(btProfileRecoveryDelayMs)
            if (isBtAutoConnectSuspended() || !isBleConnected() || !isCurrentConnectedDevice(device)) return@launch
            val resolved = refreshRemoteDevice(device)
            if (resolved.bondState != BluetoothDevice.BOND_BONDED) return@launch
            val link = queryLinkState(resolved)
            if (areConfiguredProfilesConnected(link)) {
                return@launch
            }
            if (link.a2dpState == BluetoothProfile.STATE_CONNECTING ||
                link.hfpState == BluetoothProfile.STATE_CONNECTING
            ) {
                FissionLogUtils.d(TAG, "profile recovery skipped: profile still connecting after $profile disconnect")
                return@launch
            }
            FissionLogUtils.d(TAG, "profile recovery after $profile disconnect")
            scheduleConnectConfiguredProfiles(resolved, delayMs = 0, reason = "profile_recovery")
        }
    }

    private fun isBleConnected(): Boolean {
        return BleManager.currentDeviceManager?.bleConnection != null
    }

    private fun cancelProfileRetryJobs(address: String) {
        val config = btConfig()
        if (config.connectA2dp) retryJobs.remove("A2DP_$address")?.cancel()
        if (config.connectHfp) retryJobs.remove("HFP_$address")?.cancel()
        if (config.connectSpp) retryJobs.remove("SPP_$address")?.cancel()
    }

    private fun connectA2dp(device: BluetoothDevice) {
        if (!isProfileEnabled(GlassesConstant.BtProfileType.A2DP)) return
        retryConnect("A2DP_${device.address}", device, GlassesConstant.BtProfileType.A2DP)
    }

    private fun connectHfp(device: BluetoothDevice) {
        if (!isProfileEnabled(GlassesConstant.BtProfileType.HFP)) return
        retryConnect("HFP_${device.address}", device, GlassesConstant.BtProfileType.HFP)
    }

    private fun connectSpp(device: BluetoothDevice) {
        if (!isProfileEnabled(GlassesConstant.BtProfileType.SPP)) return
        retryConnect("SPP_${device.address}", device, GlassesConstant.BtProfileType.SPP)
    }

    /** 注销 init 时注册的长期 BroadcastReceiver；调用方需持有 [synchronized] this。 */
    private fun unregisterReceiversLocked() {
        val ctx = appContext
        if (!receiversRegistered.get() || ctx == null) return
        try {
            ctx.unregisterReceiver(bondedReceiver)
            ctx.unregisterReceiver(adapterReceiver)
            ctx.unregisterReceiver(a2dpReceiver)
            ctx.unregisterReceiver(hfpReceiver)
            ctx.unregisterReceiver(uuidReceiver)
            ctx.unregisterReceiver(foundReceiver)
            FissionLogUtils.d(TAG, "BroadcastReceivers unregistered")
        } catch (_: Exception) {
        }
        receiversRegistered.set(false)
    }

    @SuppressLint("MissingPermission") fun release(device: BluetoothDevice?) {
        FissionLogUtils.d(TAG, "release device is null: ${device == null}")
        val releasingGeneration: Int
        synchronized(this) {
            // 解绑可能已提前 unregisterReceivers；只要仍标记 initialized 就继续收尾
            if (!initialized.get() && !receiversRegistered.get()) return
            releasingGeneration = initGeneration.get()
            unregisterReceiversLocked()
            initialized.set(false)
        }

        scope.launch(Dispatchers.Main) {
            if (initGeneration.get() != releasingGeneration) {
                FissionLogUtils.d(TAG, "release cleanup skipped: BtManager re-initialized")
                return@launch
            }

            if (hasScanPermission()) {
                bluetoothAdapter?.cancelDiscovery()
            }
            btDiscoveryJob?.cancel()
            btPairJob?.cancel()
            sdpRetryJob?.cancel()
            profileConnectJob?.cancel()
            profileRecoveryJob?.cancel()
            stackReadyJob?.cancel()
            isActivePairingRequest = false
            pendingBondResume = false
            bondResumeInProgress = false
            bondAttemptedGeneration = -1
            bondFailedThisGeneration = false
            updateClassicStackState(ClassicStackState.OFF, "release")
            retryJobs.values.forEach { it.cancel() }
            retryJobs.clear()
            device?.let {
                disconnectA2dpInternal(it)
                disconnectHfpInternal(it)
            }
            a2dpProxy?.let { bluetoothAdapter?.closeProfileProxy(BluetoothProfile.A2DP, it) }
            hfpProxy?.let { bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HEADSET, it) }
            if (initGeneration.get() != releasingGeneration) {
                FissionLogUtils.d(TAG, "release proxy cleanup skipped: BtManager re-initialized")
                return@launch
            }
            a2dpProxy = null
            hfpProxy = null
            a2dpListener = null
            hfpListener = null
            appContext = null
            events = null
        }
    }

    private fun registerBondReceiver() {
        val ctx = requireContext() ?: return
        ctx.registerReceiver(bondedReceiver, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED))
        ctx.registerReceiver(adapterReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED))
        ctx.registerReceiver(a2dpReceiver, IntentFilter(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED))
        ctx.registerReceiver(hfpReceiver, IntentFilter(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED))
        ctx.registerReceiver(uuidReceiver, IntentFilter(BluetoothDevice.ACTION_UUID))
        ctx.registerReceiver(foundReceiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
    }

    private fun initA2dpProxy() {
        if (a2dpProxy != null) return
        val ctx = appContext ?: return
        a2dpListener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
                if (profile == BluetoothProfile.A2DP) {
                    a2dpProxy = proxy as BluetoothA2dp
                    scope.launch {
                        delay(200)
                        syncConnectionState()
                    }
                }
            }

            override fun onServiceDisconnected(profile: Int) {
                if (profile == BluetoothProfile.A2DP) a2dpProxy = null
            }
        }
        bluetoothAdapter?.getProfileProxy(ctx, a2dpListener, BluetoothProfile.A2DP)
    }

    private fun initHfpProxy() {
        if (hfpProxy != null) return
        val ctx = appContext ?: return
        hfpListener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
                if (profile == BluetoothProfile.HEADSET) {
                    hfpProxy = proxy as BluetoothHeadset
                }
            }

            override fun onServiceDisconnected(profile: Int) {
                if (profile == BluetoothProfile.HEADSET) hfpProxy = null
            }
        }
        bluetoothAdapter?.getProfileProxy(ctx, hfpListener, BluetoothProfile.HEADSET)
    }

    private fun cancelPendingJobs() {
        retryJobs.values.forEach { it.cancel() }
        retryJobs.clear()
        sdpRetryJob?.cancel()
        btDiscoveryJob?.cancel()
        btPairJob?.cancel()
        profileConnectJob?.cancel()
        profileRecoveryJob?.cancel()
        stackReadyJob?.cancel()
    }

    @SuppressLint("MissingPermission")
    private suspend fun createBondInternal(device: BluetoothDevice?) {
        try {
            if (isBtAutoConnectSuspended()) {
                FissionLogUtils.d(TAG, "BT 自动连接已暂停，跳过 createBondInternal")
                return
            }
            if (!isCurrentConnectedDevice(device)) {
                FissionLogUtils.d(TAG, "非当前连接设备，跳过 createBond: ${device?.address}")
                return
            }

            if (!isBluetoothOn()) {
                FissionLogUtils.d(TAG, "蓝牙未开启")
                updateClassicStackState(ClassicStackState.WAIT_ADAPTER_ON, "create_bond")
                emitEvent(BtConnectEvent.Failed(device, "Bluetooth is not enabled"))
                return
            }

            if (!hasBondPermission()) {
                emitEvent(BtConnectEvent.Failed(device, "No Bluetooth permission"))
                return
            }

            device?.let { rawDevice ->
                delay(bleSettleBeforeBondMs)
                if (!isBleConnected() || !isCurrentConnectedDevice(rawDevice)) return

                var curDevice = refreshRemoteDevice(rawDevice)
                FissionLogUtils.d(
                    TAG,
                    "createBond状态: bond=${curDevice.bondState} type=${curDevice.type} name=${curDevice.name} uuids=${curDevice.uuids} stack=$classicStackState gen=${recoveryGeneration.get()} resume=$bondResumeInProgress"
                )

                when (curDevice.bondState) {
                    BluetoothDevice.BOND_BONDED -> {
                        synchronized(pairingLock) {
                            isActivePairingRequest = false
                            pendingBondResume = false
                            bondResumeInProgress = false
                            bondFailedThisGeneration = false
                        }
                        updateClassicStackState(ClassicStackState.READY, "already_bonded")
                        emitEvent(BtConnectEvent.Bonded(curDevice))
                        if (btConfig().hasAnyProfile()) {
                            scheduleConnectConfiguredProfiles(curDevice, reason = "createBond_bonded")
                        }
                        return
                    }

                    BluetoothDevice.BOND_BONDING -> {
                        FissionLogUtils.d(TAG, "设备配对中，等待系统回调")
                        isActivePairingRequest = true
                        return
                    }
                }

                bluetoothAdapter?.cancelDiscovery()
                btDiscoveryJob?.cancel()
                if (!btConfig().enableBond) {
                    FissionLogUtils.d(TAG, "设备未配对且配置关闭 bond，跳过 createBond")
                    return
                }
                val link = queryLinkState(curDevice)
                if (hasConnectedOrConnectingClassicProfiles(link)) {
                    FissionLogUtils.d(
                        TAG,
                        "经典蓝牙 Profile 已连接/连接中，跳过 createBond 避免系统重复配对弹窗 a2dp=${link.a2dpState} hfp=${link.hfpState}"
                    )
                    synchronized(pairingLock) {
                        isActivePairingRequest = false
                        pendingBondResume = false
                        bondResumeInProgress = false
                    }
                    emitLinkStateEvents(curDevice, link)
                    return
                }

                // Classic Ready 应在 createBond 前完成
                if (classicStackState != ClassicStackState.READY || isClassicStackNotReady(curDevice)) {
                    val prepOk = ensureClassicReadyBeforeBond(rawDevice.address)
                    curDevice = refreshRemoteDevice(rawDevice)
                    if (isBtAutoConnectSuspended() || !isCurrentConnectedDevice(rawDevice)) return
                    if (!isBluetoothOn()) {
                        emitEvent(BtConnectEvent.Failed(rawDevice, "Bluetooth is not enabled"))
                        return
                    }
                    when (curDevice.bondState) {
                        BluetoothDevice.BOND_BONDED -> {
                            synchronized(pairingLock) {
                                isActivePairingRequest = false
                                pendingBondResume = false
                                bondResumeInProgress = false
                                bondFailedThisGeneration = false
                            }
                            emitEvent(BtConnectEvent.Bonded(curDevice))
                            if (btConfig().hasAnyProfile()) {
                                scheduleConnectConfiguredProfiles(curDevice, reason = "createBond_bonded_after_prep")
                            }
                            return
                        }
                        BluetoothDevice.BOND_BONDING -> {
                            FissionLogUtils.d(TAG, "预热后设备已在配对中，跳过 createBond")
                            isActivePairingRequest = true
                            return
                        }
                    }
                    if (!prepOk || isClassicStackNotReady(curDevice)) {
                        // 重试放在 Classic Ready 等待内部（SDP），此处超时直接上报，不 createBond 次数重试
                        reportBondTerminalFailure(
                            device = curDevice,
                            reason = "Classic BT stack not ready",
                            message = "Classic Ready timeout; waiting for next recovery event",
                        )
                        return
                    }
                    FissionLogUtils.d(
                        TAG,
                        "Classic Ready 后 createBond状态: bond=${curDevice.bondState} type=${curDevice.type} name=${curDevice.name} uuids=${curDevice.uuids}"
                    )
                } else {
                    curDevice = refreshRemoteDevice(rawDevice)
                }

                if (hasBondAttemptThisGeneration()) {
                    FissionLogUtils.d(TAG, "本代已发起过 createBond，跳过")
                    return
                }

                FissionLogUtils.d(TAG, "设备未配对，发起 BREDR 配对 gen=${recoveryGeneration.get()}")
                val started = createBondWithRefreshOnce(curDevice)
                if (!started) {
                    reportBondTerminalFailure(
                        device = curDevice,
                        reason = "createBond returned false",
                        message = "Failed to start BREDR bond; waiting for next recovery event",
                    )
                }
            }
        } catch (e: Exception) {
            emitEvent(BtConnectEvent.Failed(device, e.message ?: "createBond error"))
        }
    }

    private fun retryConnect(
        key: String,
        device: BluetoothDevice,
        profile: GlassesConstant.BtProfileType
    ) {
        if (!isProfileEnabled(profile)) return
        retryJobs[key]?.cancel()
        val job = scope.launch {
            repeat(maxRetry) {
                try {
                    val success = when (profile) {
                        GlassesConstant.BtProfileType.A2DP -> connectA2dpInternal(device)
                        GlassesConstant.BtProfileType.HFP -> connectHfpInternal(device)
                        GlassesConstant.BtProfileType.SPP -> connectSppInternal(device)
                        else -> false
                    }
                    if (success) return@launch
                } catch (e: Exception) {
                    FissionLogUtils.i(TAG,"$key Connect error, ${e.message}")
                }
                delay(retryInterval)
            }
            FissionLogUtils.w(TAG, "$profile 已达最大重连次数 ($maxRetry)")
            // 仅 A2DP 达上限时通知上层需手动连接；HFP/SPP 静默结束
            if (profile == GlassesConstant.BtProfileType.A2DP) {
                emitEvent(
                    BtConnectEvent.Failed(
                        device = device,
                        message = "Failed to connect $profile after $maxRetry attempts"
                    )
                )
            }
        }
        retryJobs[key] = job
    }

    @SuppressLint("MissingPermission")
    private fun connectA2dpIfNeeded(device: BluetoothDevice) {
        if (!btConfig().connectA2dp) return
        val state = a2dpProxy?.getConnectionState(device)
        if (state == BluetoothProfile.STATE_CONNECTED || state == BluetoothProfile.STATE_CONNECTING) {
            return
        }
        connectA2dp(device)
    }

    @SuppressLint("MissingPermission")
    private fun connectHfpIfNeeded(device: BluetoothDevice) {
        if (!btConfig().connectHfp) return
        val state = hfpProxy?.getConnectionState(device)
        if (state == BluetoothProfile.STATE_CONNECTED || state == BluetoothProfile.STATE_CONNECTING) {
            return
        }
        connectHfp(device)
    }

    @SuppressLint("MissingPermission")
    private fun connectSppIfNeeded(device: BluetoothDevice) {
        if (!btConfig().connectSpp) return
        val connected = sppConnections.containsKey(device.address)
        if (connected) return
        connectSpp(device)
    }

    private fun disconnectProfile(device: BluetoothDevice, profile: GlassesConstant.BtProfileType) {
        scope.launch {
            try {
                when (profile) {
                    GlassesConstant.BtProfileType.A2DP -> disconnectA2dpInternal(device)
                    GlassesConstant.BtProfileType.HFP -> disconnectHfpInternal(device)
                    GlassesConstant.BtProfileType.SPP -> disconnectSppInternal(device)
                    else -> {}
                }
            } catch (e: Exception) {
                FissionLogUtils.d(TAG,"Disconnect error : ${e.message}")
            }
        }
    }

    private fun connectA2dpInternal(device: BluetoothDevice): Boolean {
        return try {
            a2dpProxy?.let { proxy ->
                val method = proxy.javaClass.getMethod("connect", BluetoothDevice::class.java)
                method.invoke(proxy, device)
                true
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun disconnectA2dpInternal(device: BluetoothDevice) {
        a2dpProxy?.let { proxy ->
            val method = proxy.javaClass.getMethod("disconnect", BluetoothDevice::class.java)
            method.invoke(proxy, device)
        }
    }

    private fun connectHfpInternal(device: BluetoothDevice): Boolean {
        return try {
            hfpProxy?.let { proxy ->
                val method = proxy.javaClass.getMethod("connect", BluetoothDevice::class.java)
                method.invoke(proxy, device)
                true
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun disconnectHfpInternal(device: BluetoothDevice) {
        hfpProxy?.let { proxy ->
            val method = proxy.javaClass.getMethod("disconnect", BluetoothDevice::class.java)
            method.invoke(proxy, device)
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun connectSppInternal(device: BluetoothDevice): Boolean =
        withContext(Dispatchers.IO) {
            try {
                if (!hasBondPermission()) {
                    emitEvent(BtConnectEvent.Failed(device, "No Bluetooth permission"))
                    return@withContext false
                }
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket.connect()
                sppConnections[device.address] = socket
                emitEvent(BtConnectEvent.SppConnected(device))
                true
            } catch (_: IOException) {
                emitEvent(BtConnectEvent.SppDisconnected(device))
                false
            }
        }

    private suspend fun disconnectSppInternal(device: BluetoothDevice) =
        withContext(Dispatchers.IO) {
            sppConnections.remove(device.address)?.close()
            emitEvent(BtConnectEvent.SppDisconnected(device))
        }

    @SuppressLint("MissingPermission")
    private fun getBondedDevice(address: String): BluetoothDevice? {
        if (!hasBondPermission()) return null
        return bluetoothAdapter?.bondedDevices?.firstOrNull { it.address.equals(address, ignoreCase = true) }
    }

    @SuppressLint("MissingPermission")
    private fun isCurrentConnectedDevice(device: BluetoothDevice?): Boolean {
        return isTargetDevice(device)
    }

    @SuppressLint("MissingPermission")
    private fun isTargetDevice(device: BluetoothDevice?): Boolean {
        if (device == null) return false
        val bleMac = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice?.address
            ?: BleManager.currentDeviceManager?.rxBleDevice?.macAddress
        if (bleMac != null && device.address.equals(bleMac, ignoreCase = true)) return true
        val savedMac = GlassesSpUtil.getMacAddress(null) ?: return false
        return device.address.equals(savedMac, ignoreCase = true)
    }

    @SuppressLint("MissingPermission")
    private fun resolveBondedDevice(device: BluetoothDevice): BluetoothDevice {
        // 兼容旧调用点：统一走 refreshRemoteDevice，避免脏 BluetoothDevice
        return refreshRemoteDevice(device)
    }

    /**
     * 每次通过 adapter.getRemoteDevice(address) 刷新实例。
     * 不要复用 BLE 连接拿到的 BluetoothDevice，也不要优先 bonded cache：
     * 三星重启后 RemoteDevice Cache 会更新 type(UNKNOWN→LE→DUAL)，只有重新 getRemoteDevice 才能读到。
     */
    @SuppressLint("MissingPermission")
    private fun refreshRemoteDevice(device: BluetoothDevice): BluetoothDevice {
        return refreshRemoteDevice(device.address) ?: device
    }

    @SuppressLint("MissingPermission")
    private fun refreshRemoteDevice(address: String): BluetoothDevice? {
        if (address.isBlank()) return null
        return try {
            bluetoothAdapter?.getRemoteDevice(address)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 判断 BR/EDR 栈是否尚未恢复。
     * - UUID 已有 → Ready（厂商可能 type 仍短暂异常）
     * - DUAL / CLASSIC → Ready
     * - UNKNOWN → Not Ready（华为等）
     * - LE 且 UUID 为空 → Not Ready（三星恢复中常见，此时 createBond 会失败）
     */
    @SuppressLint("MissingPermission")
    private fun isClassicStackNotReady(device: BluetoothDevice): Boolean {
        if (!device.uuids.isNullOrEmpty()) return false
        return when (device.type) {
            BluetoothDevice.DEVICE_TYPE_DUAL,
            BluetoothDevice.DEVICE_TYPE_CLASSIC -> false
            BluetoothDevice.DEVICE_TYPE_UNKNOWN,
            BluetoothDevice.DEVICE_TYPE_LE -> true
            else -> true
        }
    }

    @SuppressLint("MissingPermission")
    private fun isClassicDeviceReady(device: BluetoothDevice): Boolean = !isClassicStackNotReady(device)

    /**
     * STATE_ON 之后：最短等待 + Profile Proxy。
     * 注意：此处只表示 Adapter/Profile 代理可用，不等于 Classic Ready。
     */
    private suspend fun awaitBluetoothStackReady() {
        if (!isBluetoothOn()) {
            updateClassicStackState(ClassicStackState.WAIT_ADAPTER_ON, "stack_ready_wait")
            return
        }
        updateClassicStackState(ClassicStackState.WAIT_STACK_READY, "await_stack")
        val sinceOn = System.currentTimeMillis() - adapterOnAtMs
        val minRemain = (stackReadyMinWaitMs - sinceOn).coerceAtLeast(0L)
        if (minRemain > 0) {
            FissionLogUtils.d(TAG, "等待 Bluetooth Stack 最短恢复时间 ${minRemain}ms")
            delay(minRemain)
        }
        waitForProfileProxy()
        val deadline = System.currentTimeMillis() + (stackReadyMaxWaitMs - stackReadyMinWaitMs).coerceAtLeast(0L)
        while (System.currentTimeMillis() < deadline) {
            if (!isBluetoothOn()) {
                updateClassicStackState(ClassicStackState.WAIT_ADAPTER_ON, "stack_ready_lost")
                return
            }
            if (a2dpProxy != null || hfpProxy != null) break
            delay(stackReadyPollMs)
        }
        // 故意不进入 READY：Proxy Ready ≠ Classic Ready
        FissionLogUtils.d(
            TAG,
            "Bluetooth Profile Proxy Ready a2dp=${a2dpProxy != null} hfp=${hfpProxy != null}，继续等待 Classic Ready"
        )
    }

    /**
     * 独立 Classic Ready 阶段：在 createBond / onBleConnected 之前完成。
     * STATE_ON → Proxy → UUID/Discovery → CLASSIC_READY →（再）BLE → createBond
     */
    @SuppressLint("MissingPermission")
    private suspend fun ensureClassicReadyBeforeBond(address: String?): Boolean {
        if (address.isNullOrBlank()) return false
        if (!isBluetoothOn()) return false
        if (classicStackState != ClassicStackState.READY &&
            classicStackState != ClassicStackState.WAIT_BREDR_READY
        ) {
            awaitBluetoothStackReady()
            if (!isBluetoothOn()) return false
        }
        val device = awaitClassicDeviceReady(address, btClassicPrepTimeoutMs)
        val ready = isClassicDeviceReady(device)
        FissionLogUtils.d(
            TAG,
            "ensureClassicReadyBeforeBond ready=$ready type=${device.type} uuids=${device.uuids} state=$classicStackState"
        )
        return ready
    }

    @SuppressLint("MissingPermission")
    private fun startClassicDiscoveryIfNeeded(reason: String) {
        if (!hasScanPermission()) {
            FissionLogUtils.d(TAG, "无 BLUETOOTH_SCAN 权限，跳过经典蓝牙扫描 reason=$reason")
            return
        }
        val adapter = bluetoothAdapter ?: return
        if (adapter.isDiscovering) {
            FissionLogUtils.d(TAG, "经典蓝牙扫描进行中 reason=$reason")
            return
        }
        btDiscoveryJob?.cancel()
        val started = adapter.startDiscovery()
        FissionLogUtils.d(TAG, "启动经典蓝牙扫描 started=$started reason=$reason")
        btDiscoveryJob = scope.launch {
            delay(btDiscoveryTimeoutMs)
            if (adapter.isDiscovering) {
                adapter.cancelDiscovery()
                FissionLogUtils.d(TAG, "经典蓝牙扫描超时，已停止")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopClassicDiscovery() {
        btDiscoveryJob?.cancel()
        btDiscoveryJob = null
        if (bluetoothAdapter?.isDiscovering == true) {
            bluetoothAdapter?.cancelDiscovery()
        }
    }

    /**
     * 等待 BR/EDR 就绪：事件驱动（ACTION_UUID / ACTION_FOUND）+ 轮询 refreshRemoteDevice。
     * 不再使用固定 delay 后直接 createBond。
     */
    @SuppressLint("MissingPermission")
    private suspend fun awaitClassicDeviceReady(
        address: String,
        timeoutMs: Long = btClassicPrepTimeoutMs,
    ): BluetoothDevice {
        updateClassicStackState(ClassicStackState.WAIT_BREDR_READY, "await_bredr")
        var current: BluetoothDevice = refreshRemoteDevice(address) ?: run {
            FissionLogUtils.w(TAG, "awaitClassicDeviceReady: 无法获取 remote device $address")
            updateClassicStackState(ClassicStackState.WAIT_BREDR_READY, "no_remote_device")
            try {
                bluetoothAdapter?.getRemoteDevice(address)
            } catch (_: Exception) {
                null
            } ?: throw IllegalArgumentException("Invalid BT address: $address")
        }
        if (isClassicDeviceReady(current)) {
            updateClassicStackState(ClassicStackState.READY, "bredr_already_ready")
            return current
        }
        FissionLogUtils.d(
            TAG,
            "经典蓝牙栈预热开始 address=$address type=${current.type} timeout=${timeoutMs}ms"
        )
        try {
            bluetoothAdapter?.cancelDiscovery()
            current.fetchUuidsWithSdp()
            startClassicDiscoveryIfNeeded("awaitClassicDeviceReady")
            val deadline = System.currentTimeMillis() + timeoutMs
            var pollCount = 0
            var sdpRefreshCount = 0
            while (System.currentTimeMillis() < deadline) {
                if (isBtAutoConnectSuspended() || !isCurrentConnectedDevice(current)) break
                if (!isBluetoothOn()) break

                val remaining = (deadline - System.currentTimeMillis()).coerceAtLeast(0L)
                val signal = classicStackMonitor.awaitReadySignal(
                    address,
                    timeoutMs = minOf(btClassicPrepPollMs, remaining),
                )
                current = refreshRemoteDevice(address) ?: current
                if (signal != null || isClassicDeviceReady(current)) {
                    FissionLogUtils.d(
                        TAG,
                        "经典蓝牙栈预热完成 source=${signal?.source ?: "poll"} type=${current.type} name=${current.name} uuids=${current.uuids}"
                    )
                    break
                }
                pollCount += 1
                // Classic Ready 等待期内刷新 SDP（不是 createBond 重试）
                if (pollCount % 4 == 0 && sdpRefreshCount < classicReadySdpRefreshMax) {
                    sdpRefreshCount += 1
                    FissionLogUtils.d(TAG, "Classic Ready 等待中刷新 SDP $sdpRefreshCount/$classicReadySdpRefreshMax")
                    current.fetchUuidsWithSdp()
                }
            }
        } finally {
            stopClassicDiscovery()
        }
        current = refreshRemoteDevice(address) ?: current
        if (isClassicDeviceReady(current)) {
            updateClassicStackState(ClassicStackState.READY, "bredr_ready")
        } else {
            FissionLogUtils.w(
                TAG,
                "经典蓝牙栈预热超时 type=${current.type} name=${current.name} uuids=${current.uuids}"
            )
        }
        return current
    }

    @SuppressLint("MissingPermission")
    private fun queryLinkState(device: BluetoothDevice): BtLinkState {
        val refreshed = refreshRemoteDevice(device)
        return BtLinkState(
            bondState = refreshed.bondState,
            a2dpState = a2dpProxy?.getConnectionState(refreshed) ?: BluetoothProfile.STATE_DISCONNECTED,
            hfpState = hfpProxy?.getConnectionState(refreshed) ?: BluetoothProfile.STATE_DISCONNECTED,
        )
    }

    @SuppressLint("MissingPermission")
    private fun scheduleSdpUuidRetry(device: BluetoothDevice, maxRetry: Int = 3, intervalMs: Long = 1500L) {
        sdpRetryJob?.cancel()
        sdpRetryJob = scope.launch {
            repeat(maxRetry) { attempt ->
                FissionLogUtils.d(TAG, "SDP UUID 重试 ${attempt + 1}/$maxRetry")
                val refreshed = refreshRemoteDevice(device)
                refreshed.fetchUuidsWithSdp()
                delay(intervalMs)
                val resolved = refreshRemoteDevice(device)
                if (resolved.uuids != null) {
                    val a2dpState = a2dpProxy?.getConnectionState(resolved)
                    val connected = a2dpProxy?.connectedDevices?.contains(resolved) == true
                    if (!connected && (a2dpState == BluetoothProfile.STATE_DISCONNECTED || a2dpState == BluetoothProfile.STATE_DISCONNECTING)) {
                        scheduleConnectConfiguredProfiles(resolved, reason = "sdp_uuid_retry")
                    }
                    return@launch
                }
            }
            FissionLogUtils.w(TAG, "SDP UUID 重试耗尽，仍未获取到 UUID")
        }
    }

    @SuppressLint("MissingPermission")
    private fun createBondWithRefreshOnce(device: BluetoothDevice): Boolean {
        if (!isCurrentConnectedDevice(device)) {
            FissionLogUtils.d(TAG, "非当前连接设备，跳过 createBond: ${device.address}")
            return false
        }
        getBondedDevice(device.address)?.let { bonded ->
            FissionLogUtils.d(TAG, "设备已在系统配对列表，跳过 createBond")
            bonded.fetchUuidsWithSdp()
            return true
        }
        if (hasBondPermission()) {
            val link = queryLinkState(refreshRemoteDevice(device))
            if (hasConnectedOrConnectingClassicProfiles(link)) {
                FissionLogUtils.d(TAG, "createBond: 经典蓝牙 Profile 已活跃，跳过 createBond")
                synchronized(pairingLock) {
                    isActivePairingRequest = false
                }
                return true
            }
        }

        markBondAttemptThisGeneration()
        isActivePairingRequest = true

        var target = refreshRemoteDevice(device)
        val first = invokeCreateBondNative(target)
        if (first) return true

        // 唯一允许的二次尝试：旧 BluetoothDevice 可能已死，刷新后再试一次
        FissionLogUtils.w(TAG, "createBond 返回 false，refreshRemoteDevice 后再试一次")
        target = refreshRemoteDevice(device.address) ?: return false
        return invokeCreateBondNative(target)
    }

    @SuppressLint("MissingPermission")
    private fun invokeCreateBondNative(device: BluetoothDevice): Boolean {
        return try {
            val method = device.javaClass.getMethod("createBond", Int::class.javaPrimitiveType)
            method.invoke(device, BluetoothDevice.TRANSPORT_BREDR) as Boolean
        } catch (_: Exception) {
            if (!hasBondPermission()) {
                scope.launch {
                    emitEvent(BtConnectEvent.Failed(device, "No Bluetooth permission"))
                }
                return false
            }
            device.createBond()
        }
    }

    private fun removeBondReflect(device: BluetoothDevice): Boolean {
        return try {
            val method = device.javaClass.getMethod("removeBond")
            method.invoke(device) as? Boolean ?: true
        } catch (_: Exception) {
            try {
                device.javaClass.getMethod("removeBond").invoke(device) as? Boolean ?: true
            } catch (e: Exception) {
                FissionLogUtils.e(TAG, "removeBondReflect error: ${e.message}")
                false
            }
        }
    }

    private fun hasBondPermission(): Boolean {
        val ctx = appContext ?: return false
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                ActivityCompat.checkSelfPermission(
                    ctx,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) == PackageManager.PERMISSION_GRANTED
            }

            else -> true
        }
    }
    private fun hasScanPermission(): Boolean {
        val ctx = requireContext() ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(
                ctx,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requireContext(): Context? {
        val ctx = appContext
        if (ctx == null) {
            FissionLogUtils.w(TAG, "BtManager not initialized")
        }
        return ctx
    }

    private suspend fun emitEvent(event: GlassesEvent) {
        events?.emit(event)
    }
}