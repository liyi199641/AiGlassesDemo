package com.fission.wear.glasses.sdk.live

import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.constant.GlassesConstant.DEVICE_WIFI_BASE_URL
import com.fission.wear.glasses.sdk.constant.GlassesConstant.DEVICE_WIFI_BASE_URL_AP19
import com.fission.wear.glasses.sdk.constant.GlassesConstant.DEVICE_WIFI_BASE_URL_AP_AG66
import java.net.URI

/** LY 直播预览：按 Wi-Fi 模式解析设备 HTTP / RTSP 地址。 */
internal object LyLiveEndpointResolver {

    const val LIVE_START_ENDPOINT = "?custom=1&cmd=3001&par=1"
    /** 官方文档 RTSP 入口（与 VLC 一致）；ExoPlayer 内部 DESCRIBE 后 PLAY。 */
    private const val LIVE_RTSP_PATH = "xxx.mov"

    fun resolveHttpBaseUrl(
        wifiMode: GlassesConstant.WifiMode,
        productSeries: GlassesConstant.ProductSeries,
    ): String = when (wifiMode) {
        GlassesConstant.WifiMode.P2P_MODE -> DEVICE_WIFI_BASE_URL
        GlassesConstant.WifiMode.AP_MODE -> when (productSeries.lyApSyncBackend()) {
            GlassesConstant.LyApSyncBackend.AG66 -> DEVICE_WIFI_BASE_URL_AP_AG66
            GlassesConstant.LyApSyncBackend.AP19 -> DEVICE_WIFI_BASE_URL_AP19
        }
    }

    fun resolveRtspUrl(
        wifiMode: GlassesConstant.WifiMode,
        productSeries: GlassesConstant.ProductSeries,
    ): String {
        val host = resolveRtspHost(wifiMode, productSeries)
        return "rtsp://$host/$LIVE_RTSP_PATH"
    }

    fun resolveRtspHost(
        wifiMode: GlassesConstant.WifiMode,
        productSeries: GlassesConstant.ProductSeries,
    ): String = resolveHost(wifiMode, productSeries)

    private fun resolveHost(
        wifiMode: GlassesConstant.WifiMode,
        productSeries: GlassesConstant.ProductSeries,
    ): String {
        val baseUrl = resolveHttpBaseUrl(wifiMode, productSeries)
        return URI(baseUrl).host ?: "192.168.1.254"
    }
}
