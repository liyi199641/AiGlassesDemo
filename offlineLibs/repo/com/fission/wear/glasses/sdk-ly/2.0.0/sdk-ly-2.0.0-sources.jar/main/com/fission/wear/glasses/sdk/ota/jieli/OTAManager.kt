package com.fission.wear.glasses.sdk.ota.jieli

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.content.Context
import com.blankj.utilcode.util.StringUtils
import com.fission.wear.glasses.sdk.GlassesManage
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.events.BleRawDataEvent
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.events.OTAEvent
import com.fission.wear.glasses.sdk.events.ScanStateEvent
import com.fission.wear.glasses.sdk.manager.BleManager
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.jieli.jl_bt_ota.constant.ErrorCode
import com.jieli.jl_bt_ota.constant.StateCode
import com.jieli.jl_bt_ota.impl.BluetoothOTAManager
import com.jieli.jl_bt_ota.impl.RcspAuth
import com.jieli.jl_bt_ota.interfaces.IActionCallback
import com.jieli.jl_bt_ota.interfaces.IBluetoothCallback
import com.jieli.jl_bt_ota.interfaces.IUpgradeCallback
import com.jieli.jl_bt_ota.model.BleScanMessage
import com.jieli.jl_bt_ota.model.BluetoothOTAConfigure
import com.jieli.jl_bt_ota.model.base.BaseError
import com.jieli.jl_bt_ota.model.base.CommandBase
import com.jieli.jl_bt_ota.model.response.TargetInfoResponse
import com.jieli.jl_bt_ota.util.BluetoothUtil
import com.jieli.jl_bt_ota.util.CHexConver
import com.polidea.rxandroidble3.scan.ScanFilter
import com.polidea.rxandroidble3.scan.ScanSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicReference

class OTAManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val filePath:String,
    private val eventBus: MutableSharedFlow<GlassesEvent>,
) : BluetoothOTAManager(context) {
    private companion object {
        /** OTA 模式 MAC 切换后，外层重连次数（BleDeviceManager 内部另有 GATT 重试） */
        const val MAX_OTA_RECONNECT_ATTEMPTS = 5
        const val OTA_RECONNECT_DELAY_MS = 2_000L
        const val OTA_RECONNECT_SETTLE_MS = 500L
    }

    private val TAG = "GlassesOTAManager"
    private var bluetoothDevice: BluetoothDevice? = null
    private var macAddress: String? = null
    /** OTA MAC 切换阶段，避免断开正常 MAC 时误触发重连 */
    @Volatile
    private var otaMacReconnectPhase = OtaMacReconnectPhase.NONE
    private val managerJob = SupervisorJob()
    private val managerScope = scope + managerJob
    private var lastProgress = -1
    private val lastConnectionState = AtomicReference<ConnectionStateEvent?>(null)
    private val connectionMutex = Mutex()
    @Volatile
    private var otaFailureReported = false
    @Volatile
    private var otaReconnectAttempt = 0
    private var otaReconnectJob: Job? = null

    private enum class OtaMacReconnectPhase {
        /** 正常 MAC 上校验/传输前 */
        NONE,
        /** 已断开正常 MAC，扫描等待 MAC+1 广播 */
        AWAITING_OTA_MAC,
        /** 正在连接 MAC+1 */
        CONNECTING_OTA_MAC,
        /** 已连上 MAC+1，OTA 传输中 */
        OTA_MAC_ACTIVE,
    }

    private val onIBluetoothCallback = object : IBluetoothCallback {
        override fun onAdapterStatus(p0: Boolean, p1: Boolean) {

        }

        override fun onDiscoveryStatus(p0: Boolean, p1: Boolean) {

        }

        override fun onDiscovery(
            p0: BluetoothDevice?,
            p1: BleScanMessage?
        ) {

        }

        override fun onBleDataBlockChanged(
            p0: BluetoothDevice?,
            p1: Int,
            p2: Int
        ) {

        }

        override fun onBtDeviceConnection(p0: BluetoothDevice?, p1: Int) {
//            FissionLogUtils.d(TAG, "onBtDeviceConnection 设备连接状态：$p1")

        }

        override fun onConnection(p0: BluetoothDevice?, status: Int) {
            FissionLogUtils.i(
                TAG,
                "onConnection status=$status isOta=$isOTA address=${p0?.address}"
            )
            when (status) {
                StateCode.CONNECTION_OK if !isOTA    -> {
                    lastProgress = -1
                    bluetoothOption.firmwareFilePath = filePath
                    startOTA(otaCallback)
                }
                StateCode.CONNECTION_FAILED if isOTA &&
                    (otaMacReconnectPhase == OtaMacReconnectPhase.CONNECTING_OTA_MAC ||
                        otaMacReconnectPhase == OtaMacReconnectPhase.OTA_MAC_ACTIVE) -> {
                    scheduleOtaReconnect("OTA reconnect failed")
                }
            }
//            if (status == StateCode.CONNECTION_OK){
//                lastProgress = -1
//                bluetoothOption.firmwareFilePath = filePath
//                startOTA(otaCallback)
//            }

//            if (status == StateCode.CONNECTION_OK){//OTA初始化成功
//                if(isOTA) return //如果已经在OTA流程，则不需要处理
//                queryMandatoryUpdate(object : IActionCallback<TargetInfoResponse> {
//                    override fun onSuccess(deviceInfo: TargetInfoResponse?) {
//                        //设备处于强制升级模式，请跳转到OTA界面，引导用户升级固件
//                    }
//
//                    override fun onError(baseError: BaseError?) {
//                        //可以不用处理，也可以获取设备信息
//                        //没有错误，设备处于正常模式，可以获取设备信息
//                        if (baseError?.code == ErrorCode.ERR_NONE && baseError.subCode == ErrorCode.ERR_NONE) {
//                            val deviceInfo: TargetInfoResponse = getDeviceInfo()
//                            deviceInfo.versionCode //设备版本号
//                            deviceInfo.versionName //设备版本名
//                            deviceInfo.projectCode //设备产品ID(默认是0，如果设备支持会改变)
//                            //需要看固件是否支持
//                            deviceInfo.uid //客户ID
//                            deviceInfo.pid //产品ID
//                            //进行步骤2
//                        }
//                    }
//
//                })
//            }
        }

        override fun onReceiveCommand(
            p0: BluetoothDevice?,
            p1: CommandBase<*, *>?
        ) {

        }

        override fun onA2dpStatus(p0: BluetoothDevice?, p1: Int) {

        }

        override fun onHfpStatus(p0: BluetoothDevice?, p1: Int) {

        }

        override fun onMandatoryUpgrade(p0: BluetoothDevice?) {

        }

        override fun onError(error: BaseError?) {
            error ?: return
            FissionLogUtils.e(
                TAG,
                "onIBluetoothCallback onError: code=${error.code} subCode=${error.subCode} msg=${error.message}"
            )
            reportOtaFailure(error.message ?: "OTA error", error.code)
        }

    }
    private fun emitEvent(event: GlassesEvent) {
        managerScope.launch {
            eventBus.emit(event)
        }
    }

    init {
        managerScope.launch {
            eventBus
                    .buffer(Channel.BUFFERED)
                    .collect { event ->
                        handleEvent(event)
                    }
        }

        bluetoothOption.setPriority(BluetoothOTAConfigure.PREFER_BLE) //请按照项目需要选择
            .setUseAuthDevice(true) //具体根据固件的配置选择
            .setBleIntervalMs(500) //默认是500毫秒
            .setTimeoutMs(3000) //命令超时时间
            .setMtu(500) //BLE底层通讯MTU值，会影响BLE传输数据的速率。建议用500 或者 270。该MTU值会使OTA库在BLE连接时改变MTU，所以用户SDK需要对此处理。
            .setNeedChangeMtu(false)
            .isUseReconnect = true //是否自定义回连方式，默认为false，走SDK默认回连方式，客户可以根据需求进行变更
        configure(bluetoothOption)
        RcspAuth.setAuthTimeout(5000)
        registerBluetoothCallback(onIBluetoothCallback)
    }

    private suspend fun handleConnectionEvent(event: ConnectionStateEvent) {
        connectionMutex.withLock {

            val last = lastConnectionState.get()
            if(last == event){return}
            lastConnectionState.set(event)

            when (event) {
                is ConnectionStateEvent.Connected -> {
                    val connectedMac = BleManager.currentDeviceManager?.rxBleDevice?.macAddress
                    val targetMac = macAddress
                    if (targetMac != null && connectedMac != null &&
                        !StringUtils.equals(connectedMac, targetMac)
                    ) {
                        FissionLogUtils.w(
                            TAG,
                            "忽略非 OTA MAC 的连接成功: connected=$connectedMac target=$targetMac"
                        )
                        return
                    }

                    FissionLogUtils.i(TAG, "设备连接状态：Connected  hash=${System.identityHashCode(this)}")
                    if (targetMac != null) {
                        otaMacReconnectPhase = OtaMacReconnectPhase.OTA_MAC_ACTIVE
                    }
                    otaReconnectAttempt = 0
                    otaReconnectJob?.cancel()
                    otaReconnectJob = null

                    bluetoothDevice =
                        BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice

                    onBtDeviceConnection(
                        bluetoothDevice,
                        StateCode.CONNECTION_OK
                    )
                }

                is ConnectionStateEvent.Connecting -> {
                    val connectingMac = BleManager.currentDeviceManager?.rxBleDevice?.macAddress
                    val targetMac = macAddress
                    if (targetMac != null && connectingMac != null &&
                        !StringUtils.equals(connectingMac, targetMac)
                    ) {
                        return
                    }
                    if (targetMac != null &&
                        otaMacReconnectPhase == OtaMacReconnectPhase.AWAITING_OTA_MAC
                    ) {
                        otaMacReconnectPhase = OtaMacReconnectPhase.CONNECTING_OTA_MAC
                    }

                    FissionLogUtils.i(TAG, "设备连接状态： Connecting  hash=${System.identityHashCode(this)}")

                    onBtDeviceConnection(
                        bluetoothDevice,
                        StateCode.CONNECTION_CONNECTING
                    )
                }

                is ConnectionStateEvent.Disconnected -> {
                    FissionLogUtils.i(
                        TAG,
                        "设备连接状态：Disconnected phase=$otaMacReconnectPhase hash=${System.identityHashCode(this)}"
                    )

                    // 校验完成后断开正常 MAC、等待 MAC+1 广播，属于预期流程，不通知杰理也不重连
                    if (otaMacReconnectPhase == OtaMacReconnectPhase.AWAITING_OTA_MAC) {
                        return
                    }

                    onBtDeviceConnection(
                        bluetoothDevice,
                        StateCode.CONNECTION_DISCONNECT
                    )

                    if (otaMacReconnectPhase == OtaMacReconnectPhase.OTA_MAC_ACTIVE) {
                        otaMacReconnectPhase = OtaMacReconnectPhase.CONNECTING_OTA_MAC
                        scheduleOtaReconnect("OTA MAC disconnected unexpectedly")
                    } else if (macAddress == null) {
                        BleManager.disconnect()
                    }
                }

                is ConnectionStateEvent.Failed -> {
                    FissionLogUtils.e(
                        TAG,
                        "设备连接失败：${event.error.message} phase=$otaMacReconnectPhase targetMac=$macAddress"
                    )
                    // 仅 MAC+1 连接失败时才重试；断开正常 MAC 或扫描等待阶段忽略
                    if (otaMacReconnectPhase == OtaMacReconnectPhase.CONNECTING_OTA_MAC &&
                        macAddress != null
                    ) {
                        scheduleOtaReconnect(
                            event.error.message ?: "BLE GATT connection failed"
                        )
                    }
                }

                else -> {}
            }
        }
    }

    private fun scheduleOtaReconnect(reason: String) {
        if (otaFailureReported) return

        val targetMac = macAddress
        if (targetMac.isNullOrEmpty()) {
            reportOtaConnectionFailure(reason, ErrorCode.SUB_ERR_RECONNECT_FAILED)
            return
        }

        if (otaReconnectAttempt >= MAX_OTA_RECONNECT_ATTEMPTS) {
            reportOtaConnectionFailure(
                "$reason (已重试 $MAX_OTA_RECONNECT_ATTEMPTS 次)",
                ErrorCode.SUB_ERR_RECONNECT_FAILED
            )
            return
        }

        otaReconnectAttempt++
        otaMacReconnectPhase = OtaMacReconnectPhase.AWAITING_OTA_MAC
        FissionLogUtils.w(
            TAG,
            "MAC+1 连接失败，${OTA_RECONNECT_DELAY_MS}ms 后重连 " +
                "($otaReconnectAttempt/$MAX_OTA_RECONNECT_ATTEMPTS): $reason target=$targetMac"
        )

        otaReconnectJob?.cancel()
        otaReconnectJob = managerScope.launch {
            delay(OTA_RECONNECT_DELAY_MS)
            if (otaFailureReported) return@launch

            GlassesManage.stopScanBleDevices(context)
            BleManager.disconnect()
            delay(OTA_RECONNECT_SETTLE_MS)
            if (otaFailureReported) return@launch

            FissionLogUtils.i(TAG, "OTA 重连：重新扫描 MAC+1 设备 $targetMac")
            startOtaDeviceScan()
        }
    }

    private fun startOtaDeviceScan() {
        GlassesManage.startScanBleDevices(
            context = context,
            bleScanConfig = null,
            scanSettings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                .build(),
            scanFilters = arrayOf(ScanFilter.Builder().build())
        )
    }

    private fun reportOtaConnectionFailure(reason: String, code: Int) {
        if (otaFailureReported) return
        otaFailureReported = true
        otaReconnectJob?.cancel()
        otaReconnectJob = null
        macAddress = null
        otaMacReconnectPhase = OtaMacReconnectPhase.NONE
        otaReconnectAttempt = 0
        GlassesManage.stopScanBleDevices(context)
        bluetoothDevice = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice
        onBtDeviceConnection(bluetoothDevice, StateCode.CONNECTION_FAILED)
        emitEvent(OTAEvent.Failed(reason, code))
    }

    private fun reportOtaFailure(reason: String, code: Int) {
        if (otaFailureReported) return
        otaFailureReported = true
        otaReconnectJob?.cancel()
        otaReconnectJob = null
        otaReconnectAttempt = 0
        macAddress = null
        otaMacReconnectPhase = OtaMacReconnectPhase.NONE
        GlassesManage.stopScanBleDevices(context)
        emitEvent(OTAEvent.Failed(reason, code))
    }
    private suspend fun handleEvent(event: GlassesEvent) {
        when (event) {

            is ConnectionStateEvent -> handleConnectionEvent(event)

            is BleRawDataEvent.OTAData -> {
                super.onReceiveDeviceData(bluetoothDevice, event.data.toByteArray())
            }

            is ScanStateEvent.DeviceFound -> handleDeviceFound(event)

            is ScanStateEvent.Error -> {
                if (otaMacReconnectPhase == OtaMacReconnectPhase.AWAITING_OTA_MAC &&
                    !macAddress.isNullOrEmpty()
                ) {
                    FissionLogUtils.e(TAG, "OTA 扫描失败：${event.throwable.message}")
                    scheduleOtaReconnect(
                        event.throwable.message ?: "OTA device scan failed"
                    )
                }
            }

            else -> {}
        }
    }
    private suspend fun handleDeviceFound(event: ScanStateEvent.DeviceFound) {

        if (!StringUtils.isEmpty(macAddress) &&
            StringUtils.equals(event.data.bleDevice.macAddress, macAddress)
        ) {

            GlassesManage.stopScanBleDevices(context)
            otaMacReconnectPhase = OtaMacReconnectPhase.CONNECTING_OTA_MAC

            withContext(Dispatchers.Main) {
                FissionLogUtils.i(TAG, "扫描到 MAC+1，开始连接 ${macAddress}...")

                BleManager.connectDevice(
                    context,
                    macAddress!!,
                    scope,
                    eventBus,
                    true
                )
            }
        }
    }

    suspend fun startOTA(){
        if (!isOTA) {
            bluetoothDevice =
                BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice

            onBtDeviceConnection(
                bluetoothDevice,
                StateCode.CONNECTION_CONNECTING
            )

            delay(200)

            onBtDeviceConnection(
                bluetoothDevice,
                StateCode.CONNECTION_OK
            )
        }
    }


    override fun sendAuthDataToDevice(p0: BluetoothDevice?, p1: ByteArray?): Boolean {
        p1?.let {
            BleManager.sendOtaAuthData(it)
        }
        return true
    }

    override fun getConnectedDevice(): BluetoothDevice? {
//        FissionLogUtils.d(TAG,"getConnectedDevice 设备状态：" + BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice)
        return BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice
    }

    override fun getConnectedBluetoothGatt(): BluetoothGatt? {
        return null
    }

    override fun connectBluetoothDevice(p0: BluetoothDevice?) {
        FissionLogUtils.d(TAG,"connectBluetoothDevice: 设备蓝牙地址：${p0?.address}")
        p0?.let {
            BleManager.connectDevice(context, p0.address!!, scope, eventBus, true)
        }
    }

    override fun disconnectBluetoothDevice(p0: BluetoothDevice?) {
        FissionLogUtils.d(TAG,"disconnectBluetoothDevice: 设备蓝牙地址：${p0?.address}")
        BleManager.disconnect()
    }

    override fun onError(error: BaseError?) {
        super.onError(error)
        error ?: return
        FissionLogUtils.e(TAG, "onError: code=${error.code} subCode=${error.subCode} msg=${error.message}")
        reportOtaFailure(error.message ?: "OTA error", error.code)
    }

    override fun release() {
        super.release()
        FissionLogUtils.d(TAG,"release")
        otaReconnectJob?.cancel()
        otaReconnectJob = null
        unregisterBluetoothCallback(onIBluetoothCallback)
        managerScope.cancel()
    }

    override fun sendDataToDevice(
        p0: BluetoothDevice?,
        data: ByteArray?
    ): Boolean {
        data?.let {
            BleManager.sendOtaAuthData(it)
        }
        return true
    }

    private val otaCallback = object : IUpgradeCallback {
        override fun onStartOTA() {
            FissionLogUtils.d(TAG,"onStartOTA")
            otaFailureReported = false
            otaReconnectAttempt = 0
            emitEvent(OTAEvent.Start)
        }

        override fun onNeedReconnect(mac: String, isMacPlusOne: Boolean) {
            FissionLogUtils.d(TAG,"onNeedReconnect: mac:$mac ,isMacPlusOne: $isMacPlusOne ")
            bluetoothOption.isUseAuthDevice = true
            otaReconnectJob?.cancel()
            otaReconnectJob = null
            otaReconnectAttempt = 0
            lastProgress = -1

            // 1. 先确定 MAC+1，再断开正常 MAC，避免断开事件误触发重连
            val data = BluetoothUtil.addressCovertToByteArray(mac)
            val value = CHexConver.byteToInt(data[data.size - 1]) + 1
            data[data.size - 1] = CHexConver.intToByte(value)
            macAddress = BluetoothUtil.hexDataCovetToAddress(data)
            otaMacReconnectPhase = OtaMacReconnectPhase.AWAITING_OTA_MAC
            emitEvent(OTAEvent.EnterOTAMode(macAddress ?: ""))
            FissionLogUtils.d(TAG, "校验完成，切换 OTA MAC: $macAddress，断开正常 MAC")

            BleManager.currentDeviceManager?.disconnect()
            startOtaDeviceScan()
        }

        override fun onProgress(type: Int, progressPercent: Float) {
//            FissionLogUtils.d("onProgress:  type: $type  progressPercent: $progressPercent")
            val percent = progressPercent.toInt().coerceIn(0, 100)
            if (percent == lastProgress) return
            lastProgress = percent
            emitEvent(
                OTAEvent.Progress(
                    percent,
                    if (type == 0) GlassesConstant.OTAStage.VERIFY else GlassesConstant.OTAStage.OTA
                )
            )
        }

        override fun onStopOTA() {
            FissionLogUtils.d(TAG,"onStopOTA")
            macAddress = null
            otaMacReconnectPhase = OtaMacReconnectPhase.NONE
            lastProgress = -1
            emitEvent(OTAEvent.Success)
        }

        override fun onCancelOTA() {
            emitEvent(OTAEvent.Cancelled)
        }

        override fun onError(error: BaseError) {
            FissionLogUtils.e(TAG,"otaCallback onError:  code: ${error.code}  subCode: ${error.subCode}   opCode操作码: ${error.opCode}  message: ${error.message}")
            reportOtaFailure(error.message ?: "OTA error", error.code)
        }
    }

}