/**
 * @name LyWifiDownManager
 * @class name：com.fission.wear.glasses.sdk.manager
 * @author ly
 * @time 2026/3/30 15:35
 * @change
 * @chang time
 * @class describe
 */
package com.fission.wear.glasses.sdk.manager

import android.content.Context
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.constant.GlassesConstant.DEVICE_WIFI_BASE_URL
import com.fission.wear.glasses.sdk.constant.GlassesConstant.DEVICE_WIFI_BASE_URL_AP19
import com.fission.wear.glasses.sdk.constant.GlassesConstant.DEVICE_WIFI_BASE_URL_AP_AG66
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_DOWNLOAD_DELETE
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_DOWNLOAD_FAILED
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_DOWNLOAD_GET_FILE_LIST_FAILED
import com.fission.wear.glasses.sdk.data.repository.MediaRepository
import com.fission.wear.glasses.sdk.data.repository.XmlRetrofitClient
import com.fission.wear.glasses.sdk.events.CmdResultEvent
import com.fission.wear.glasses.sdk.events.FileSyncEvent
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean

class LyWifiDownloadManager(
    private val eventBus: MutableSharedFlow<GlassesEvent>,
    private val scope: CoroutineScope,
    private val wifiMode: GlassesConstant.WifiMode,
    private val productSeries: GlassesConstant.ProductSeries,
    /** 媒体文件保存根目录绝对路径（由 [com.fission.wear.glasses.sdk.config.SdkConfig.mediaFilesStorageDirName] 等解析得到）。 */
    private val mediaFilesSaveDirPath: String,
) {

    private var totalFileNum: Int = 0
    private var curFileNum: Int = 0
    private val downloadQueueMutex = Mutex()
    private var downloadJob: Job? = null
    private var fetchFileListJob: Job? = null
    private val workJob = SupervisorJob()
    private val workScope = CoroutineScope(scope.coroutineContext + workJob)
    private val wifiDisconnected = AtomicBoolean(false)
    private val wifiReleased = AtomicBoolean(false)
    private val syncAborted = AtomicBoolean(false)

    init {
        workScope.launch {
            eventBus.collect { event ->
                when (event) {
                    is FileSyncEvent.DownloadSuccess -> {
                        if (event.filePath.isNotBlank()) {//过滤列表为空的情况
                            curFileNum += 1
                            deleteMediaFileList(event.remoteUrl, isLastMedia = false)
                        }
                    }

                    is FileSyncEvent.BatchDownloadFinished -> {
                        disconnectWifiOnce()
                    }

                    is FileSyncEvent.Failed -> {
                        syncAborted.set(true)
                        downloadJob?.cancel()
                        workScope.launch { releaseWifiOnce() }
                    }

                    else -> {}
                }
            }
        }
    }

    private fun emitEvent(event: GlassesEvent) {
        workScope.launch {
            eventBus.emit(event)
        }
    }

    fun getMediaFileList(context: Context) {
//        downloadJob?.cancel()
//        downloadJob = null
        syncAborted.set(false)
        totalFileNum = 0
        curFileNum = 0
        when (wifiMode) {
            GlassesConstant.WifiMode.P2P_MODE -> getMediaFileListInP2P(context)
            GlassesConstant.WifiMode.AP_MODE -> when (productSeries.lyApSyncBackend()) {
                GlassesConstant.LyApSyncBackend.AP19 -> getMediaFileListInAp(context)
                GlassesConstant.LyApSyncBackend.AG66 ->
                    getMediaFileListInP2P(context, DEVICE_WIFI_BASE_URL_AP_AG66)
            }
        }
    }

    fun deleteMediaFileList(filePath: String,
                            isLastMedia: Boolean) {
        when (wifiMode) {
            GlassesConstant.WifiMode.P2P_MODE -> deleteMediaFileListInP2P(DEVICE_WIFI_BASE_URL, filePath, isLastMedia)
            GlassesConstant.WifiMode.AP_MODE -> when (productSeries.lyApSyncBackend()) {
                GlassesConstant.LyApSyncBackend.AP19 ->
                    deleteMediaFileListInAP(
                        DEVICE_WIFI_BASE_URL_AP19,
                        filePath.substringAfter(DEVICE_WIFI_BASE_URL_AP19),
                        isLastMedia,
                    )
                GlassesConstant.LyApSyncBackend.AG66 ->
                    deleteMediaFileListInP2P(DEVICE_WIFI_BASE_URL_AP_AG66, filePath, isLastMedia)
            }
        }
    }

    fun deleteMediaFileListInP2P(
        baseUrl: String,
        filePath: String,
        isLastMedia: Boolean,
    ) {
        workScope.launch(Dispatchers.IO) {
            try {
                val response = MediaRepository.deleteMediaFilesByXml(baseUrl, filePath)
                withContext(Dispatchers.Main) {
                    val response1 = XmlRetrofitClient.parseFunctionXml(response.string())
                    if (isLastMedia) {
                        disconnectWifiOnce()
                    }
                    FissionLogUtils.d("wl", "删除文件返回结果：${response1}")
                }
            } catch (e: Exception) {
                FissionLogUtils.d("wl", "删除文件失败：${e.message}")
                abortSync("删除文件失败", ERROR_CODE_DOWNLOAD_DELETE)
            }
        }
    }

    private fun disconnectWifiOnce() {
        if (!wifiDisconnected.compareAndSet(false, true)) return
        when (wifiMode) {
            GlassesConstant.WifiMode.AP_MODE -> WifiApConnectManager.disconnect()
            GlassesConstant.WifiMode.P2P_MODE -> WifiDirectManager.disconnect()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun getMediaFileListInP2P(
        context: Context,
        baseUrl: String = DEVICE_WIFI_BASE_URL,
    ) {
        fetchFileListJob?.cancel()
        fetchFileListJob = workScope.launch(Dispatchers.IO) {
            try {
                FissionLogUtils.d("准备获取文件数量")
                val files = suspendCancellableCoroutine { cont ->
                    val endpoint = "?custom=1&cmd=3015"
                    XmlRetrofitClient.fetchXml(baseUrl, endpoint) { fileList ->
                        if (cont.isActive) {
                            cont.resume(fileList) {}
                        }
                    }
                }
                totalFileNum = files.size
                curFileNum = 0
                FissionLogUtils.d("wl", "----getMediaFilesByXml----: ${files.size} 个文件")
                if (files.isEmpty()) {
                    abortSync("没有文件可下载", ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND)
                    return@launch
                }
                withContext(Dispatchers.Main) {
                    emitEvent(CmdResultEvent.MediaFileListByXml(files))
                    fetchThumbnailsThenDownload(context, baseUrl, files)
                }
            } catch (e: Exception) {
                abortSync(
                    "获取文件列表失败",
                    ERROR_CODE_DOWNLOAD_GET_FILE_LIST_FAILED
                )
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun getMediaFileListInAp(
        context: Context) {
        fetchFileListJob?.cancel()
        fetchFileListJob = workScope.launch(Dispatchers.IO) {
            try {
                FissionLogUtils.d("准备获取文件数量:AP")
                val files = suspendCancellableCoroutine { cont ->
                    val endpoint = "app/getfilelist"
                    XmlRetrofitClient.fetchXmlAp(DEVICE_WIFI_BASE_URL_AP19, endpoint) { fileList ->
                        if (cont.isActive) {
                            cont.resume(fileList) {}
                        }
                    }
                }
                totalFileNum = files.size
                curFileNum = 0
                FissionLogUtils.d("wl", "----getMediaFiles----: ${files.size} 个文件")
                files.forEachIndexed { index, fileInfo ->
                    FissionLogUtils.d("fileinfo", "----getMediaFiles----:  ${fileInfo.toString()}")
                }

                if (files.isEmpty()) {
                    abortSync("没有文件可下载", ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND)
                    return@launch
                }

                withContext(Dispatchers.Main) {
                    emitEvent(CmdResultEvent.MediaFileListByXml(files))
                    val downloadUrl = DEVICE_WIFI_BASE_URL_AP19.removeSuffix("/")
                    fetchAp19ThumbnailsThenDownload(context, downloadUrl, files)
                }
            } catch (e: Exception) {
                abortSync(
                    "获取文件列表失败",
                    ERROR_CODE_DOWNLOAD_GET_FILE_LIST_FAILED
                )
            }
        }
    }

    private fun deleteMediaFileListInAP(
        baseUrl: String,
        fileName: String,
        isLastMedia: Boolean,
    ) {
        workScope.launch(Dispatchers.IO) {
            try {
                val response = MediaRepository.deleteMediaFilesByXmlInAp(
                    baseUrl, URLEncoder.encode(fileName, "UTF-8").replace("%2F", "/")
                )
                withContext(Dispatchers.Main) {
                    val response1 = XmlRetrofitClient.parseFunctionXmlInAp(response.string())
                    if (isLastMedia) {
                        disconnectWifiOnce()
                    }
                    FissionLogUtils.d("wl", "删除文件返回结果：${response1}")
                }
            } catch (e: Exception) {
                FissionLogUtils.d("wl", "删除文件失败：${e.message}")
                abortSync("删除文件失败", ERROR_CODE_DOWNLOAD_DELETE)
            }
        }
    }

    /** P2P / AP(AG66) 设备媒体目录，与历史下载逻辑一致。 */
    private fun buildP2pDownloadBaseUrl(baseUrl: String): String {
        return baseUrl.removeSuffix("/") + "/DCIM/100HUNTI"
    }

    /** 缩略图 URL：`baseurl/DCIM/100HUNTI/文件名?custom=1&cmd=4001`。 */
    private fun buildP2PThumbnailUrl(baseUrl: String, fileName: String): String {
        val normalizedName = fileName.removePrefix("/")
        return "${buildP2pDownloadBaseUrl(baseUrl)}/$normalizedName?custom=1&cmd=4001"
    }

    /** AP19 缩略图 URL：`baseurl/app/getthumbnail?file=文件路径`（file 与下载参数一致）。 */
    private fun buildAp19ThumbnailUrl(baseUrl: String, fileName: String): String {
        val normalizedBase = baseUrl.removeSuffix("/")
        val normalizedFile = fileName.removePrefix("/")
        return "$normalizedBase/app/getthumbnail?file=$normalizedFile"
    }

    /** AP19 模式：先组装缩略图 URL 通知上层，再串行下载原文件。 */
    private fun fetchAp19ThumbnailsThenDownload(
        context: Context,
        downloadUrl: String,
        allFiles: List<XmlRetrofitClient.FileInfo>,
    ) {
        if (allFiles.isEmpty()) {
            abortSync("没有文件可下载", ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND)
            return
        }

        downloadJob?.cancel()
        downloadJob = workScope.launch(Dispatchers.IO) {
            downloadQueueMutex.withLock {
                val thumbnails = allFiles.mapIndexedNotNull { index, fileInfo ->
                    val fileName = fileInfo.name?.takeIf { it.isNotBlank() }
                        ?: return@mapIndexedNotNull null
                    val fpath = fileInfo.fpath?.takeIf { it.isNotBlank() } ?: fileName
                    val thumbnailUrl = buildAp19ThumbnailUrl(downloadUrl, fileName)
                    FissionLogUtils.d("LyWifiDownloadManager", "AP19 缩略图地址: $thumbnailUrl")
                    FileSyncEvent.ThumbnailItem(
                        fpath = fpath,
                        index = index,
                        thumbnailUrl = thumbnailUrl,
                    )
                }
                if (thumbnails.size != allFiles.size) {
                    abortSync("文件路径不完整", ERROR_CODE_DOWNLOAD_FAILED)
                    return@withLock
                }

                emitEvent(FileSyncEvent.ThumbnailsReady(thumbnails, allFiles.size))

                var successCount = 0
                for ((index, fileInfo) in allFiles.withIndex()) {
                    if (syncAborted.get()) break
                    try {
                        val fileName = fileInfo.name
                        if (fileName.isNullOrBlank()) {
                            abortSync("文件名为空", ERROR_CODE_DOWNLOAD_FAILED)
                            break
                        }
                        val currentFileType = when {
                            fileName.endsWith(".jpg", ignoreCase = true)  -> 0
                            fileName.endsWith(".mp4", ignoreCase = true)  -> 1
                            fileName.endsWith(".opus", ignoreCase = true) -> 2
                            else                                          -> -1
                        }
                        FissionLogUtils.d("LyWifiDownloadManager", "AP19 下载地址: $downloadUrl/$fileName")
                        val downloadResult = MediaRepository.downloadFile(
                            downloadUrl,
                            fileName,
                            context,
                            currentFileType,
                            mediaFilesSaveDirPath,
                            scope,
                            eventBus,
                            index,
                            allFiles.size,
                            fileInfo,
                            emitFailureEvent = false,
                        )
                        when (downloadResult) {
                            is MediaRepository.DownloadFileResult.Success -> successCount += 1
                            is MediaRepository.DownloadFileResult.Skipped -> {
                                FissionLogUtils.w("LyWifiDownloadManager", "跳过无效文件: $fileName")
                                emitDownloadSkipped(index, allFiles.size, fileInfo.fpath ?: fileName)
                            }
                            is MediaRepository.DownloadFileResult.Failed -> {
                                abortSync(
                                    "下载文件失败:$fileName",
                                    ERROR_CODE_DOWNLOAD_FAILED
                                )
                                break
                            }
                        }
                        if (syncAborted.get()) break
                    } catch (e: Exception) {
                        FissionLogUtils.d("LyWifiDownloadManager", "AP19 下载文件流程失败: ${e.message}")
                        abortSync(
                            "下载文件流程失败:${e.message}",
                            ERROR_CODE_DOWNLOAD_FAILED
                        )
                        break
                    }
                }
                if (!syncAborted.get()) {
                    delay(200)
                    emitBatchDownloadFinished(successCount, allFiles.size)
                }
            }
        }
    }

    /** P2P / AP(AG66) 模式：先组装缩略图 URL 通知上层，再串行下载原文件。 */
    private fun fetchThumbnailsThenDownload(
        context: Context,
        baseUrl: String,
        allFiles: List<XmlRetrofitClient.FileInfo>,
    ) {
        if (allFiles.isEmpty()) {
            abortSync("没有文件可下载", ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND)
            return
        }

        val downloadUrl = buildP2pDownloadBaseUrl(baseUrl)

        downloadJob?.cancel()
        downloadJob = workScope.launch(Dispatchers.IO) {
            downloadQueueMutex.withLock {
                val thumbnails = allFiles.mapIndexedNotNull { index, fileInfo ->
                    val fpath = fileInfo.fpath?.takeIf { it.isNotBlank() }
                        ?: return@mapIndexedNotNull null
                    val fileName = fileInfo.name?.takeIf { it.isNotBlank() }
                        ?: return@mapIndexedNotNull null
                    val thumbnailUrl = buildP2PThumbnailUrl(baseUrl, fileName)
                    FissionLogUtils.d("LyWifiDownloadManager", "缩略图地址: $thumbnailUrl")
                    FileSyncEvent.ThumbnailItem(
                        fpath = fpath,
                        index = index,
                        thumbnailUrl = thumbnailUrl,
                    )
                }
                if (thumbnails.size != allFiles.size) {
                    abortSync("文件路径不完整", ERROR_CODE_DOWNLOAD_FAILED)
                    return@withLock
                }

                emitEvent(FileSyncEvent.ThumbnailsReady(thumbnails, allFiles.size))

                var successCount = 0
                for ((index, fileInfo) in allFiles.withIndex()) {
                    if (syncAborted.get()) break
                    try {
                        val fileName = fileInfo.name
                        if (fileName.isNullOrBlank()) {
                            abortSync(
                                "文件名为空",
                                ERROR_CODE_DOWNLOAD_FAILED
                            )
                            break
                        }
                        val currentFileType = when {
                            fileName.endsWith(".jpg", ignoreCase = true)  -> 0
                            fileName.endsWith(".mp4", ignoreCase = true)  -> 1
                            fileName.endsWith(".opus", ignoreCase = true) -> 2
                            else                                          -> -1
                        }
                        FissionLogUtils.d("LyWifiDownloadManager", "下载地址: $downloadUrl/$fileName")
                        val downloadResult = MediaRepository.downloadFile(
                            downloadUrl,
                            fileName,
                            context,
                            currentFileType,
                            mediaFilesSaveDirPath,
                            scope,
                            eventBus,
                            index,
                            allFiles.size,
                            fileInfo,
                            emitFailureEvent = false,
                        )
                        when (downloadResult) {
                            is MediaRepository.DownloadFileResult.Success -> successCount += 1
                            is MediaRepository.DownloadFileResult.Skipped -> {
                                FissionLogUtils.w("LyWifiDownloadManager", "跳过无效文件: ${fileInfo.name}")
                                emitDownloadSkipped(index, allFiles.size, fileInfo.fpath ?: fileName)
                            }
                            is MediaRepository.DownloadFileResult.Failed -> {
                                abortSync(
                                    "下载文件失败:${fileInfo.name}",
                                    ERROR_CODE_DOWNLOAD_FAILED
                                )
                                break
                            }
                        }
                    } catch (e: Exception) {
                        FissionLogUtils.d("LyWifiDownloadManager", "下载文件流程失败: ${e.message}")
                        abortSync(
                            "下载文件流程失败:${e.message}",
                            ERROR_CODE_DOWNLOAD_FAILED
                        )
                        break
                    }
                }
                if (!syncAborted.get()) {
                    delay(200)
                    emitBatchDownloadFinished(successCount, allFiles.size)
                }
            }
        }
    }

    private fun emitDownloadSkipped(curFileIndex: Int, totalFileCount: Int, fpath: String) {
        emitEvent(
            FileSyncEvent.DownloadSkipped(
                curFileIndex = curFileIndex,
                totalFileCount = totalFileCount,
                fpath = fpath,
            )
        )
    }

    private fun emitBatchDownloadFinished(successCount: Int, totalFileCount: Int) {
        emitEvent(
            FileSyncEvent.BatchDownloadFinished(
                successCount = successCount,
                totalFileCount = totalFileCount,
            )
        )
    }

    private fun abortSync(reason: String, code: Int) {
        if (!syncAborted.compareAndSet(false, true)) return
        downloadJob?.cancel()
        emitEvent(FileSyncEvent.Failed(reason, code))
    }

    fun release() {
        workJob.cancel()
        downloadJob = null
        fetchFileListJob = null
        curFileNum = 0
        totalFileNum = 0
    }

    fun getCurFileNum(): Pair<Int, Int> {
        val result = Pair(curFileNum, totalFileNum)
        curFileNum = 0
        totalFileNum = 0
        return result
    }


    private suspend fun releaseWifiOnce() {
        if (!wifiReleased.compareAndSet(false, true)) return
        delay(1000)//延迟一秒给设备删除媒体资源
        WifiDirectManager.release()
        WifiApConnectManager.release()
    }

}