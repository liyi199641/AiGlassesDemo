package com.fission.wear.glasses.sdk.ota.ly

import android.net.Network
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.manager.WifiApConnectManager
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

/**
 * LY T 系列 ISP OTA：Wi-Fi 连接后通过 TCP 协议升级。
 *
 * 协议（ip=192.168.169.1, port=5007）：
 * 1. App 发送 `A0`
 * 2. 设备回复 `A1 00 00 00 00 00 00 00 00`
 * 3. App 发送 20 字节：前 16 字节保留，后 4 字节为文件大小（小端）
 * 4. App 发送固件文件
 * 5. 设备回复 `Upgrade_ok` / `Upgrade_err`；无需 App 关机，仅记录状态
 *
 * S 系列仍使用 [com.fission.wear.glasses.sdk.data.repository.MediaRepository.uploadOtaFile]。
 */
object LyIspTcpOtaClient {

    private const val TAG = "LyIspTcpOtaClient"
    private const val HOST = "192.168.169.1"
    private const val PORT = 5007
    private const val CONNECT_TIMEOUT_MS = 10_000
    private const val SO_TIMEOUT_MS = 120_000
    private const val CHUNK_SIZE = 64 * 1024

    private val CMD_START = byteArrayOf(0xA0.toByte())
    private val ACK_READY = byteArrayOf(
        0xA1.toByte(), 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    )
    private const val RESULT_OK = "Upgrade_ok"
    private const val RESULT_ERR = "Upgrade_err"

    sealed class Result {
        data object Success : Result()
        data class Failed(val reason: String, val code: Int) : Result()
    }

    suspend fun upload(
        file: File,
        onProgress: (Int) -> Unit,
        onFileUploaded: (() -> Unit)? = null,
    ): Result = withContext(Dispatchers.IO) {
        if (!file.exists() || !file.isFile) {
            return@withContext Result.Failed(
                "OTA 文件不存在",
                GlassesConstant.ERROR_CODE_OTA_FILE_NOT_FOUND
            )
        }
        val fileSize = file.length()
        if (fileSize <= 0L) {
            return@withContext Result.Failed(
                "OTA 文件大小无效",
                GlassesConstant.ERROR_CODE_OTA_TRANSFER_FAILED
            )
        }

        val network: Network? = WifiApConnectManager.getBoundApNetwork()
        FissionLogUtils.i(
            TAG,
            "开始 ISP TCP OTA host=$HOST:$PORT size=$fileSize network=$network"
        )

        var socket: Socket? = null
        try {
            socket = (network?.socketFactory?.createSocket() ?: Socket()).apply {
                soTimeout = SO_TIMEOUT_MS
                tcpNoDelay = true
                connect(InetSocketAddress(HOST, PORT), CONNECT_TIMEOUT_MS)
            }
            val input = DataInputStream(BufferedInputStream(socket.getInputStream()))
            val output = BufferedOutputStream(socket.getOutputStream())

            // 2/3. 发送 A0，等待 A1 应答
            output.write(CMD_START)
            output.flush()
            val ack = ByteArray(ACK_READY.size)
            input.readFully(ack)
            if (!ack.contentEquals(ACK_READY)) {
                val hex = ack.joinToString(" ") { "%02X".format(it) }
                FissionLogUtils.e(TAG, "设备握手应答异常: $hex")
                return@withContext Result.Failed(
                    "ISP OTA 握手失败",
                    GlassesConstant.ERROR_CODE_OTA_HANDSHAKE_FAILED
                )
            }
            FissionLogUtils.d(TAG, "收到设备握手应答 A1")

            // 4. 20 字节：16 保留 + 4 文件大小小端
            val header = ByteArray(20)
            ByteBuffer.wrap(header, 16, 4)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putInt(fileSize.toInt())
            output.write(header)
            output.flush()
            FissionLogUtils.d(
                TAG,
                "已发送文件头 size=${fileSize.toInt()} header=${header.joinToString(" ") { "%02X".format(it) }}"
            )

            // 5. 发送固件文件
            var sent = 0L
            var lastProgress = -1
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(CHUNK_SIZE)
                while (isActive) {
                    val read = fis.read(buffer)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                    sent += read
                    val progress = ((sent * 100) / fileSize).toInt().coerceIn(0, 99)
                    if (progress != lastProgress) {
                        lastProgress = progress
                        onProgress(progress)
                    }
                }
            }
            output.flush()
            FissionLogUtils.i(TAG, "固件发送完成 sent=$sent，等待升级结果")
            onFileUploaded?.invoke()

            // 6. 等待 Upgrade_ok / Upgrade_err
            val resultText = readAsciiResult(input)
            FissionLogUtils.i(TAG, "设备升级结果: $resultText")
            return@withContext when {
                resultText.contains(RESULT_OK) -> {
                    onProgress(100)
                    Result.Success
                }
                resultText.contains(RESULT_ERR) -> Result.Failed(
                    "ISP升级失败",
                    GlassesConstant.ERROR_CODE_OTA_UPGRADE_FAILED
                )
                else -> Result.Failed(
                    "未知升级结果: $resultText",
                    GlassesConstant.ERROR_CODE_OTA_UPGRADE_FAILED
                )
            }
        } catch (e: Exception) {
            FissionLogUtils.e(TAG, "ISP TCP OTA 异常: ${e.message}")
            Result.Failed(
                e.message ?: "ISP OTA 传输失败",
                GlassesConstant.ERROR_CODE_OTA_TRANSFER_FAILED
            )
        } finally {
            runCatching { socket?.close() }
        }
    }

    private fun readAsciiResult(input: DataInputStream): String {
        val buffer = ByteArray(64)
        val builder = StringBuilder()
        while (builder.length < 64) {
            val read = input.read(buffer)
            if (read <= 0) break
            builder.append(String(buffer, 0, read, StandardCharsets.US_ASCII))
            val text = builder.toString()
            if (text.contains(RESULT_OK) || text.contains(RESULT_ERR)) {
                return text.trim()
            }
        }
        return builder.toString().trim()
    }
}
