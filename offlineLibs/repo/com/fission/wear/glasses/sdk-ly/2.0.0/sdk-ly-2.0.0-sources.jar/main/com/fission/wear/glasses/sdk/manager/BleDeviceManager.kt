package com.fission.wear.glasses.sdk.manager

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import com.fission.wear.glasses.sdk.events.BleRawDataEvent
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.manager.BleDeviceManager.Companion.GATT_CHECK_INTERVAL_MS
import com.fission.wear.glasses.sdk.manager.BleDeviceManager.Companion.GATT_COOLDOWN_MS
import com.fission.wear.glasses.sdk.manager.BleDeviceManager.Companion.GATT_READY_TIMEOUT_MS
import com.fission.wear.glasses.sdk.util.BlePacketUtils.bytesToHex
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.jieli.jl_bt_ota.constant.BluetoothConstant
import com.polidea.rxandroidble3.RxBleConnection
import com.polidea.rxandroidble3.RxBleDevice
import com.polidea.rxandroidble3.RxBlePhy
import com.polidea.rxandroidble3.RxBlePhyOption
import io.reactivex.rxjava3.core.Completable
import io.reactivex.rxjava3.core.Observable
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.disposables.Disposable
import io.reactivex.rxjava3.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Queue
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.cancellation.CancellationException
import kotlin.experimental.and
import kotlin.math.pow

/**
 * describe: BLE设备管理，支持MTU协商和自动分包
 * author: wl
 * createTime: 2025/9/9
 */
fun Disposable.addTo(compositeDisposable: CompositeDisposable) {
    compositeDisposable.add(this)
}

class BleDeviceManager(
    context: Context,
    macAddress: String,
    private val scope: CoroutineScope,
    private val eventBus: MutableSharedFlow<GlassesEvent>
) {
    private val appContext = context.applicationContext

    private val bluetoothManager =
        appContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager

    companion object {
        /** 后台 PHY 切换超时，避免部分机型 GATT PHY_UPDATE 阻塞约 30s */
        private const val PHY_OPERATION_TIMEOUT_SEC = 5L
        /** 服务发现 / 通知订阅超时，部分 OEM 解绑后重连较慢 */
        private const val GATT_SETUP_TIMEOUT_SEC = 15L
        /** 连接建立后等待栈稳定，iQOO/Vivo 等机型需要 */
        private const val CONNECTION_SETTLE_MS = 600L
        /** GATT 配置失败后完整重连间隔 */
        private const val FULL_RECONNECT_DELAY_MS = 2_000L
        private const val MAX_FULL_CONNECTION_RETRIES = 3

        // App 重启后，等待旧 GATT 从系统层释放
        private const val GATT_READY_TIMEOUT_MS = 3_000L

        // 每次检查间隔
        private const val GATT_CHECK_INTERVAL_MS = 200L

        // 确认 GATT 已断开后，再给 Bluetooth Stack 一点稳定时间
        private const val GATT_COOLDOWN_MS = 500L
    }

    private data class WriteRequest(val uuid: UUID, val data: ByteArray)

    private val rxBleClient = RxBleClientProvider.get(context)
    val rxBleDevice: RxBleDevice = rxBleClient.getBleDevice(macAddress)

    @Volatile
    private var isDisconnectingIntentionally = false
    private var disposables = CompositeDisposable()
    private val notificationDisposables = CompositeDisposable()

    @Volatile
    private var reconnectAttempt = 0

    @Volatile
    var bleConnection: RxBleConnection? = null
    @Volatile
    private var isOtaMode: Boolean = false
    private val writeQueue: Queue<WriteRequest> = ConcurrentLinkedQueue()
    private val isWriting = AtomicBoolean(false)
    var mtu: Int = 23 // 默认值，未协商前是23

    fun isOtaMode(): Boolean = isOtaMode

    /** OTA 进行中切换模式，无需重连 BLE。 */
    fun enterOtaMode() {
        isOtaMode = true
    }

    fun exitOtaMode() {
        isOtaMode = false
    }

    // 普通通知UUID
    private val notifyUUID = UUID.fromString("0000AA14-0000-1000-8000-00805F9B34FB")

    // 图片数据通知UUID
    private val imageNotifyUUID = UUID.fromString("0000AA15-0000-1000-8000-00805F9B34FB")

    // 写入UUID
    private val writeUUID = UUID.fromString("0000AA13-0000-1000-8000-00805F9B34FB")

    //OTA 设备认证UUID
    private val otaServiceUUID = BluetoothConstant.UUID_SERVICE;
    private val otaWriteUUID = BluetoothConstant.UUID_WRITE
    private val otaNotificationUUID = BluetoothConstant.UUID_NOTIFICATION
    private var connectStateJob: Job? = null

    private fun emitEvent(event: GlassesEvent) {
        connectStateJob =  scope.launch {
            eventBus.emit(event)
        }
    }

    @Volatile
    private var isWaitingGattReady = false

    private var waitGattJob: Job? = null

    @SuppressLint("Range")
    fun connect(isOtaMode: Boolean = false) {
        this.isOtaMode = isOtaMode
        isDisconnectingIntentionally = false
        reconnectAttempt = 0

        waitGattReadyAndConnect(isOtaMode)
    }

    @SuppressLint("MissingPermission")
    private fun waitGattReadyAndConnect(isOtaMode: Boolean) {

        if (isWaitingGattReady) {
            FissionLogUtils.w(
                "BleDeviceManager",
                "已经存在 GATT Ready 等待流程，忽略重复 connect()"
            )
            return
        }

        waitGattJob?.cancel()

        isWaitingGattReady = true

        waitGattJob = scope.launch {

            try {
                val device = rxBleDevice.bluetoothDevice

                val deadline =
                    System.currentTimeMillis() + GATT_READY_TIMEOUT_MS

                FissionLogUtils.d(
                    "BleDeviceManager",
                    "开始等待 GATT Ready: ${device.address}"
                )

                while (isActive) {

                    if (isDisconnectingIntentionally) {
                        return@launch
                    }

                    val connectedDevices =
                        bluetoothManager.getConnectedDevices(
                            BluetoothProfile.GATT
                        )

                    val gattConnected = connectedDevices.any {
                        it.address.equals(
                            device.address,
                            ignoreCase = true
                        )
                    }

                    if (!gattConnected) {

                        FissionLogUtils.d(
                            "BleDeviceManager",
                            "目标设备已经不在 GATT Connected 列表中"
                        )

                        /*
                         * 非常重要：
                         *
                         * getConnectedDevices() == DISCONNECTED
                         * 不代表 Bluetooth Stack 已经完全 teardown。
                         *
                         * OnePlus 上这里保留一个短 cooldown。
                         */
                        delay(GATT_COOLDOWN_MS)

                        if (isDisconnectingIntentionally) {
                            return@launch
                        }

                        FissionLogUtils.d(
                            "BleDeviceManager",
                            "GATT cooldown 完成，开始 establishConnection()"
                        )

                        beginConnection(isOtaMode)

                        return@launch
                    }

                    // 仍然连接
                    if (System.currentTimeMillis() >= deadline) {

                        FissionLogUtils.w(
                            "BleDeviceManager",
                            "等待 GATT 释放超时，" +
                            "device=${device.address}"
                        )

                        /*
                         * 不无限等待。
                         *
                         * 某些 OEM 的 BluetoothManager 状态
                         * 可能长时间保持 CONNECTED。
                         *
                         * 超时后仍然尝试一次连接。
                         */
                        delay(GATT_COOLDOWN_MS)

                        if (!isDisconnectingIntentionally) {

                            FissionLogUtils.w(
                                "BleDeviceManager",
                                "GATT Ready 超时，继续建立连接"
                            )

                            beginConnection(isOtaMode)
                        }

                        return@launch
                    }

                    FissionLogUtils.d(
                        "BleDeviceManager",
                        "GATT 仍然 Connected，" +
                        "等待 ${GATT_CHECK_INTERVAL_MS}ms"
                    )

                    delay(GATT_CHECK_INTERVAL_MS)
                }

            } catch (e: CancellationException) {

                FissionLogUtils.d(
                    "BleDeviceManager",
                    "waitGattReadyAndConnect cancelled"
                )

            } catch (e: Exception) {

                FissionLogUtils.w(
                    "BleDeviceManager",
                    "查询 GATT 状态失败: ${e.message}"
                )

                /*
                 * 查询失败不能阻塞 BLE。
                 * 给 stack 一点时间，然后继续连接。
                 */
                if (!isDisconnectingIntentionally) {

                    delay(GATT_COOLDOWN_MS)

                    if (!isDisconnectingIntentionally) {
                        beginConnection(isOtaMode)
                    }
                }

            } finally {
                isWaitingGattReady = false
                waitGattJob = null
            }
        }
    }

    private fun beginConnection(isOtaMode: Boolean) {
        if (disposables.isDisposed) disposables = CompositeDisposable() else disposables.clear()
        notificationDisposables.clear()

        emitEvent(ConnectionStateEvent.Connecting)

        rxBleDevice.observeConnectionStateChanges()
            .subscribe { state ->
                if (state == RxBleConnection.RxBleConnectionState.DISCONNECTED) {
                    FissionLogUtils.d("BleDeviceManager", "检测到主动断开")
                    if (isDisconnectingIntentionally) {
                        emitEvent(ConnectionStateEvent.Disconnected)
                    } else {
                        emitEvent(ConnectionStateEvent.Disconnected)
                        bleConnection = null
                    }
                }
            }
            .addTo(disposables)

        // flatMap + Observable.never() 保持 establishConnection 订阅不断开，否则通知会被系统关闭
        rxBleDevice.establishConnection(false)
            .flatMap { connection ->
                bleConnection = connection
                FissionLogUtils.d("BleDeviceManager", "连接已建立，开始 GATT 初始化...")
                prepareGattConnection(connection)
                    .andThen(buildNotificationChain(connection, isOtaMode))
                    .andThen(Completable.fromAction {
                        FissionLogUtils.i(
                            "BleDeviceManager",
                            "BLE通道完全就绪！(所有通知已订阅)$bleConnection"
                        )
                        reconnectAttempt = 0
                        emitEvent(ConnectionStateEvent.Connected(rxBleDevice.bluetoothDevice, isOtaMode))
                        schedulePhyUpgradeAsync(connection)
                    })
                    .andThen(Observable.never<Any>())
            }
            .subscribe({
                // 由 Observable.never() 保持连接，正常不会走到这里
            }, { error ->
                handleConnectionPipelineFailure(error, isOtaMode)
            })
            .addTo(disposables)
    }

    private fun prepareGattConnection(connection: RxBleConnection): Completable {
        return Completable.timer(CONNECTION_SETTLE_MS, TimeUnit.MILLISECONDS)
            .andThen(requestHighConnectionPriority(connection))
            .andThen(discoverServices(connection))
            .andThen(requestMtu(connection))
    }

    private fun requestHighConnectionPriority(connection: RxBleConnection): Completable {
        return connection.requestConnectionPriority(
            BluetoothGatt.CONNECTION_PRIORITY_HIGH,
            3,
            TimeUnit.SECONDS
        ).onErrorComplete { error ->
            FissionLogUtils.w(
                "BleDeviceManager",
                "CONNECTION_PRIORITY_HIGH 失败，继续: ${error.message}"
            )
            true
        }
    }

    private fun discoverServices(connection: RxBleConnection): Completable {
        return connection.discoverServices(GATT_SETUP_TIMEOUT_SEC, TimeUnit.SECONDS)
            .doOnSuccess {
                FissionLogUtils.d("BleDeviceManager", "GATT 服务发现完成")
            }
            .ignoreElement()
    }

    @SuppressLint("Range")
    private fun requestMtu(connection: RxBleConnection): Completable {
        return connection.requestMtu(517)
            .doOnSuccess { mtuValue ->
                mtu = mtuValue
                FissionLogUtils.i("BleDeviceManager", "MTU协商成功: $mtuValue. 物理链路已就绪。")
            }
            .ignoreElement()
    }

    private fun buildNotificationChain(
        connection: RxBleConnection,
        isOtaMode: Boolean
    ): Completable {
        FissionLogUtils.d("BleDeviceManager", "开始后台配置BLE通道...")
        return if (isOtaMode) {
            setupNotification(connection, otaNotificationUUID, "OTA通知")
        } else {
            setupNotification(connection, notifyUUID, "普通通知")
                .andThen(setupNotification(connection, imageNotifyUUID, "图片通知"))
                .andThen(setupNotification(connection, otaNotificationUUID, "OTA通知"))
        }
    }

    private fun handleConnectionPipelineFailure(error: Throwable, isOtaMode: Boolean) {
        FissionLogUtils.e("BleDeviceManager", "BLE 连接流程失败: ${error.message}")
        if (isDisconnectingIntentionally) return

        if (isRecoverableGattSetupError(error) && reconnectAttempt < MAX_FULL_CONNECTION_RETRIES) {
            scheduleFullConnectionRetry(isOtaMode, error)
            return
        }
        emitEvent(ConnectionStateEvent.Failed(error))
    }

    private fun scheduleFullConnectionRetry(isOtaMode: Boolean, cause: Throwable) {
        reconnectAttempt++
        FissionLogUtils.w(
            "BleDeviceManager",
            "将进行完整 BLE 重连 (${reconnectAttempt}/${MAX_FULL_CONNECTION_RETRIES}): ${cause.message}"
        )
        tearDownActiveConnection()
        scope.launch {
            delay(FULL_RECONNECT_DELAY_MS)
            if (!isDisconnectingIntentionally) {
                beginConnection(isOtaMode)
            }
        }
    }

    private fun tearDownActiveConnection() {
        bleConnection = null
        resetWriteQueue()
        notificationDisposables.clear()
        disposables.clear()
        if (disposables.isDisposed) {
            disposables = CompositeDisposable()
        }
    }

    private fun resetWriteQueue() {
        val dropped = writeQueue.size
        writeQueue.clear()
        isWriting.set(false)
        if (dropped > 0) {
            FissionLogUtils.w("BleDeviceManager", "重置写入队列，丢弃 $dropped 条待写数据")
        }
    }

    fun pendingWriteQueueSize(): Int = writeQueue.size + if (isWriting.get()) 1 else 0

    private fun isRecoverableGattSetupError(error: Throwable): Boolean {
        if (error is TimeoutException) return true
        val message = error.message.orEmpty()
        return message.contains("SERVICE_DISCOVERY", ignoreCase = true) ||
            message.contains("GATT exception", ignoreCase = true)
    }

    private fun setupNotification(
        connection: RxBleConnection,
        uuid: UUID,
        logTag: String
    ): Completable {
        return Completable.create { emitter ->
            lateinit var setupDisposable: Disposable
            setupDisposable = connection.setupNotification(uuid)
                .subscribe({ notificationObservable ->
                    notificationObservable.subscribe({ bytes ->
                        when (uuid) {
                            notifyUUID -> emitEvent(BleRawDataEvent.GeneralData(bytes.toList()))
                            imageNotifyUUID -> {
                                FissionLogUtils.d("BleDeviceManager", "图片通知通道收到数据 size=${bytes.size}")
                                emitEvent(BleRawDataEvent.ImageData(bytes.toList()))
                            }
                            otaNotificationUUID -> emitEvent(BleRawDataEvent.OTAData(bytes.toList()))
                        }
                    }, { error ->
                        FissionLogUtils.w(
                            "BleDeviceManager",
                            "通知'$logTag'数据流中断: ${error.message}"
                        )
                    }).addTo(notificationDisposables)

                    notificationDisposables.add(setupDisposable)
                    FissionLogUtils.d("BleDeviceManager", "已为'$logTag'建立长期数据监听。")
                    if (!emitter.isDisposed) {
                        emitter.onComplete()
                    }
                }, { error ->
                    if (!emitter.isDisposed) {
                        emitter.onError(error)
                    }
                })
        }.timeout(GATT_SETUP_TIMEOUT_SEC, TimeUnit.SECONDS)
    }


    @SuppressLint("CheckResult")
    private fun schedulePhyUpgradeAsync(connection: RxBleConnection) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        FissionLogUtils.d("BleDeviceManager", "连接就绪，后台尝试切换 PHY 2M...")
        setPhyIfNeeded(connection)
            .subscribe({
                FissionLogUtils.d("BleDeviceManager", "后台 PHY 切换流程结束")
            }, { error ->
                FissionLogUtils.w("BleDeviceManager", "后台 PHY 切换异常: ${error.message}")
            })
            .addTo(disposables)
    }

    private fun setPhyIfNeeded(connection: RxBleConnection): Completable {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            FissionLogUtils.d("BleDeviceManager", "PHY setting skipped: Android < 8.0")
            return Completable.complete()
        }
        return connection.readPhy()
            .flatMapCompletable { currentPhy ->
                val already2M =
                    currentPhy.txPhy == RxBlePhy.PHY_2M && currentPhy.rxPhy == RxBlePhy.PHY_2M
                if (already2M) {
                    FissionLogUtils.d("BleDeviceManager", "PHY already 2M, no need to set")
                    return@flatMapCompletable Completable.complete()
                }
                connection.setPreferredPhy(
                    setOf(RxBlePhy.PHY_2M),
                    setOf(RxBlePhy.PHY_2M),
                    RxBlePhyOption.PHY_OPTION_NO_PREFERRED
                )
                    .retry(2) { error ->
                        error.message?.contains("GATT_REQ_NOT_SUPPORTED") == true
                    }
                    .doOnSuccess { phy ->
                        FissionLogUtils.d(
                            "BleDeviceManager",
                            "PHY switched success: TX=${phy.txPhy}, RX=${phy.rxPhy}"
                        )
                    }
                    .doOnError { error ->
                        FissionLogUtils.w(
                            "BleDeviceManager",
                            "PHY switch failed after retries: ${error.message}, fallback to 1M"
                        )
                    }
                    .ignoreElement()
            }
            .timeout(PHY_OPERATION_TIMEOUT_SEC, TimeUnit.SECONDS)
            .onErrorComplete { error ->
                FissionLogUtils.w("BleDeviceManager", "PHY setup failed: ${error.message}")
                true
            }
    }

    private fun enqueueData(uuid: UUID, data: ByteArray) { // 删掉 useWriteCommand 参数
        //始终使用最安全的 mtu - 3 作为分包大小
        val maxPayload = mtu - 3
        if (data.isEmpty() || maxPayload <= 0) {
            FissionLogUtils.w("BleDeviceManager", "分包失败，数据为空或maxPayload <= 0")
            return
        }

        var offset = 0
        while (offset < data.size) {
            val end = (offset + maxPayload).coerceAtMost(data.size)
            val chunk = data.copyOfRange(offset, end)
            writeQueue.offer(WriteRequest(uuid, chunk))
            offset = end
        }
        val queueSize = writeQueue.size
        if (queueSize > 1) {
            FissionLogUtils.w(
                "BleDeviceManager",
                "写入队列积压 queueSize=$queueSize isWriting=${isWriting.get()}"
            )
        }
        processQueue()
    }

    fun sendData(data: ByteArray) {
        if (isOtaMode) {
            FissionLogUtils.w("BleDeviceManager", "OTA模式下跳过普通命令写入: ${bytesToHex(data)}")
            return
        }
        // 调用新的 enqueueData
        enqueueData(writeUUID, data)
    }

    suspend fun sendDataAndAwait(data: ByteArray, timeoutMs: Long = 3_000L): Boolean {
        if (isOtaMode) {
            FissionLogUtils.w("BleDeviceManager", "OTA模式下跳过普通命令写入: ${bytesToHex(data)}")
            return false
        }
        if (bleConnection == null) {
            FissionLogUtils.w("BleDeviceManager", "sendDataAndAwait: 无连接")
            return false
        }
        sendData(data)
        return awaitPendingWrites(timeoutMs)
    }

    suspend fun awaitPendingWrites(timeoutMs: Long = 3_000L): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (bleConnection == null) {
                FissionLogUtils.w("BleDeviceManager", "awaitPendingWrites: 连接已断开")
                return false
            }
            if (!isWriting.get() && writeQueue.isEmpty()) {
                return true
            }
            delay(10)
        }
        FissionLogUtils.w("BleDeviceManager", "awaitPendingWrites 超时")
        return false
    }

    fun sendOtaAuthData(data: ByteArray) {
        // 调用新的 enqueueData
        enqueueData(otaWriteUUID, data)
    }

    private fun processQueue() {
        if (!isWriting.compareAndSet(false, true)) {
            FissionLogUtils.d(
                "BleDeviceManager",
                "写入排队中，isWriting=true，queueSize=${writeQueue.size}"
            )
            return
        }
        val request = writeQueue.poll()
        if (request == null) {
            isWriting.set(false)
            return
        }
        val currentConnection = bleConnection
        if (currentConnection == null) {
            FissionLogUtils.e("BleDeviceManager", "写入失败：连接已断开$currentConnection bleConnection:$bleConnection")
//            emitEvent(WriteResultEvent.Failure(request.uuid, request.data, IllegalStateException("Connection is null")))
            isWriting.set(false)
            writeQueue.clear()
            return
        }
        var isWriteWithoutResponse = false

        // 检查是否是RCSP协议包
        if (request.data.size > 8 && request.data[0] == 0xFE.toByte() && request.data[1] == 0xDC.toByte() && request.data[2] == 0xBA.toByte()) {
            val opCode = request.data[4] and 0xFF.toByte() // 获取OpCode
            // 杰理协议中，0xE5 (229) 是固件数据传输命令，通常使用无应答模式
            if (opCode == 0xE5.toByte()) {
                isWriteWithoutResponse = true
            }
        }

        val writeOperation: Completable

        if (isWriteWithoutResponse) {
            if (!isOtaMode){
                // --- 执行无应答写入 ---
                FissionLogUtils.d(
                    "BleDeviceManager",
                    "执行写入 (无应答 - OTA 数据): ${bytesToHex(request.data)}"
                )
            }
            writeOperation = currentConnection.writeCharacteristic(
                request.uuid, // UUID 应该总是 otaWriteUUID
                request.data
            ).ignoreElement() // 丢弃回复，实现无应答
        } else {
            if (!isOtaMode) {
                // --- 执行有应答写入 ---
                FissionLogUtils.d(
                    "BleDeviceManager",
                    "执行写入 (有应答 - 命令): ${bytesToHex(request.data)}"
                )
            }
            // writeCharacteristic 默认就是有应答的，它返回一个 Single<ByteArray>
            // 我们不使用 ignoreElement()，而是将它转换为 Completable 以便统一处理
            writeOperation = currentConnection.writeCharacteristic(
                request.uuid,
                request.data
            ).flatMapCompletable { responseBytes ->
                // 虽然这里我们收到了回复，但杰理SDK是通过Notification接收业务层回复的
                // 所以这里收到GATT层的回复后，我们什么都不用做，直接表示完成即可。
                if (!isOtaMode) {
                    FissionLogUtils.d(
                        "BleDeviceManager",
                        "GATT层写入确认: ${bytesToHex(responseBytes)}"
                    )
                }
                Completable.complete()
            }
        }

        // 统一订阅写入操作
        writeOperation.subscribe({
            isWriting.set(false)
            processQueue()
        }, { error ->
            FissionLogUtils.e("BleDeviceManager", "写入 ${request.uuid} 失败: ${error.message}")
//            emitEvent(WriteResultEvent.Failure(request.uuid, request.data, error))
            isWriting.set(false)
            processQueue()
        })
            .addTo(disposables)
    }


    fun disconnect() {
        FissionLogUtils.d("BleDeviceManager", "主动断开连接")
        isDisconnectingIntentionally = true
        resetWriteQueue()
        notificationDisposables.clear()
        disposables.dispose()
        connectStateJob?.cancel()
        bleConnection = null
        emitEvent(ConnectionStateEvent.Disconnected)
    }
}
