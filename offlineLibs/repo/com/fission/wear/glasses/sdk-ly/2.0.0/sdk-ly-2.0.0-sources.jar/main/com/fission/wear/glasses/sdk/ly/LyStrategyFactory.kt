package com.fission.wear.glasses.sdk.ly

import com.fission.wear.glasses.sdk.LYGlassesCmdStrategy
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ChannelType
import com.fission.wear.glasses.sdk.events.GlassesCmdStrategy
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.strategy.AiUplinkProfile
import com.fission.wear.glasses.sdk.strategy.GlassesStrategyFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow

class LyStrategyFactory : GlassesStrategyFactory {
    override val channel: ChannelType = ChannelType.LY

    override val aiUplinkProfile: AiUplinkProfile = AiUplinkProfile(
        glassesUplinkFormat = "opus",
        sampleRate = 16000,
        deviceChannel = 2,
    )

    override fun create(
        config: SdkConfig,
        eventFlow: MutableSharedFlow<GlassesEvent>,
        scope: CoroutineScope,
    ): GlassesCmdStrategy = LYGlassesCmdStrategy(eventFlow, scope, config)
}
