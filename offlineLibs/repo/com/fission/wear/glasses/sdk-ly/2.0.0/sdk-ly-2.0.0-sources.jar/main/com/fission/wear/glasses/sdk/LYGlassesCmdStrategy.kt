package com.fission.wear.glasses.sdk

import android.icu.util.Calendar
import android.os.SystemClock
import com.blankj.utilcode.util.ConvertUtils
import com.fission.wear.glasses.sdk.bt.BtManager
import com.fission.wear.glasses.sdk.config.BleComConfig
import com.fission.wear.glasses.sdk.config.BtConnectionConfig
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ActionSyncType
import com.fission.wear.glasses.sdk.constant.GlassesConstant.BtMediaKeyAction
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_IMAGE_RECOGNITION
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_IMAGE_SAVE
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_OTA_FILE_NOT_FOUND
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_WIFI_DEVICE_DISCOVERY_TIMEOUT
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_WIFI_OPEN_ERROR
import com.fission.wear.glasses.sdk.constant.LyCmdConstant
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_ACTION_SYNCHRONIZATION
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_AI_IMAGE_RECOGNITION
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_ALARM_CLOCK_SETTING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_ANSWER_OR_HANG_UP_CALL
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_AUDIO_DATA
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_CANCEL_PLAY_AUDIO
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_CLEAR_DEVICE_CONNECTION_RECORD
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_DELETE_ALARM_CLOCK
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_DEVICE_BUTTON_CLICK
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_DEVICE_CANCEL_RECORDING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_DEVICE_START_RECORDING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_DOWNLOAD_COMPLETE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_DOWN_OR_UP_VOLUME
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_FAILED_RECOGNIZE_PICTURE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_BATTERY_LEVEL
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_DEVICE_CONFIG
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_DEVICE_SETTINGS_STATE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_DEVICE_STORAGE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_IMAGE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_MEDIA_FILES
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_VOICE_COMMAND_DISABLE_STATE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_GET_VOLUME
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_ISP_UPGRADE_RESULT
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_LED_INTENSITY
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_MIC_SETTING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_NOTIFY_BATTERY_LEVEL
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_OPEN_OPUS
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_PHOTO_MODE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_PHOTO_STYLE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_PLAY_OR_PAUSE_SONG
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_POWER_ON
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_PREVIOUS_OR_NEXT_SONG
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_REBOOT_DEVICE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_RECORDING_DURATION
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_RESET_GESTURE_SHORTCUT
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_RESTORE_FACTORY_SETTING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SEDENTARY_REMINDER_SETTING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_ISP_VERSION
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_OFFLINE_VOICE_LANGUAGE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_SCREEN_ORIENTATION
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_SOS_PHONE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_START_LIVE_STREAMING
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_TIME
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_VOICE_COMMAND_DISABLE_STATE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_VOLUME
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_WEAR_DETECTION
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_SET_WIFI_CONFIG
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_START_OR_STOP_RECORD
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_START_RECORDING_VIDEO
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_STOP_RECORDING_VIDEO
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_UPDATE_MEDIA_FILE_SIZE
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_VAD_STOP
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_VERSION_INFO
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.LY_CMD_WIFI_NAME
import com.fission.wear.glasses.sdk.constant.LyCmdConstant.PhotoCaptureTrigger
import com.fission.wear.glasses.sdk.data.cache.GlassesSpUtil
import com.fission.wear.glasses.sdk.data.dto.DeviceSettingsStateDTO
import com.fission.wear.glasses.sdk.data.dto.DeviceVersionInfoDTO
import com.fission.wear.glasses.sdk.data.model.BaseWsMessage
import com.fission.wear.glasses.sdk.data.model.GlassesFeaturesConfigInfo
import com.fission.wear.glasses.sdk.data.model.LiveStreamingConfig
import com.fission.wear.glasses.sdk.data.model.McpData
import com.fission.wear.glasses.sdk.data.repository.MediaRepository
import com.fission.wear.glasses.sdk.events.AgentEvent
import com.fission.wear.glasses.sdk.events.AiAssistantEvent
import com.fission.wear.glasses.sdk.events.AudioStateEvent
import com.fission.wear.glasses.sdk.events.BleRawDataEvent
import com.fission.wear.glasses.sdk.events.BtConnectEvent
import com.fission.wear.glasses.sdk.events.CmdResultEvent
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent
import com.fission.wear.glasses.sdk.events.FileSyncEvent
import com.fission.wear.glasses.sdk.events.GlassesCmdStrategy
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.events.LiveEvent
import com.fission.wear.glasses.sdk.events.OTAEvent
import com.fission.wear.glasses.sdk.events.WifiApEvent
import com.fission.wear.glasses.sdk.live.LyLiveApi
import com.fission.wear.glasses.sdk.live.LyLiveEndpointResolver
import com.fission.wear.glasses.sdk.live.LyLiveNetworkProbe
import com.fission.wear.glasses.sdk.manager.BleManager
import com.fission.wear.glasses.sdk.manager.LyWifiDownloadManager
import com.fission.wear.glasses.sdk.manager.WifiApConnectManager
import com.fission.wear.glasses.sdk.manager.WifiDirectManager
import com.fission.wear.glasses.sdk.ota.jieli.OTAManager
import com.fission.wear.glasses.sdk.ota.ly.LyIspTcpOtaClient
import com.fission.wear.glasses.sdk.state.SdkBleConnectionState
import com.fission.wear.glasses.sdk.util.BitmapUtils.saveBitmapAsJpeg
import com.fission.wear.glasses.sdk.util.BlePacketUtils
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.fission.wear.glasses.sdk.util.checkBleConnectPrecondition
import com.fission.wear.glasses.sdk.util.getBits
import com.fission.wear.glasses.sdk.util.toBytes
import com.fission.wear.glasses.sdk.util.toInt2Bytes
import com.polidea.rxandroidble3.RxBleConnection.RxBleConnectionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.internal.synchronized
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File

/**
 * describe:
 * author: wl
 * createTime: 2025/9/9
 */
internal class LYGlassesCmdStrategy(
    private val eventBus: MutableSharedFlow<GlassesEvent>,
    private val scope: CoroutineScope,
    private val sdkConfig: SdkConfig,
) : GlassesCmdStrategy {
    private val header: Short = 0xAB55.toShort()
    private var ssid: String? = null
    private fun aiAssistantListenMode(): String =
        GlassesConstant.AI_ASSISTANT_TYPE_LISTEN_MODE_AUTO

    private var deviceSettingsState = DeviceSettingsStateDTO()
    private val allGestureTypes = GlassesConstant.GestureType.entries.toSet()
    private var otaManager: OTAManager? = null
    private lateinit var operationType: GlassesConstant.OperationType
    private lateinit var filePath: String
    private var lastActionStates: ByteArray? = null
    private var pendingIspVersion: String? = null
    /**
     * ISP 固件是否已上传完成。上传完成前收到的 [LY_CMD_ISP_UPGRADE_RESULT]（0x96）一律忽略。
     */
    @Volatile
    private var ispFirmwareUploaded = false
    /** ISP OTA 已出最终结果后，忽略后续重复回调。 */
    private var ispOtaResultHandled = false
    private var ispOtaJob: Job? = null
    private val currentGestureSettings =
        mutableMapOf<GlassesConstant.GestureType, GlassesConstant.GestureAction>()
    private val imageReceiver by lazy {
        BlePacketUtils.ImageReceiver(scope, eventBus)
    }
    private var wifiMode: GlassesConstant.WifiMode = sdkConfig.productSeries.defaultWifiMode()
    private var liveStreamingConfig: LiveStreamingConfig? = null
    private var lyWifiDownloadManager: LyWifiDownloadManager? = null
    private var lastActionStateTime:Long = 0L
    private var aiAssistantBridgeJob: Job? = null
    private var wifiNameCallbackTimeoutJob: Job? = null
    private var isMediaSyncInProgress = false
    /** Wi-Fi 已连上并开始拉取文件列表后为 true；仅处于开热点/连热点阶段时为 false。 */
    private var isMediaWifiConnectSuccess = false
    private var isConnectInProgress = false
    private val TAG = "LYGlassesCmdStrategy"
    private var isAiRecording = false //AI录音中
    private var lyRawAudioPacketSeq = 0
    private var lyRawAudioDumpPath: String? = null
    private var lyRawAudioDumpFile: File? = null
    private var lyRawAudioDumpWriter: java.io.BufferedWriter? = null
    private var lastPhotoCaptureTrigger: Byte = PhotoCaptureTrigger.AI_RECOGNITION
    /** AI识图：拍照指令已接受，等待动作同步中拍照结束后再拉取图片 */
    private var awaitingAiImageTransferAfterPhotoEnd = false
    @Volatile
    private var sessionResourcesReleased = false

    private companion object {
        const val WIFI_NAME_CALLBACK_TIMEOUT_MS = 10_000L
        const val OPEN_WIFI_BLE_WRITE_TIMEOUT_MS = 5_000L
        /** HTTP cmd=3001 成功后等待设备 RTSP 服务就绪 */
        const val LY_LIVE_RTSP_START_DELAY_MS = 800L
        /** Logcat 过滤 `LY_RAW_AUDIO`；原始 hex 也会写入 filesDir/ly_raw_audio_dump/ */
        const val LOG_LY_RAW_AUDIO = true
        const val LY_RAW_AUDIO_TAG = "LY_RAW_AUDIO"
        const val LY_RAW_AUDIO_MAX_LOG_PACKETS = 300
    }

    private fun emitEvent(event: GlassesEvent) {
        scope.launch {
            eventBus.emit(event)
        }
    }

    init {

        scope.launch {
            eventBus
                .collect { event ->
                    when (event) {
                        is ConnectionStateEvent.Disconnected -> {
                            lastActionStateTime = 0
                            lastActionStates = null
                            awaitingAiImageTransferAfterPhotoEnd = false
                            AiAssistantClient.getInstance().cancelWifiExclusiveSession()
                            endConnect()
                        }
                        is ConnectionStateEvent.Failed -> {
                            endConnect()
                        }
                        is ConnectionStateEvent.Connected -> {
                            endConnect()
                            if (!event.isOtaMode) {
                                FissionLogUtils.i("BLE device connected successfully, ready to pair BT")
                                BtManager.onBleConnected(event.device)
                            }
                        }

                        is BtConnectEvent.Bonded -> Unit

                        is BtConnectEvent.BondFailed -> {
                            FissionLogUtils.i(TAG, "BT Pairing failed")
                        }

                        is BtConnectEvent.Failed -> {
                            FissionLogUtils.d(TAG, "BT Connect Fail: ${event.message}")
                        }

                        is BleRawDataEvent.ImageData -> {
                            val bytes = event.data.toByteArray()
                            FissionLogUtils.d(TAG, "收到图片原始BLE通知 size=${bytes.size}")
                            imageReceiver.onReceive(bytes)
                        }

                        is BleRawDataEvent.GeneralData -> {
                            handleGeneralData(event.data.toByteArray())
                        }

                        is CmdResultEvent.ImageData -> {
                            FissionLogUtils.d(TAG, "收到CmdResultEvent.ImageData size=${event.data.size}")
                            handleImageComplete(event.data.toByteArray())
                        }

                        is CmdResultEvent.Fail -> {
                            when (event.code) {
                                in GlassesConstant.ERROR_CODE_IMAGE_PACKET_TOO_SHORT..
                                    GlassesConstant.ERROR_CODE_IMAGE_TIMEOUT ->
                                    FissionLogUtils.w(
                                        TAG,
                                        "图片传输失败 code=${event.code} msg=${event.msg}",
                                    )
                                ERROR_CODE_IMAGE_RECOGNITION -> FissionLogUtils.w(
                                    TAG,
                                    "AI识图失败 code=${event.code} msg=${event.msg}",
                                )
                                else -> FissionLogUtils.i(TAG, event.msg)
                            }
                        }

                        is WifiApEvent.Connected -> {
                            // 中立 AP 连接成功：按业务内部触发下一步（Manager 不再发业务事件）
                            if (!::operationType.isInitialized) return@collect
                            when (operationType) {
                                GlassesConstant.OperationType.MEDIA_SYNC -> {
                                    isMediaWifiConnectSuccess = true
                                    lyWifiDownloadManager?.getMediaFileList(
                                        sdkConfig.context
                                    )
                                }

                                GlassesConstant.OperationType.OTA -> {
                                    if (ispOtaResultHandled) {
                                        FissionLogUtils.w(
                                            TAG,
                                            "ISP OTA 已结束，忽略 AP 连接成功触发的重复 OTA"
                                        )
                                        resetIspOtaWifiSessionState()
                                        return@collect
                                    }
                                    if (sdkConfig.productSeries.usesIspTcpOta()) {
                                        startIspTcpOta()
                                    } else {
                                        startIspHttpOta()
                                    }
                                }

                                GlassesConstant.OperationType.LIVE -> {
                                    scope.launch { startLyLiveSession() }
                                }
                            }
                        }

                        // 中立 AP 连接失败/断开：按业务转发为各自失败事件，隔离到 LiveEvent/OTAEvent/FileSyncEvent
                        is WifiApEvent.Failed -> handleApConnectionFailed(event.reason, event.code)
                        is WifiApEvent.Disconnected -> handleApConnectionFailed(event.reason, event.code)

                        is FileSyncEvent.BatchDownloadFinished -> {
                            delay(200)//延迟等待最后一次delete完成
                            downloadComplete(event.successCount, event.totalFileCount)
                        }

                        is FileSyncEvent.Failed -> {
                            FissionLogUtils.d(
                                TAG,
                                "Wifi连接失败：$event.reason 错误码：${event.code}"
                            )
                            if (::operationType.isInitialized &&
                                operationType == GlassesConstant.OperationType.OTA
                            ) {
                                finishIspOtaWifi()
                                if (!ispOtaResultHandled) {
                                    ispOtaResultHandled = true
                                    emitEvent(OTAEvent.Failed(event.reason, event.code))
                                }
                                endAssistantAfterWifiExclusiveSession()
                                return@collect
                            }
                            if (::operationType.isInitialized &&
                                operationType == GlassesConstant.OperationType.LIVE
                            ) {
                                finishLyLiveSession(
                                    failed = LiveEvent.Failed(event.reason, event.code),
                                )
                                return@collect
                            }
                            if (isMediaSyncInProgress) {
                                endMediaSync()
                            }
                            if (event.code == ERROR_CODE_DOWNLOAD_FILE_NOT_FOUND){
                                syncDownloadStatus(1, 1)//关闭wifi
                            }else {
                                val result = lyWifiDownloadManager?.getCurFileNum() ?: Pair(0, 0)
                                syncDownloadStatus(result.first, result.second)//关闭wifi
                            }
                            connectAssistantWs()
                        }

                        is OTAEvent.Failed,
                        is OTAEvent.Cancelled,
                        is OTAEvent.Success -> {
                            otaManager?.release()
                            otaManager = null
                            BleManager.exitOtaMode()
                            if (ispOtaResultHandled) {
                                resetIspOtaWifiSessionState()
                            }
                            endAssistantAfterWifiExclusiveSession()
                        }


                        else -> {

                        }
                    }
                }
        }

        aiAssistantBridgeJob = scope.launch {
            AiAssistantClient.getInstance().aiAgentEventFlow().collect { event ->
                when (event) {
                    is AiAssistantEvent.AiImageRecognition -> {
                        FissionLogUtils.d(TAG, "AI识图触发拍照")
                        AiAssistantClient.getInstance().startAiImageRecognition(event.data)
                        takePicture(true)
                    }

                    // 仅全部 TTS 段播放完成后才会收到；MCP 识图多段时第一段结束不会停麦
                    AiAssistantEvent.AgentAudioPlaybackFinished -> {
                        if (AiAssistantClient.getInstance().isAwaitingMcpImageRecognitionFollowUp()) {
                            FissionLogUtils.i(TAG, "MCP 识图跟进中，暂不关闭 AI 录音")
                            return@collect
                        }
                        stopVadAudio()
                    }

                    is AgentEvent.AiAssistantConnectState -> { //AI服务断开关闭录音
                        if (event.state == GlassesConstant.WS_CONNECTION_STATE_DISCONNECTED &&
                            GlassesManage.currentConnectionState().bleState == SdkBleConnectionState.CONNECTED &&
                            isAiRecording
                        ) {
                            // 切语种重建连接期间禁止开听，此时停麦由 interrupt 负责，避免异步 DISCONNECTED 误伤
                            if (AiAssistantClient.getInstance().isListenBlockedByWsReconnect()) {
                                FissionLogUtils.d(TAG, "WS 重建中，忽略 DISCONNECTED 停麦")
                                return@collect
                            }
                            isAiRecording = false
                            stopVadAudio()
                        }
                    }
                    else -> Unit
                }
            }
        }

        BtManager.init(
            sdkConfig.context,
            eventBus,
            BtConnectionConfig.forChannel(sdkConfig.channel)
        )
    }

    override fun release() {
        releaseSessionResources()
        // 解绑可能仍在后台进行：等结束后再 release，避免中途关掉 Profile proxy
        BtManager.whenUnpairFinished {
            BtManager.release(null)
        }
    }

    override fun disConnect(unpair: Boolean) {
        endConnect()
        val device = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice
        if (unpair && BleManager.currentDeviceManager?.bleConnection != null) {
            runBlocking(Dispatchers.IO) {
                clearDeviceConnectionRecord()
            }
        }
        releaseSessionResources()
        if (unpair) {
            BtManager.removeBondFromPairedDevicesByAddress(sdkConfig.context) {
                GlassesSpUtil.remove(GlassesSpUtil.KEY_MAC_ADDRESS)
                BtManager.release(device)
            }
        } else {
            device?.let { BtManager.disconnectConfiguredProfiles(it) }
            BleManager.disconnect()
            BtManager.release(device)
        }
    }

    /** 释放所有依赖 [scope] 的会话资源；可重复调用。 */
    private fun releaseSessionResources() {
        if (sessionResourcesReleased) return
        sessionResourcesReleased = true
        endMediaSync()
        isAiRecording = false
        closeLyRawAudioDumpSession("releaseSessionResources")
        awaitingAiImageTransferAfterPhotoEnd = false
        lastActionStateTime = 0
        lastActionStates = null

        aiAssistantBridgeJob?.cancel()
        aiAssistantBridgeJob = null

        lyWifiDownloadManager?.release()
        lyWifiDownloadManager = null

        liveStreamingConfig = null

        otaManager?.release()
        otaManager = null
        BleManager.exitOtaMode()

        WifiApConnectManager.disconnect()
        WifiDirectManager.disconnect()
        imageReceiver.cancel()
    }

    private fun handleImageComplete(img: ByteArray) {
        FissionLogUtils.d(TAG, "AI has finished receiving the image, image size${img.size}")
        val bitmap = ConvertUtils.bytes2Bitmap(img)
        scope.launch(Dispatchers.IO) {
            val imageDir = File(sdkConfig.context.filesDir, sdkConfig.aiImageRecognitionStorageDirName).apply { mkdirs() }
            val path = File(imageDir, "${System.currentTimeMillis()}.jpg").absolutePath
            val file = File(path)
            try {
                saveBitmapAsJpeg(bitmap, file, 100)
                emitEvent(CmdResultEvent.ImageFile(file))
                val isAiImageRecognitionStarted =
                    AiAssistantClient.getInstance().aiImageRecognition(path)
                if (!isAiImageRecognitionStarted) {
                    FissionLogUtils.d(TAG, "AI识图缺少MCP消息")
//                    emitEvent(CmdResultEvent.Fail("AI识图缺少MCP消息", ERROR_CODE_IMAGE_RECOGNITION))
                    return@launch
                }
            } catch (e: Exception) {
                FissionLogUtils.d(TAG, "图片保存或AI识别异常${e.message}")
                emitEvent(CmdResultEvent.Fail("图片保存或AI识别异常", ERROR_CODE_IMAGE_SAVE))
            }
        }
    }

    private fun shouldLogLyRawAudio(data: ByteArray, blePacket: BlePacketUtils.BlePacket?): Boolean {
        if (!LOG_LY_RAW_AUDIO) return false
        if (blePacket?.command == LY_CMD_AUDIO_DATA.toByte()) return true
        if (isAiRecording) return true
        return data.size >= 5 && data[4] == LY_CMD_AUDIO_DATA.toByte()
    }

    private fun resetLyRawAudioDumpSession(trigger: String) {
        lyRawAudioPacketSeq = 0
        closeLyRawAudioDumpFile()
        if (!LOG_LY_RAW_AUDIO) return
        val dir = File(sdkConfig.context.filesDir, "ly_raw_audio_dump").apply { mkdirs() }
        lyRawAudioDumpFile = File(dir, "session_${System.currentTimeMillis()}.hex.txt")
        lyRawAudioDumpPath = lyRawAudioDumpFile?.absolutePath
        FissionLogUtils.iTag(
            LY_RAW_AUDIO_TAG,
            "dump_start trigger=$trigger path=$lyRawAudioDumpPath",
        )
    }

    private fun closeLyRawAudioDumpSession(reason: String) {
        if (!LOG_LY_RAW_AUDIO) return
        FissionLogUtils.iTag(
            LY_RAW_AUDIO_TAG,
            "dump_end reason=$reason packets=$lyRawAudioPacketSeq path=${lyRawAudioDumpPath ?: "n/a"}",
        )
        closeLyRawAudioDumpFile()
        lyRawAudioDumpPath = null
        lyRawAudioDumpFile = null
    }

    private fun closeLyRawAudioDumpFile() {
        lyRawAudioDumpWriter?.runCatching { close() }
        lyRawAudioDumpWriter = null
    }

    private fun logLyRawAudioPacket(rawBle: ByteArray, blePacket: BlePacketUtils.BlePacket?) {
        if (!LOG_LY_RAW_AUDIO) return
        if (lyRawAudioPacketSeq >= LY_RAW_AUDIO_MAX_LOG_PACKETS) {
            if (lyRawAudioPacketSeq == LY_RAW_AUDIO_MAX_LOG_PACKETS) {
                FissionLogUtils.wTag(
                    LY_RAW_AUDIO_TAG,
                    "达到上限 $LY_RAW_AUDIO_MAX_LOG_PACKETS，后续不再打印",
                )
            }
            lyRawAudioPacketSeq++
            return
        }
        lyRawAudioPacketSeq++
        val seq = lyRawAudioPacketSeq
        val fullHex = rawBle.joinToString("") { "%02X".format(it) }
        val header = if (rawBle.size >= 2) {
            "%02X%02X".format(rawBle[0], rawBle[1])
        } else {
            "NA"
        }
        val cmdGuess = if (rawBle.size >= 5) "%02X".format(rawBle[4]) else "NA"
        val parsedCmd = blePacket?.command?.let { "%02X".format(it) } ?: "NA"
        val crcOk = blePacket?.isValid?.toString() ?: "NA"
        val opusHex = if (blePacket?.command == LY_CMD_AUDIO_DATA.toByte()) {
            blePacket.data.joinToString("") { "%02X".format(it) }
        } else {
            ""
        }
        val opusSize = if (blePacket?.command == LY_CMD_AUDIO_DATA.toByte()) {
            blePacket.data.size
        } else {
            0
        }
        val line = buildString {
            append("seq=$seq ")
            append("raw_size=${rawBle.size} ")
            append("header=$header ")
            append("cmd_guess=$cmdGuess ")
            append("parsed_cmd=$parsedCmd ")
            append("crc_ok=$crcOk ")
            if (opusSize > 0) {
                append("opus_size=$opusSize ")
                append("opus_hex=$opusHex ")
            }
            append("full_hex=$fullHex")
        }
        FissionLogUtils.iTag(LY_RAW_AUDIO_TAG, line)

        val dumpFile = lyRawAudioDumpFile ?: return
        scope.launch(Dispatchers.IO) {
            runCatching {
                if (lyRawAudioDumpWriter == null) {
                    lyRawAudioDumpWriter = dumpFile.bufferedWriter()
                }
                lyRawAudioDumpWriter?.apply {
                    write(line)
                    newLine()
                    flush()
                }
            }.onFailure {
                FissionLogUtils.wTag(LY_RAW_AUDIO_TAG, "写 dump 文件失败: ${it.message}")
            }
        }
    }

    private fun handleGeneralData(data: ByteArray) {
        val blePacket = BlePacketUtils.parseBlePacket(data)
        if (shouldLogLyRawAudio(data, blePacket)) {
            logLyRawAudioPacket(data, blePacket)
        }
        if (blePacket?.command != LY_CMD_AUDIO_DATA.toByte()) {//过滤录音数据
            FissionLogUtils.d("收到普通数据包: ${BlePacketUtils.bytesToHex(data)}")
        }
        when (blePacket?.command) {
            LY_CMD_UPDATE_MEDIA_FILE_SIZE.toByte() -> {
                val count = blePacket.data.toByteArray().toInt2Bytes()
                FissionLogUtils.d("当前文件数量：$count")
                emitEvent(CmdResultEvent.MediaFileCount(count))
            }

            LY_CMD_GET_BATTERY_LEVEL.toByte() -> {
                val value = BlePacketUtils.parseBatteryLevel(blePacket.data.toByteArray())
                emitEvent(CmdResultEvent.DevicePower(value.first, value.second))
            }

            LY_CMD_ACTION_SYNCHRONIZATION.toByte() -> {
                val bleData = blePacket.data.toByteArray()
                val curTime = SystemClock.elapsedRealtime()
//                FissionLogUtils.w("lastActionStateTime: $lastActionStateTime   curTime:$curTime   result: ${curTime - lastActionStateTime}")
//                if (curTime - lastActionStateTime < 50){//50毫秒以下直接过滤
//                    return
//                }
                lastActionStateTime = curTime
                if(bleData.contentEquals(lastActionStates)){//单点触控
                    emitEvent(CmdResultEvent.ActionSync(ActionSyncType.SINGLE_TOUCH, true))
                }

                if (lastActionStates == null) {
                    lastActionStates = ByteArray(bleData.size) { 0xFF.toByte() }
                }

                lastActionStates?.let {lastActionStates->
                    if (bleData.size >= 9) {
                        bleData.forEachIndexed { i, currentValue ->
                            val state = currentValue == 0x01.toByte()
//                        FissionLogUtils.d("currentValue:${currentValue} lastActionStates : ${lastActionStates[i]}")
                            when (val actionType = ActionSyncType.fromIndex(i)) {
                                //开/关成对动作，对比差异发送
                                ActionSyncType.IMPORTING,
                                ActionSyncType.TAKE_PHOTO,
                                ActionSyncType.RECORD_AUDIO,
                                ActionSyncType.RECORD_VIDEO,
                                ActionSyncType.MUSIC,
                                ActionSyncType.WEAR -> {
                                    if (currentValue != lastActionStates[i]) {
                                        emitEvent(CmdResultEvent.ActionSync(actionType, state))
                                        lastActionStates[i] = currentValue
                                    }
                                }
                                //一次性动作每次都发送
                                ActionSyncType.VOLUME_UP,
                                ActionSyncType.VOLUME_DOWN,
                                ActionSyncType.NOD,
                                ActionSyncType.SHAKE_HEAD -> {
                                    lastActionStates[i] = 0x00.toByte()
                                    if (state) {
                                        emitEvent(CmdResultEvent.ActionSync(actionType, true))
                                    }
                                }
                                else -> Unit
                            }
                        }
                    }
                }
            }

//            LY_CMD_ISP_WORKING_STATE.toByte() -> {
//                val bleData = blePacket.data.toByteArray()
//                if (bleData.isNotEmpty()) {
//                    val workingState = bleData[0].toInt() and 0xFF
//                    FissionLogUtils.d(
//                        TAG,
//                        "ISP正在工作: $workingState (0:拍照, 1:录像, 2:录音, 3:导入模式)"
//                    )
//                    emitEvent(CmdResultEvent.IspWorkingMode(workingState))
//                }
//            }

            LY_CMD_GET_VOLUME.toByte() -> {
                val bleData = blePacket.data.toByteArray()
                if (bleData.isNotEmpty()) {
                    val systemVolume = bleData[0].toInt() and 0x0F
                    val mediaVolume = bleData[1].toInt() and 0x0F
                    val callVolume = bleData[2].toInt() and 0x0F
                    emitEvent(CmdResultEvent.DeviceVolumeState(systemVolume,mediaVolume,callVolume))
                }
            }

            LY_CMD_GET_VOICE_COMMAND_DISABLE_STATE.toByte() -> {
                val bleData = blePacket.data.toByteArray()
                if (bleData.isNotEmpty()) {
                    val mask = bleData[0].getBits()
                    emitEvent(
                        CmdResultEvent.VoiceCommandDisableState(
                            localOfflineVoiceDisabled = mask[0] != 0,
                            opusStreamPushDisabled = mask[1] != 0
                        )
                    )
                }
            }

            // ISP 升级结果（Wi‑Fi 开启结果见 LY_CMD_WIFI_NAME）
            LY_CMD_ISP_UPGRADE_RESULT.toByte() -> {
                val bleData = blePacket.data.toByteArray()
                if (bleData.isEmpty()) return
                val result = bleData[0].toInt() and 0xFF
                // 暂时统一按 S 系列逻辑：0x01 为成功
                val isSuccess = sdkConfig.productSeries.isIspUpgradeSuccess(result)

                if (!ispFirmwareUploaded) {
                    // POWER_ON(0x63) 后设备有时直接回 0x96 成功（无需再传固件）；
                    // 若仍忽略，会一直等 WIFI_NAME/上传，上层 UI 卡住。
                    if (isSuccess &&
                        ::operationType.isInitialized &&
                        operationType == GlassesConstant.OperationType.OTA &&
                        !ispOtaResultHandled
                    ) {
                        FissionLogUtils.d(
                            TAG,
                            "上传前收到 ISP 升级成功，按已成功结束 OTA " +
                                "(系列=${sdkConfig.productSeries.code}, result=0x${result.toString(16)})"
                        )
                        completeIspOtaFromBleResult(success = true)
                        return
                    }
                    FissionLogUtils.d(
                        TAG,
                        "忽略上传完成前的ISP升级结果 result=0x${result.toString(16)}"
                    )
                    return
                }
                if (ispOtaResultHandled) {
                    FissionLogUtils.d(TAG, "忽略重复的ISP升级结果")
                    return
                }
                FissionLogUtils.d(
                    TAG,
                    "ISP升级结果(BLE): ${if (isSuccess) "成功" else "失败"} " +
                        "(系列=${sdkConfig.productSeries.code}, result=0x${result.toString(16)})"
                )
                completeIspOtaFromBleResult(success = isSuccess)
            }

            LY_CMD_NOTIFY_BATTERY_LEVEL.toByte() -> {
                val bleData = blePacket.data
                if (bleData.size >= 2) {
                    val statusByte = bleData[0].toInt() and 0xFF
                    val isCharging = (statusByte == 0x01)
                    val batteryLevel = bleData[1].toInt() and 0xFF
                    emitEvent(
                        CmdResultEvent.DevicePower(batteryLevel, isCharging)
                    )
                }
            }

            LY_CMD_VERSION_INFO.toByte() -> {
                val bleData = blePacket.data
                if (bleData.size >= 7) {
                    val fwVerMajor = bleData[0].toInt() and 0xFF
                    val fwVerMinor = bleData[1].toInt() and 0xFF
                    val fwVerPatch = bleData[2].toInt() and 0xFF
                    val firmwareVersion = "$fwVerMajor.$fwVerMinor.$fwVerPatch"

                    val ispVerMajor = bleData[3].toInt() and 0xFF
                    val ispVerMinor = bleData[4].toInt() and 0xFF
                    val ispVerPatch = bleData[5].toInt() and 0xFF
                    val ispVersion = "$ispVerMajor.$ispVerMinor.$ispVerPatch"

                    val hardwareVersion = (bleData[6].toInt() and 0xFF).toString()

                    emitEvent(
                        CmdResultEvent.DeviceVersionInfoEvent(
                            DeviceVersionInfoDTO(
                                firmwareVersion,
                                ispVersion,
                                hardwareVersion
                            )
                        )
                    )
                } else {
                    FissionLogUtils.e(
                        TAG,
                        "接收到的版本信息数据长度不为7字节，实际为: ${bleData.size}"
                    )
                }
            }

            LY_CMD_GET_DEVICE_CONFIG.toByte() -> {
                val bleData = blePacket.data
                if (bleData.size >= 4) {
                    val fwVerFirst = bleData[3].getBits()
                    val fwVerSecond = bleData[2].getBits()
//                    val fwVerThird = bleData[2].getBits()
//                    val fwVerFour = bleData[3].getBits()

                    val configInfo = GlassesFeaturesConfigInfo(
                        fwVerFirst[0] == 1,
                        fwVerFirst[1] == 1,
                        fwVerFirst[2] == 1,
                        fwVerFirst[3] == 1,
                        fwVerFirst[4] == 1,
                        fwVerFirst[5] == 1,
                        fwVerFirst[6] == 1,
                        fwVerFirst[7] == 1,
                        fwVerSecond[0] == 1,
                        fwVerSecond[1] == 1,
                        fwVerSecond[2] == 1,
                        fwVerSecond[3] == 1
                    )
                    FissionLogUtils.d("设备支持功能： $configInfo")
                    emitEvent(CmdResultEvent.DeviceSupportedFeatures(configInfo))
                }
            }

            LY_CMD_DEVICE_START_RECORDING.toByte() -> {
                FissionLogUtils.d(TAG, "AI录音开始")
                resetLyRawAudioDumpSession("0x97_DEVICE_START_RECORDING")
                if (AiAssistantClient.getInstance().isListenBlockedByWsReconnect()) {
                    FissionLogUtils.w(TAG, "WS 重连中，禁止开听，通知眼镜停麦")
                    stopVadAudio()
                    return
                }
                isAiRecording = true
                AiAssistantClient.getInstance().notifyDeviceDialogueRecordingStarted()
                emitEvent(AudioStateEvent.StartRecording)
                startReceivingAudio(aiAssistantListenMode(), AiAssistantClient.getInstance().getAiDialogueLanguage())
            }

            LY_CMD_CANCEL_PLAY_AUDIO.toByte() -> {//取消录音/按钮打断
                FissionLogUtils.d(TAG, "AI录音取消")//设备取消
                closeLyRawAudioDumpSession("0x51_CANCEL_PLAY_AUDIO")
                isAiRecording = false
                AiAssistantClient.getInstance().notifyDeviceDialogueCancelled()
                GlassesManage.interruptAiAssistant()
                emitEvent(AudioStateEvent.CancelRecording)
            }

            LY_CMD_VAD_STOP.toByte() -> {
                FissionLogUtils.d(TAG, "AI录音停止")
                closeLyRawAudioDumpSession("0x56_VAD_STOP")
                isAiRecording = false
                emitEvent(AudioStateEvent.CancelRecording)
            }


            LY_CMD_AUDIO_DATA.toByte() -> {//录音数据
                emitEvent(AudioStateEvent.ReceivingAudioData(blePacket.data.toList()))
                sendReceivingAudioData(
                    aiAssistantListenMode(),
                    blePacket.data.toByteArray()
                )
            }

            LY_CMD_DEVICE_CANCEL_RECORDING.toByte() -> {//放弃本次识别
                FissionLogUtils.d(TAG, "AI录音丢弃")
                closeLyRawAudioDumpSession("0x49_DEVICE_CANCEL_RECORDING")
                isAiRecording = false
                AiAssistantClient.getInstance().notifyDeviceDialogueCancelled()
                emitEvent(AudioStateEvent.CancelRecording)
                cancelReceivingAudio()
            }

//            LY_CMD_DEVICE_STOP_RECORDING.toByte() -> {//语音完成
//                FissionLogUtils.d(TAG, "AI录音结束")
//                emitEvent(AudioStateEvent.StopRecording)
//                stopReceivingAudio(aiAssistantListenMode())
//            }

            // Wi‑Fi 开启结果：ISP 用 POWER_ON、同步文件用 SET_WIFI_CONFIG，均在此回调
            LY_CMD_WIFI_NAME.toByte() -> {
                cancelWifiNameCallbackTimeout()
                ssid = String(blePacket.data.toByteArray())
                if (::operationType.isInitialized &&
                    operationType == GlassesConstant.OperationType.OTA &&
                    ispOtaResultHandled
                ) {
                    FissionLogUtils.w(
                        TAG,
                        "ISP OTA 已结束，忽略设备重复 Wi‑Fi 名称回调: $ssid"
                    )
                    return
                }
                FissionLogUtils.i(
                    TAG,
                    "Wi‑Fi 开启成功，收到名称：$ssid, wifiMode=$wifiMode, operationType=" +
                        if (::operationType.isInitialized) operationType else "unset"
                )
                when (wifiMode) {
                    GlassesConstant.WifiMode.AP_MODE -> {
                        // 设备可能重复上报 SSID；再次 connect 会取消系统选网弹窗（华为提示「该应用已取消选择设备的请求」）
                        if (WifiApConnectManager.isConnectingOrConnected()) {
                            FissionLogUtils.w(TAG, "AP 已在连接/已连接，忽略重复 Wi‑Fi 名称回调: $ssid")
                            return
                        }
                        WifiApConnectManager.init(sdkConfig.context)
                        val apPolicy = if (::operationType.isInitialized &&
                            operationType == GlassesConstant.OperationType.LIVE
                        ) {
                            WifiApConnectManager.ApConnectPolicy.SOCKET_FACTORY_ONLY
                        } else {
                            WifiApConnectManager.ApConnectPolicy.BIND_PROCESS
                        }
                        // 传入按 productSeries 精确解析的设备网关（S/AG66→192.168.1.254，T/AP19→192.168.169.1），
                        // 让 AP 可达性探测直接用权威地址，避免 Android 9 上推断失败而误用兜底 192.168.169.1。
                        val apGatewayHost = LyLiveEndpointResolver.resolveRtspHost(
                            wifiMode,
                            sdkConfig.productSeries,
                        )
                        WifiApConnectManager.connect(
                            sdkConfig.context,
                            ssid!!,
                            scope,
                            eventBus,
                            apPolicy,
                            knownApGatewayHost = apGatewayHost,
                        )
                    }

                    GlassesConstant.WifiMode.P2P_MODE -> {
                        WifiDirectManager.init(sdkConfig.context)
                        WifiDirectManager.connect(sdkConfig.context, ssid!!, scope, eventBus)
                    }
                }
            }

            LY_CMD_DEVICE_BUTTON_CLICK.toByte() -> {
                emitEvent(CmdResultEvent.DeviceBtnClickEvent(BtMediaKeyAction.CLICK))
//                stopVadAudio()
            }

            LY_CMD_AI_IMAGE_RECOGNITION.toByte() -> {
                val bleData = blePacket.data.toByteArray()
                if (bleData.isEmpty()) {
                    FissionLogUtils.w(TAG, "AI识图拍照回调数据为空")
                    return
                }
                val status = bleData[0].toInt() and 0xFF
                if (status == 0x01) {
                    if (lastPhotoCaptureTrigger == PhotoCaptureTrigger.AI_RECOGNITION) {
                        awaitingAiImageTransferAfterPhotoEnd = true
                        FissionLogUtils.d(
                            TAG,
                            "AI识图拍照指令已接受，等待动作同步拍照结束 trigger=0x${lastPhotoCaptureTrigger.toInt() and 0xFF}",
                        )
                        tryRequestAiImageTransferAfterPhotoEnd()
                    } else {
                        FissionLogUtils.d(TAG, "本地存储拍照指令已接受")
                    }
                } else {
                    awaitingAiImageTransferAfterPhotoEnd = false
                    FissionLogUtils.d(TAG, "AI识图拍照失败 status=0x${status.toString(16)}")
                    handleAiImageRecognitionFailed("设备拍照失败")
                }
            }

//            LY_CMD_GET_IMAGE_SUCCESS.toByte() -> {
//                FissionLogUtils.d(TAG, "设备通知图片就绪，请求拉取图片")
//                requestImageTransfer(lastPhotoCaptureTrigger)
//            }

            LY_CMD_FAILED_RECOGNIZE_PICTURE.toByte() -> {
                FissionLogUtils.d(TAG, "设备AI识图失败")
                handleAiImageRecognitionFailed("设备识图失败")
            }

            in settingsCommandSet -> {
                handleDeviceSettingsCommand(blePacket?.command!!, blePacket.data.toByteArray())
            }
        }
    }

    private val settingsCommandSet = setOf(
        LY_CMD_LED_INTENSITY.toByte(),
        LY_CMD_RECORDING_DURATION.toByte(),
        LY_CMD_SET_WEAR_DETECTION.toByte(),
        LY_CMD_SET_SCREEN_ORIENTATION.toByte(),
        GlassesConstant.GestureType.SLIDE_FORWARD.cmd,
        GlassesConstant.GestureType.SLIDE_BACKWARD.cmd,
        GlassesConstant.GestureType.SINGLE_TAP.cmd,
        GlassesConstant.GestureType.DOUBLE_TAP.cmd,
        GlassesConstant.GestureType.TRIPLE_TAP.cmd
    )

    private fun handleDeviceSettingsCommand(cmd: Byte, data: ByteArray) {
        when (cmd) {
            LY_CMD_LED_INTENSITY.toByte() -> {
                deviceSettingsState.ledBrightness =
                    GlassesConstant.LedBrightnessLevel.fromByte(data[0])
            }

            LY_CMD_RECORDING_DURATION.toByte() -> {
                deviceSettingsState.recordDuration = BlePacketUtils.toIntBigEndian(data)
            }

            LY_CMD_SET_WEAR_DETECTION.toByte() -> {
                deviceSettingsState.wearDetectionEnabled =
                    GlassesConstant.WearDetectionState.fromByte(data[0])
            }

            LY_CMD_SET_SCREEN_ORIENTATION.toByte() -> {
                deviceSettingsState.orientation =
                    GlassesConstant.ScreenOrientation.fromByte(data[0])
            }

            GlassesConstant.GestureType.SLIDE_FORWARD.cmd,
            GlassesConstant.GestureType.SLIDE_BACKWARD.cmd,
            GlassesConstant.GestureType.SINGLE_TAP.cmd,
            GlassesConstant.GestureType.DOUBLE_TAP.cmd,
            GlassesConstant.GestureType.TRIPLE_TAP.cmd -> {
                val gestureType = GlassesConstant.GestureType.entries.find { it.cmd == cmd } ?: return
                val action = GlassesConstant.GestureAction.fromByte(data[0])
                action?.let { currentGestureSettings[gestureType] = it }
            }
        }
        tryEmitDeviceSettings()
    }

    private fun tryEmitDeviceSettings() {
        val gesturesComplete = currentGestureSettings.keys.containsAll(allGestureTypes)
        if (
//            deviceSettingsState.ledBrightness != null &&
            deviceSettingsState.recordDuration != null
            && deviceSettingsState.wearDetectionEnabled != null
//            && deviceSettingsState.voiceCommandEnabled != null
//            && deviceSettingsState.burstPhotoCount != null
            && deviceSettingsState.orientation != null
            && gesturesComplete
        ) {
            deviceSettingsState.gestureSettings = currentGestureSettings.toMap()
            emitEvent(CmdResultEvent.DeviceSettingsStateEvent(deviceSettingsState))
            deviceSettingsState = DeviceSettingsStateDTO()
            currentGestureSettings.clear()
        }
    }


    @OptIn(InternalCoroutinesApi::class)
    override fun connect(params: Any) {
        if (params !is BleComConfig) {
            val errorMsg = "Parameter type error"
            FissionLogUtils.e(TAG, errorMsg)
            // 发射一个错误事件
            emitEvent(ConnectionStateEvent.Failed(IllegalArgumentException(errorMsg)))
            return
        }

        if (params.context == null || params.mac == null){
            emitEvent(ConnectionStateEvent.Failed(IllegalArgumentException("params error")))
            return
        }

        synchronized(this@LYGlassesCmdStrategy) {
            if (isConnectInProgress) {
                FissionLogUtils.w(TAG, "设备连接进行中，忽略重复请求")
                return
            }
            isConnectInProgress = true
        }

        FissionLogUtils.i(TAG, "Starting to connect the device, MAC: ${params.mac?.substring(params.mac?.length?.minus(5) ?: 0)}")
        BleManager.connectDevice(
            sdkConfig.context,
            params.mac!!,
            scope,
            eventBus,
            isOtaMode = params.isOtaMode
        )
    }


    override fun reconnectBluetooth() {
        val device = BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice
        if (device == null || BleManager.currentDeviceManager?.bleConnection == null) {
            FissionLogUtils.w(TAG, "reconnectBluetooth skipped: BLE not connected")
            return
        }
        if (BtManager.areConfiguredProfilesConnected(device)) {
            FissionLogUtils.d(TAG, "reconnectBluetooth skipped: BT profiles already connected")
            BtManager.syncConnectionState(device)
            return
        }
        BtManager.onBleConnected(device)
    }

    override fun setVoiceDuration(times: Int) {

    }


    /**
     * @param times  单位s, 目前协议支持60， 180， 300， 540， 900秒
     */
    override fun setVideoDuration(times: Int) {
        val command: Byte = LY_CMD_RECORDING_DURATION.toByte()
        val data = times.toBytes(2)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun rebootDevice() {
        val command: Byte = LY_CMD_REBOOT_DEVICE.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun restoreFactorySettings() {
        val command: Byte = LY_CMD_RESTORE_FACTORY_SETTING.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    private suspend fun clearDeviceConnectionRecord(): Boolean {
        val command: Byte = LY_CMD_CLEAR_DEVICE_CONNECTION_RECORD.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        val success = BleManager.sendDataAndAwait(packet)
//        FissionLogUtils.d(TAG, "清除设备连接记录, success=$success")
        return success
    }

    override fun takePicture(takePhotoOnly: Boolean) {
        awaitingAiImageTransferAfterPhotoEnd = false
        lastPhotoCaptureTrigger =
            if (takePhotoOnly) PhotoCaptureTrigger.AI_RECOGNITION else PhotoCaptureTrigger.STORE_ON_DEVICE
        val command: Byte = LY_CMD_AI_IMAGE_RECOGNITION.toByte()
        val data = byteArrayOf(lastPhotoCaptureTrigger)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        FissionLogUtils.i(
            TAG,
            "发起AI拍照 trigger=0x${lastPhotoCaptureTrigger.toInt() and 0xFF} takePhotoOnly=$takePhotoOnly",
        )
        BleManager.sendData(packet)

//        if (takePhotoOnly) {
//            val command: Byte = LY_CMD_AI_IMAGE_RECOGNITION.toByte()
//            val data = byteArrayOf(0x31)
//            val packet = BlePacketUtils.buildBlePacket(header, command, data)
//            BleManager.sendData(packet)
//        } else {
//            ToastUtils.showShort(
//                sdkConfig.context.getString(R.string.sdk_local_storage_photo_not_supported)
//            )
//        }
    }

    override fun startVideoRecording() {
        val command: Byte = LY_CMD_START_RECORDING_VIDEO.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun stopVideoRecording() {
        val command: Byte = LY_CMD_STOP_RECORDING_VIDEO.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun startAiAssistant() {
        resetLyRawAudioDumpSession("0x18_OPEN_OPUS")
        val command: Byte = LY_CMD_OPEN_OPUS.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun stopAiAssistant() {
        stopVadAudio()
    }

    override fun interruptAiAssistant() {
        stopVadAudio()
    }

    override fun stopVadAudio() {
        val command: Byte = LY_CMD_VAD_STOP.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun setTime() {
        val command: Byte = LY_CMD_SET_TIME.toByte()
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR) - 2000
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)
        val data = byteArrayOf(
            year.toByte(),
            month.toByte(),
            day.toByte(),
            hour.toByte(),
            minute.toByte(),
            second.toByte()
        )
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---setTime---:" + BlePacketUtils.bytesToHex(packet))
        BleManager.sendData(packet)
    }

    override fun requestDeviceVersionInfo() {
        val command: Byte = LY_CMD_VERSION_INFO.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(
//            TAG,
//            "---requestDeviceVersionInfo---:" + BlePacketUtils.bytesToHex(packet)
//        )
        BleManager.sendData(packet)
    }

    override fun setLedBrightness(level: GlassesConstant.LedBrightnessLevel) {
        val command: Byte = LY_CMD_LED_INTENSITY.toByte()
        val data = byteArrayOf(level.data)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---setLedIntensity---:" + BlePacketUtils.bytesToHex(packet))
        BleManager.sendData(packet)
    }

    override fun setGestureShortcut(
        gesture: GlassesConstant.GestureType,
        action: GlassesConstant.GestureAction
    ) {
        val command: Byte = gesture.cmd
        val data = byteArrayOf(action.data)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---setGestureShortcut---:" + BlePacketUtils.bytesToHex(packet))
        BleManager.sendData(packet)

    }

    override fun setWearDetection(state: GlassesConstant.WearDetectionState) {
        val command: Byte = LY_CMD_SET_WEAR_DETECTION.toByte()
        val data = byteArrayOf(state.data)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---setWearDetection---: ${BlePacketUtils.bytesToHex(packet)}")
        BleManager.sendData(packet)
    }

    override fun setScreenOrientation(orientation: GlassesConstant.ScreenOrientation) {
        val command: Byte = LY_CMD_SET_SCREEN_ORIENTATION.toByte()
        val data = byteArrayOf(orientation.data)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---setScreenOrientation---: ${BlePacketUtils.bytesToHex(packet)}")
        BleManager.sendData(packet)

    }

    override fun resetGestureShortcuts() {
        val command: Byte = LY_CMD_RESET_GESTURE_SHORTCUT.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(
//            TAG,
//            "---slideBarGesturesRestoredDF---:" + BlePacketUtils.bytesToHex(packet)
//        )
        BleManager.sendData(packet)
    }

    override fun getDeviceSettingsState() {
        val command: Byte = LY_CMD_GET_DEVICE_SETTINGS_STATE.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(
//            TAG,
//            "---getDeviceSettingsState---: ${BlePacketUtils.bytesToHex(packet)}"
//        )
        BleManager.sendData(packet)
    }

    override fun startOTA(filePath: String, otaType: GlassesConstant.OtaType, version: String) {
        if (filePath.isEmpty() || !File(filePath).exists()) {
            FissionLogUtils.i(TAG, "startOTA-> OTA 文件不存在")
            emitEvent(OTAEvent.Failed("OTA 文件不存在", ERROR_CODE_OTA_FILE_NOT_FOUND))
            return
        }
        checkBleConnectPrecondition(
            BleManager.currentDeviceManager?.rxBleDevice?.connectionState == RxBleConnectionState.CONNECTED
        )?.let { failure ->
            FissionLogUtils.i(TAG, "startOTA-> ${failure.reason}")
            emitEvent(OTAEvent.Failed(failure.reason, failure.code))
            return
        }
        when (otaType) {
            GlassesConstant.OtaType.FIRMWARE -> {//杰理需要断开双模式
                BleManager.enterOtaMode()
                BleManager.currentDeviceManager?.rxBleDevice?.bluetoothDevice?.let { device ->
                    BtManager.disconnectConfiguredProfiles(device)
                }
                //杰理内部会抢连BT
                otaManager?.release()
                otaManager = OTAManager(sdkConfig.context, scope, filePath, eventBus)
                scope.launch {
                    AiAssistantClient.getInstance().beginWifiExclusiveSession()
                    otaManager?.startOTA()
                }
            }

            GlassesConstant.OtaType.WIFI_ISP -> {
                this.filePath = filePath
                this.pendingIspVersion = version
                this.ispFirmwareUploaded = false
                this.ispOtaResultHandled = false
                ispOtaJob?.cancel()
                operationType = GlassesConstant.OperationType.OTA
                scope.launch {
                    AiAssistantClient.getInstance().beginWifiExclusiveSession()
                    when {
                        sdkConfig.productSeries.usesIspTcpOta() -> {
                            wifiMode = GlassesConstant.WifiMode.AP_MODE
                            emitEvent(OTAEvent.Start)
                            powerOn()
                        }
                        else -> {
                            wifiMode = sdkConfig.productSeries.defaultWifiMode()
                            emitEvent(OTAEvent.Start)
                            powerOn()
                        }
                    }
                }
            }
        }
    }

    override fun startLiveStreaming(liveStreamingConfig: LiveStreamingConfig) {
        operationType = GlassesConstant.OperationType.LIVE
        this.liveStreamingConfig = liveStreamingConfig
        wifiMode = GlassesConstant.WifiMode.AP_MODE
        scope.launch {
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            val command: Byte = LY_CMD_SET_START_LIVE_STREAMING.toByte()
            val data = byteArrayOf(0x30)//ap: 0x30, p2p: 0x31
            val packet = BlePacketUtils.buildBlePacket(header, command, data)
            BleManager.sendData(packet)
        }
    }

    override fun startPushLiveStreaming(liveUrl: String) {
        FissionLogUtils.w(TAG, "Not supported for now：startPushLiveStreaming")
    }

    override fun stopLiveStreaming() {
        if (::operationType.isInitialized &&
            operationType == GlassesConstant.OperationType.LIVE
        ) {
            finishLyLiveSession(stopped = LiveEvent.RespStop)
            return
        }
        endAssistantAfterWifiExclusiveSession()
    }

    override fun setLivePreviewMicState(
        enableState: GlassesConstant.EnableState,
    ) {
        FissionLogUtils.w(TAG, "Not supported for now：setLivePreviewMicState")
    }

    /**
     * LY 直播 SDK 职责：连 AP → HTTP 启动设备推流 → 返回 [Network] + RTSP。
     * 预览播放由 App 自行处理。
     */
    private suspend fun startLyLiveSession() {
        val baseUrl = LyLiveEndpointResolver.resolveHttpBaseUrl(wifiMode, sdkConfig.productSeries)
        val documentRtspUrl = LyLiveEndpointResolver.resolveRtspUrl(wifiMode, sdkConfig.productSeries)
        FissionLogUtils.i(
            TAG,
            "LY 直播 Wi-Fi 已连接，启动设备推流: baseUrl=$baseUrl documentRtsp=$documentRtspUrl",
        )
        val started = LyLiveApi.startLiveStream(baseUrl)
        if (!started) {
            finishLyLiveSession(
                failed = LiveEvent.Failed(
                    "设备启动直播失败",
                    GlassesConstant.ERROR_CODE_LIVE_PREVIEW_START_FAILED,
                ),
            )
            return
        }
        delay(LY_LIVE_RTSP_START_DELAY_MS)
        val rtspHost = LyLiveEndpointResolver.resolveRtspHost(wifiMode, sdkConfig.productSeries)
        val rtspReady = LyLiveNetworkProbe.waitForRtspReady(rtspHost)
        if (!rtspReady) {
            FissionLogUtils.w(TAG, "RTSP 端口未就绪，仍返回地址: host=$rtspHost")
        }
        val apNetwork = WifiApConnectManager.getBoundApNetwork()
        if (apNetwork == null) {
            finishLyLiveSession(
                failed = LiveEvent.Failed(
                    "眼镜 AP Network 不可用",
                    GlassesConstant.ERROR_CODE_LIVE_PREVIEW_START_FAILED,
                ),
            )
            return
        }
        FissionLogUtils.i(
            TAG,
            "LY 直播就绪: rtsp=$documentRtspUrl apNetwork=$apNetwork",
        )
        emitEvent(LiveEvent.RespSuccess(rtsp = documentRtspUrl, apNetwork = apNetwork))
    }

    private fun finishLyLiveSession(
        failed: LiveEvent? = null,
        stopped: LiveEvent? = null,
    ) {
        liveStreamingConfig = null
        if (::operationType.isInitialized &&
            operationType == GlassesConstant.OperationType.LIVE
        ) {
            syncDownloadStatus(1, 1)
        }
        endAssistantAfterWifiExclusiveSession()
        when (wifiMode) {
            GlassesConstant.WifiMode.AP_MODE -> WifiApConnectManager.disconnect()
            GlassesConstant.WifiMode.P2P_MODE -> WifiDirectManager.disconnect()
        }
        failed?.let { emitEvent(it) }
        stopped?.let { emitEvent(it) }
    }

    override fun getActionState() {
        val command: Byte = LY_CMD_ACTION_SYNCHRONIZATION.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun setOfflineVoiceLanguage(language: GlassesConstant.OffLineLanguages) {
        val command: Byte = LY_CMD_SET_OFFLINE_VOICE_LANGUAGE.toByte()
        val data = byteArrayOf(when(language){
            GlassesConstant.OffLineLanguages.Chinese -> 0x00
            GlassesConstant.OffLineLanguages.English -> 0x01
        })
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
        FissionLogUtils.d(TAG, "设置离线语音语言: $language (0:CN, 1:EN)")
    }

    override fun controlMusic(enable: Boolean) {
        val command: Byte = LY_CMD_PLAY_OR_PAUSE_SONG.toByte()
        val data = byteArrayOf(if (enable) 0x01 else 0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun switchMusic(action: GlassesConstant.MusicSwitchAction) {
        val command: Byte = LY_CMD_PREVIOUS_OR_NEXT_SONG.toByte()
        val data = byteArrayOf(when(action){
            GlassesConstant.MusicSwitchAction.PREVIOUS -> 0x00
            GlassesConstant.MusicSwitchAction.NEXT     -> 0x01
        })
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun upVolume() {
        val command: Byte = LY_CMD_DOWN_OR_UP_VOLUME.toByte()
        val data = byteArrayOf(0x01)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun downVolume() {
        val command: Byte = LY_CMD_DOWN_OR_UP_VOLUME.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }


    override fun getGlassesVolume() {
        val command: Byte = LY_CMD_GET_VOLUME.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun setGlassesVolume(
        type: GlassesConstant.AudioVolumeType,
        volume: Int) {
        val realVolume = when(type){
            GlassesConstant.AudioVolumeType.SYSTEM -> volume.coerceIn(0, 15)
            GlassesConstant.AudioVolumeType.MEDIA  -> volume.coerceIn(0, 16)
            GlassesConstant.AudioVolumeType.CALL   -> volume.coerceIn(0, 15)
        }
        val command: Byte = LY_CMD_SET_VOLUME.toByte()
        val data = byteArrayOf(type.data, realVolume.toByte())
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
        FissionLogUtils.d(TAG, "设置音量: type-> ${type.displayName}  volume-> $realVolume")
    }

    override fun getDeviceSupportedFeatures() {
        val command: Byte = LY_CMD_GET_DEVICE_CONFIG.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun answerPhoneCall() {
        val command: Byte = LY_CMD_ANSWER_OR_HANG_UP_CALL.toByte()
        val data = byteArrayOf(0x01)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun hangUpPhoneCall() {
        val command: Byte = LY_CMD_ANSWER_OR_HANG_UP_CALL.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    fun sendIspVersion(version: String) {
        val command: Byte = LY_CMD_SET_ISP_VERSION.toByte()
        val parts = version.split(".")
        if (parts.size == 3) {
            val data = byteArrayOf(
                parts[0].toInt().toByte(),
                parts[1].toInt().toByte(),
                parts[2].toInt().toByte()
            )
            val packet = BlePacketUtils.buildBlePacket(header, command, data)
            BleManager.sendData(packet)
            FissionLogUtils.d(TAG, "发送 ISP 版本号: $version")
        }
    }

    override fun getDeviceStorage() {
        val command: Byte = LY_CMD_GET_DEVICE_STORAGE.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        FissionLogUtils.d(TAG, "---getDeviceStorage---:" + BlePacketUtils.bytesToHex(packet))
        BleManager.sendData(packet)
    }

    override fun getVoiceWakeUp() {
        val command: Byte = LY_CMD_GET_VOICE_COMMAND_DISABLE_STATE.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---getVoiceCommandDisableState---:" + BlePacketUtils.bytesToHex(packet))
        BleManager.sendData(packet)
    }

    override fun setVoiceWakeUp(
        localOfflineEnabled: Boolean,
        opusPushEnabled: Boolean
    ) {
        var disableMask = 0
        if (!localOfflineEnabled) {
            disableMask = disableMask or LyCmdConstant.VOICE_CMD_DISABLE_MASK_LOCAL_OFFLINE
        }
        if (!opusPushEnabled) {
            stopVadAudio()
            disableMask = disableMask or LyCmdConstant.VOICE_CMD_DISABLE_MASK_OPUS_STREAM
        }
        val command: Byte = LY_CMD_SET_VOICE_COMMAND_DISABLE_STATE.toByte()
        val data = byteArrayOf((disableMask and 0xFF).toByte())
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun getMediaFileCount() {
        val command: Byte = LY_CMD_GET_MEDIA_FILES.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
//        FissionLogUtils.d(TAG, "---getMediaFileCount---:" + BlePacketUtils.bytesToHex(packet))
        BleManager.sendData(packet)
    }


    /**
     * 0x31 value表示的是下载了几个文件
     */
   private fun syncDownloadStatus(downFileCount:Int, totalFileCount: Int){
        val command: Byte = LY_CMD_DOWNLOAD_COMPLETE.toByte()
        val data = if (downFileCount == totalFileCount && downFileCount > 0) byteArrayOf(0x30, 0x00) else byteArrayOf(0x31, downFileCount.toByte())

        FissionLogUtils.d(TAG, "同步下载状态: XX=${String.format("%02X", data[0])}, YY=${String.format("%02X", data[1])}")
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    private fun downloadComplete(downFileCount:Int, totalFileCount: Int) {
        endMediaSync()
        syncDownloadStatus(downFileCount, totalFileCount)
        connectAssistantWs()
    }

    private fun connectAssistantWs() {
        endAssistantAfterWifiExclusiveSession()
    }

    private fun endAssistantAfterWifiExclusiveSession() {
        AiAssistantClient.getInstance().endWifiExclusiveSession()
    }

    override fun aiImageRecognitionTts(baseWsMessage: BaseWsMessage<McpData>) {
        AiAssistantClient.getInstance().sendIotCommand(baseWsMessage)
    }


    fun setMicOptimization() {
        val command: Byte = LY_CMD_MIC_SETTING.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    fun setSedentaryReminder(min: Int) {
        val command: Byte = LY_CMD_SEDENTARY_REMINDER_SETTING.toByte()
        val data = min.toBytes(1)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    fun setAlarmClock(index: Int, isRepeated: Boolean, hour: Int, min: Int) {
        val command: Byte = LY_CMD_ALARM_CLOCK_SETTING.toByte()
        val repeatByte: Byte = if (isRepeated) 0x02 else 0x01

        // 将小时 and 分钟转成 4 个 ASCII 字节
        val hourStr = hour.toString().padStart(2, '0')
        val minStr = min.toString().padStart(2, '0')
        val timeBytes = byteArrayOf(
            hourStr[0].code.toByte(),
            hourStr[1].code.toByte(),
            minStr[0].code.toByte(),
            minStr[1].code.toByte()
        )

        val data = byteArrayOf(index.toByte(), repeatByte) + timeBytes
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    fun deleteAlarmClock(index: Int) {
        val command: Byte = LY_CMD_DELETE_ALARM_CLOCK.toByte()
        val data = byteArrayOf(index.toByte())
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun getBatteryLevel() {
        val command: Byte = LY_CMD_GET_BATTERY_LEVEL.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun startDeviceRecording() {
        val command: Byte = LY_CMD_START_OR_STOP_RECORD.toByte()
        val data = byteArrayOf(0x01)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    override fun stopDeviceRecording() {
        val command: Byte = LY_CMD_START_OR_STOP_RECORD.toByte()
        val data = byteArrayOf(0x00)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    fun setPhotoParameters(ratio: Byte, clarity: Byte) {
        val command: Byte = LY_CMD_PHOTO_STYLE.toByte()
        val data = byteArrayOf(ratio, clarity)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

   private fun getImage(type: Int) {
        val command: Byte = LY_CMD_GET_IMAGE.toByte()
        val data = byteArrayOf(type.toByte())
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        FissionLogUtils.d(
            TAG,
            "请求拉取图片 type=0x${type.toString(16)} packet=${BlePacketUtils.bytesToHex(packet)}",
        )
        BleManager.sendData(packet)
    }

    private fun requestImageTransfer(trigger: Byte) {
        getImage(trigger.toInt() and 0xFF)
    }

    private fun tryRequestAiImageTransferAfterPhotoEnd() {
        if (!awaitingAiImageTransferAfterPhotoEnd) return
        if (lastPhotoCaptureTrigger != PhotoCaptureTrigger.AI_RECOGNITION) {
            awaitingAiImageTransferAfterPhotoEnd = false
            return
        }
        if (!isTakePhotoEnded()) {
            FissionLogUtils.d(TAG, "拍照尚未结束，继续等待动作同步")
            return
        }
        awaitingAiImageTransferAfterPhotoEnd = false
        FissionLogUtils.d(
            TAG,
            "拍照已结束，请求拉取图片 trigger=0x${lastPhotoCaptureTrigger.toInt() and 0xFF}",
        )
        requestImageTransfer(lastPhotoCaptureTrigger)
    }

    private fun isTakePhotoEnded(): Boolean {
        val photoIndex = ActionSyncType.TAKE_PHOTO.index
        return lastActionStates?.getOrNull(photoIndex) == 0x00.toByte()
    }

    private fun handleAiImageRecognitionFailed(reason: String) {
        awaitingAiImageTransferAfterPhotoEnd = false
        AiAssistantClient.getInstance().clearPendingAiImageRecognition()
        emitEvent(CmdResultEvent.Fail(reason, ERROR_CODE_IMAGE_RECOGNITION))
    }

    fun setSosPhoneNum(phoneNum: String) {
        val command: Byte = LY_CMD_SET_SOS_PHONE.toByte()
        val data = phoneNum.map { it.code.toByte() }.toByteArray()
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }

    fun setPhotoMode(mode: Byte) {
        val command: Byte = LY_CMD_PHOTO_MODE.toByte()
        val data = byteArrayOf(mode)
        val packet = BlePacketUtils.buildBlePacket(header, command, data)
        BleManager.sendData(packet)
    }



    override fun deviceShutDown() {

    }

    @OptIn(InternalCoroutinesApi::class)
    override fun syncAllMediaFile(wifiMode: GlassesConstant.WifiMode) {
        if (!sdkConfig.productSeries.isWifiModeSupported(wifiMode)) {
            FissionLogUtils.w(
                TAG,
                "系列 ${sdkConfig.productSeries.code} 不支持 Wi-Fi 模式 $wifiMode，" +
                    "支持: ${sdkConfig.productSeries.supportedWifiModes()}"
            )
            emitEvent(
                FileSyncEvent.Failed(
                    "当前设备系列不支持该 Wi-Fi 模式",
                    GlassesConstant.ERROR_CODE_WIFI_UNKNOWN_ERROR,
                )
            )
            return
        }
        synchronized(this@LYGlassesCmdStrategy) {
            if (isMediaSyncInProgress) {
                if (isMediaWifiConnectSuccess) {
                    FissionLogUtils.w(TAG, "媒体同步进行中，忽略重复请求")
                    return
                }
                FissionLogUtils.w(
                    TAG,
                    "Wi-Fi 尚未连上，取消进行中的连接并重试媒体同步"
                )
                cancelMediaSyncWifiConnect()
            }
            isMediaSyncInProgress = true
            isMediaWifiConnectSuccess = false
            scope.launch {
                AiAssistantClient.getInstance().beginWifiExclusiveSession()
                operationType = GlassesConstant.OperationType.MEDIA_SYNC
                this@LYGlassesCmdStrategy.wifiMode = wifiMode
                lyWifiDownloadManager?.release()
                val mediaDir =
                    File(sdkConfig.context.filesDir, sdkConfig.mediaFilesStorageDirName).apply { mkdirs() }
                lyWifiDownloadManager =
                    LyWifiDownloadManager(
                        eventBus,
                        scope,
                        wifiMode,
                        sdkConfig.productSeries,
                        mediaDir.absolutePath,
                    )
                openWifi()
            }
        }
    }

    private fun cancelMediaSyncWifiConnect() {
        cancelWifiNameCallbackTimeout()
        when (wifiMode) {
            GlassesConstant.WifiMode.AP_MODE -> WifiApConnectManager.disconnect()
            GlassesConstant.WifiMode.P2P_MODE -> WifiDirectManager.disconnect()
        }
        lyWifiDownloadManager?.release()
        lyWifiDownloadManager = null
        isMediaSyncInProgress = false
        isMediaWifiConnectSuccess = false
    }

    private fun startReceivingAudio(mode: String, language: Int) {
        AiAssistantClient.getInstance().startListening(mode, language)
    }

    private fun sendReceivingAudioData(mode: String, byteArray: ByteArray) {
        AiAssistantClient.getInstance().sendAudio(mode, byteArray)
    }

    private fun stopReceivingAudio(mode: String) {
        AiAssistantClient.getInstance().stopListening(mode)
    }

    private fun cancelReceivingAudio() {
        AiAssistantClient.getInstance().abort()
    }

    /**
     * 同步文件开 Wi‑Fi：发 [LY_CMD_SET_WIFI_CONFIG]，开启结果等 [LY_CMD_WIFI_NAME]。
     * ISP 升级勿调用（应走 [powerOn]）。
     */
    private fun openWifi() {
        scope.launch {
            val command: Byte = LY_CMD_SET_WIFI_CONFIG.toByte()
            val data = when (wifiMode) {
                GlassesConstant.WifiMode.AP_MODE -> byteArrayOf(0x30)
                GlassesConstant.WifiMode.P2P_MODE -> byteArrayOf(0x31)
            }
            val packet = BlePacketUtils.buildBlePacket(header, command, data)
            FissionLogUtils.d(
                TAG,
                "openWifi 发送 LY_CMD_SET_WIFI_CONFIG: ${BlePacketUtils.bytesToHex(packet)}, wifiMode=$wifiMode"
            )
            val writeOk = BleManager.sendDataAndAwait(packet, OPEN_WIFI_BLE_WRITE_TIMEOUT_MS)
            if (!writeOk) {
                FissionLogUtils.e(
                    TAG,
                    "openWifi BLE 写入失败或超时 (${OPEN_WIFI_BLE_WRITE_TIMEOUT_MS}ms)"
                )
                if (::operationType.isInitialized &&
                    operationType == GlassesConstant.OperationType.MEDIA_SYNC
                ) {
                    emitEvent(
                        FileSyncEvent.Failed(
                            "Wi-Fi配置指令发送失败",
                            ERROR_CODE_WIFI_OPEN_ERROR
                        )
                    )
                }
                return@launch
            }
            startWifiNameCallbackTimeout()
        }
    }

    private fun endMediaSync() {
        isMediaSyncInProgress = false
        isMediaWifiConnectSuccess = false
        cancelWifiNameCallbackTimeout()
    }

    /**
     * 中立 AP 连接失败/断开（[WifiApEvent.Failed]/[WifiApEvent.Disconnected]）按当前业务转发：
     * 直播→[LiveEvent.Failed]，ISP→[OTAEvent.Failed]，文件同步→[FileSyncEvent.Failed]。
     * 隔离后直播/ISP 的 AP 连接失败不再发 [FileSyncEvent]，避免串味到 App 媒体同步页。
     */
    private fun handleApConnectionFailed(reason: String, code: Int) {
        if (!::operationType.isInitialized) return
        when (operationType) {
            GlassesConstant.OperationType.OTA -> {
                finishIspOtaWifi()
                if (!ispOtaResultHandled) {
                    ispOtaResultHandled = true
                    emitEvent(OTAEvent.Failed(reason, code))
                }
                endAssistantAfterWifiExclusiveSession()
            }

            GlassesConstant.OperationType.LIVE -> {
                finishLyLiveSession(failed = LiveEvent.Failed(reason, code))
            }

            GlassesConstant.OperationType.MEDIA_SYNC -> {
                // 转成文件同步失败：对外发 FileSyncEvent.Failed，由 collect 分支做媒体同步收尾
                emitEvent(FileSyncEvent.Failed(reason, code))
            }
        }
    }

    @OptIn(InternalCoroutinesApi::class)
    private fun endConnect() {
        synchronized(this@LYGlassesCmdStrategy) {
            isConnectInProgress = false
        }
    }

    /**
     * 等待 [LY_CMD_WIFI_NAME]（ISP 的 POWER_ON / 同步文件的 SET_WIFI_CONFIG 开启结果共用）。
     */
    private fun startWifiNameCallbackTimeout() {
        cancelWifiNameCallbackTimeout()
        wifiNameCallbackTimeoutJob = scope.launch {
            delay(WIFI_NAME_CALLBACK_TIMEOUT_MS)
            if (!::operationType.isInitialized) return@launch
            FissionLogUtils.e(
                TAG,
                "等待 LY_CMD_WIFI_NAME 回调超时 (${WIFI_NAME_CALLBACK_TIMEOUT_MS}ms)"
            )
            when (operationType) {
                GlassesConstant.OperationType.OTA -> {
                    if (!ispOtaResultHandled) {
                        ispOtaResultHandled = true
                        emitEvent(
                            OTAEvent.Failed(
                                "Wi-Fi设备发现超时",
                                ERROR_CODE_WIFI_DEVICE_DISCOVERY_TIMEOUT
                            )
                        )
                    }
                }
                GlassesConstant.OperationType.MEDIA_SYNC -> {
                    emitEvent(
                        FileSyncEvent.Failed(
                            "Wi-Fi设备发现超时",
                            ERROR_CODE_WIFI_DEVICE_DISCOVERY_TIMEOUT
                        )
                    )
                }
                else -> Unit
            }
        }
    }

    private fun cancelWifiNameCallbackTimeout() {
        wifiNameCallbackTimeoutJob?.cancel()
        wifiNameCallbackTimeoutJob = null
    }

    private fun startIspTcpOta() {
        if (ispOtaResultHandled) {
            FissionLogUtils.w(TAG, "ISP OTA 已结束，忽略重复的 TCP OTA")
            resetIspOtaWifiSessionState()
            return
        }
        if (!::filePath.isInitialized) {
            emitEvent(OTAEvent.Failed("OTA 文件不存在", ERROR_CODE_OTA_FILE_NOT_FOUND))
            return
        }
        ispOtaJob?.cancel()
        ispOtaJob = scope.launch {
            val result = LyIspTcpOtaClient.upload(
                file = File(filePath),
                onProgress = { progress ->
                    emitEvent(
                        OTAEvent.Progress(
                            progress,
                            GlassesConstant.OTAStage.OTA
                        )
                    )
                },
                onFileUploaded = {
                    ispFirmwareUploaded = true
                    FissionLogUtils.d(TAG, "T系列 ISP 固件上传完成，开始接受 0x96")
                }
            )
            // T 系列：升级成功/失败均无需 App 关机，仅记录状态并释放 Wi-Fi
            releaseIspOtaWifi()
            when (result) {
                is LyIspTcpOtaClient.Result.Success -> {
                    if (!ispOtaResultHandled) {
                        ispOtaResultHandled = true
                        emitEvent(OTAEvent.Success)
                        pendingIspVersion?.let {
                            sendIspVersion(it)
                            pendingIspVersion = null
                        }
                    }
                }
                is LyIspTcpOtaClient.Result.Failed -> {
                    if (!ispOtaResultHandled) {
                        ispOtaResultHandled = true
                        emitEvent(OTAEvent.Failed(result.reason, result.code))
                    }
                }
            }
        }
    }

    /** S 系列旧方案：HTTP multipart 上传 OTA 文件。 */
    private fun startIspHttpOta() {
        if (ispOtaResultHandled) {
            FissionLogUtils.w(TAG, "ISP OTA 已结束，忽略重复的 HTTP OTA")
            resetIspOtaWifiSessionState()
            return
        }
        if (!::filePath.isInitialized) {
            emitEvent(OTAEvent.Failed("File does not exist", ERROR_CODE_OTA_FILE_NOT_FOUND))
            return
        }
        ispOtaJob?.cancel()
        ispOtaJob = scope.launch {
            MediaRepository.uploadOtaFile(
                file = File(filePath),
                onProgress = { progress ->
                    if (progress == 100) {
                        ispFirmwareUploaded = true
                        FissionLogUtils.d(TAG, "S系列 ISP 固件上传完成")
                        emitEvent(OTAEvent.Success)
                    }
                    emitEvent(
                        OTAEvent.Progress(
                            progress,
                            GlassesConstant.OTAStage.OTA
                        )
                    )
                }
            )
            // 若进度未到 100 但请求已结束，也视为上传结束（后续才可处理 0x96）
            if (!ispFirmwareUploaded) {
                ispFirmwareUploaded = true
                FissionLogUtils.d(TAG, "S系列 ISP 上传结束")
            }
        }
    }

    /** 中止进行中的 ISP OTA 任务并断开 Wi-Fi（不向设备发关机指令）。 */
    private fun finishIspOtaWifi() {
        ispOtaJob?.cancel()
        ispOtaJob = null
        releaseIspOtaWifi()
    }

    /**
     * 根据 BLE [LY_CMD_ISP_UPGRADE_RESULT] 结束 ISP OTA（含 POWER_ON 后直接回成功的场景）。
     */
    private fun completeIspOtaFromBleResult(success: Boolean) {
        if (ispOtaResultHandled) return
        ispOtaResultHandled = true
        cancelWifiNameCallbackTimeout()
        finishIspOtaWifi()
        if (success) {
            emitEvent(OTAEvent.Success)
            pendingIspVersion?.let {
                sendIspVersion(it)
                pendingIspVersion = null
            }
        } else {
            emitEvent(OTAEvent.Failed("ISP升级失败"))
        }
    }

    private fun releaseIspOtaWifi() {
        cancelWifiNameCallbackTimeout()
        when (wifiMode) {
            GlassesConstant.WifiMode.AP_MODE -> WifiApConnectManager.disconnect()
            GlassesConstant.WifiMode.P2P_MODE -> WifiDirectManager.disconnect()
        }
    }

    /**
     * ISP OTA 已出最终结果后重置 Wi-Fi 会话，避免设备重启后重复上报 SSID 再次连 AP 并触发 OTA。
     */
    private fun resetIspOtaWifiSessionState() {
        ispOtaJob = null
        releaseIspOtaWifi()
        wifiMode = sdkConfig.productSeries.defaultWifiMode()
    }

    /**
     * ISP 升级开 Wi‑Fi：发 [LY_CMD_POWER_ON]，开启结果等 [LY_CMD_WIFI_NAME]；
     * 升级结果看 [LY_CMD_ISP_UPGRADE_RESULT]。同步文件开 Wi‑Fi 走 [openWifi]。
     */
    private fun powerOn() {
        scope.launch {
            val command: Byte = LY_CMD_POWER_ON.toByte()
            val data = byteArrayOf(0x30)
            val packet = BlePacketUtils.buildBlePacket(header, command, data)
            FissionLogUtils.d(
                TAG,
                "powerOn 发送 LY_CMD_POWER_ON: ${BlePacketUtils.bytesToHex(packet)}"
            )
            val writeOk = BleManager.sendDataAndAwait(packet, OPEN_WIFI_BLE_WRITE_TIMEOUT_MS)
            if (!writeOk) {
                FissionLogUtils.e(
                    TAG,
                    "powerOn BLE 写入失败或超时 (${OPEN_WIFI_BLE_WRITE_TIMEOUT_MS}ms)"
                )
                if (!ispOtaResultHandled) {
                    ispOtaResultHandled = true
                    emitEvent(
                        OTAEvent.Failed(
                            "Wi-Fi开机指令发送失败",
                            ERROR_CODE_WIFI_OPEN_ERROR
                        )
                    )
                }
                return@launch
            }
            startWifiNameCallbackTimeout()
        }
    }

}
