package com.fission.wear.glasses.sdk.service

import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.fission.wear.glasses.sdk.manager.BleManager
import com.fission.wear.glasses.sdk.util.NotificationUtils

/**
 * describe:
 * author: wl
 * createTime: 2025/9/9
 */
class BleComService : Service() {

    private val binder = BleServiceBinder()

    inner class BleServiceBinder : Binder() {
        fun getManager(): BleManager = BleManager
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForeground(
            1,
            NotificationUtils.createForegroundNotification(this, "蓝牙服务运行中")
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        BleManager.currentDeviceManager
    }
}
