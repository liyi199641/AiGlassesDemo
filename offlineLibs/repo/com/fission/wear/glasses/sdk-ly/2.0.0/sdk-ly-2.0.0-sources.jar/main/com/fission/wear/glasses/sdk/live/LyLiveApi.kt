package com.fission.wear.glasses.sdk.live

import com.fission.wear.glasses.sdk.data.repository.XmlRetrofitClient
import com.fission.wear.glasses.sdk.util.FissionLogUtils

/** LY 直播：通过设备 HTTP 接口启动 RTSP 推流。 */
internal object LyLiveApi {

    private const val TAG = "LyLiveApi"

    suspend fun startLiveStream(baseUrl: String): Boolean {
        val response = runCatching {
            XmlRetrofitClient.invokeFunctionCommand(baseUrl, LyLiveEndpointResolver.LIVE_START_ENDPOINT)
        }.getOrElse { error ->
            FissionLogUtils.e(TAG, "startLiveStream request failed: ${error.message}")
            return false
        }
        val success = XmlRetrofitClient.isFunctionCommandSuccess(response)
        FissionLogUtils.i(
            TAG,
            "startLiveStream baseUrl=$baseUrl cmd=${response.cmd} status=${response.status} success=$success",
        )
        return success
    }
}
