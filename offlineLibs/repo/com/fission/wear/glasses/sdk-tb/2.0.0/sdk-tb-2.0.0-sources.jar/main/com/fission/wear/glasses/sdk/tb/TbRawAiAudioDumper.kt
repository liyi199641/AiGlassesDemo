package com.fission.wear.glasses.sdk.tb

import android.content.Context
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * 保存 TB [aIRecordData] 原始 Opus 上行包，便于离线分析。
 *
 * 输出目录：`filesDir/tb_raw_ai_audio/session_<ts>/`
 * - `raw.opus.bin`：按 `[uint32_be length][opus payload]` 逐包拼接
 * - `meta.txt`：会话元信息与每包序号/长度
 *
 * Logcat 过滤 `TB_RAW_AI_AUDIO` 查看路径。
 */
internal class TbRawAiAudioDumper(
    private val context: Context,
) {
    private val ioLock = Any()
    private var sessionDir: File? = null
    private var rawStream: FileOutputStream? = null
    private var metaWriter: BufferedWriter? = null
    private var packetSeq = 0
    private var totalBytes = 0L

    fun beginSession(trigger: String) {
        synchronized(ioLock) {
            beginSessionLocked(trigger)
        }
    }

    fun appendPacket(opus: ByteArray) {
        if (opus.isEmpty()) return
        synchronized(ioLock) {
            if (rawStream == null) {
                beginSessionLocked("aIRecordData_first_packet")
            }
            appendPacketLocked(opus)
        }
    }

    fun endSession(reason: String) {
        synchronized(ioLock) {
            if (sessionDir == null) return
            FissionLogUtils.iTag(
                TAG,
                "dump_end reason=$reason packets=$packetSeq bytes=$totalBytes path=${sessionDir?.absolutePath ?: "n/a"}",
            )
            closeLocked(reason)
        }
    }

    private fun beginSessionLocked(trigger: String) {
        closeLocked("beginSession_replace")
        val root = File(context.filesDir, DUMP_DIR_NAME).apply { mkdirs() }
        val dir = File(root, "session_${System.currentTimeMillis()}").apply { mkdirs() }
        sessionDir = dir
        rawStream = FileOutputStream(File(dir, RAW_FILE_NAME))
        metaWriter = File(dir, META_FILE_NAME).bufferedWriter().apply {
            write("trigger=$trigger\n")
            write("format=length_prefixed_opus_uint32_be\n")
            write("sample_rate=16000\n")
            write("channels=1\n")
            flush()
        }
        packetSeq = 0
        totalBytes = 0L
        lastSessionPath = dir.absolutePath
        FissionLogUtils.iTag(TAG, "dump_start trigger=$trigger path=${dir.absolutePath}")
    }

    private fun appendPacketLocked(opus: ByteArray) {
        val stream = rawStream ?: return
        packetSeq++
        totalBytes += opus.size
        val lengthPrefix = ByteBuffer.allocate(4)
            .order(ByteOrder.BIG_ENDIAN)
            .putInt(opus.size)
            .array()
        stream.write(lengthPrefix)
        stream.write(opus)
        stream.flush()
        metaWriter?.apply {
            write("seq=$packetSeq size=${opus.size}\n")
            if (packetSeq % 50 == 0) {
                flush()
            }
        }
    }

    private fun closeLocked(reason: String) {
        metaWriter?.runCatching {
            write("end_reason=$reason\n")
            write("packet_count=$packetSeq\n")
            write("total_opus_bytes=$totalBytes\n")
            flush()
            close()
        }
        metaWriter = null
        rawStream?.runCatching {
            flush()
            close()
        }
        rawStream = null
        sessionDir = null
        packetSeq = 0
        totalBytes = 0L
    }

    companion object {
        const val TAG = "TB_RAW_AI_AUDIO"
        private const val DUMP_DIR_NAME = "tb_raw_ai_audio"
        private const val RAW_FILE_NAME = "raw.opus.bin"
        private const val META_FILE_NAME = "meta.txt"

        /** 最近一次 dump 会话目录，便于 adb pull。 */
        @Volatile
        var lastSessionPath: String? = null
            private set
    }
}
