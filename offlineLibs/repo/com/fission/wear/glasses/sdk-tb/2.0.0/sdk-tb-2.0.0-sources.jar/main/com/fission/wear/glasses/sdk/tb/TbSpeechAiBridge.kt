package com.fission.wear.glasses.sdk.tb

import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.topstep.wearkit.apis.WKWearKit
import com.topstep.wearkit.apis.model.speech.WKSpeechAiMessage
import com.topstep.wearkit.apis.model.speech.WKSpeechSession
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.disposables.Disposable

/**
 * 收到 Session 后立即订阅 [WKSpeechSession.audio] 并转发音频。
 */
internal class TbSpeechAiBridge(
    private val wearKitProvider: () -> WKWearKit?,
    private val callbacks: Callbacks,
) {
    interface Callbacks {
        fun onSessionStarted(scene: WKSpeechSession.Scene, origin: WKSpeechSession.Origin)
        fun onAudioData(bytes: ByteArray)
        fun onSessionEnded(scene: WKSpeechSession.Scene, reason: String)
    }

    private val tag = "TbSpeechAiBridge"
    private val rootDisposables = CompositeDisposable()
    private var sessionDisposables = CompositeDisposable()
    private var activeSession: WKSpeechSession? = null
    private var deviceSessionObserving = false

    val isSupported: Boolean
        get() = wearKitProvider()?.speechAiAbility?.isSupport() == true

    fun hasActiveSession(): Boolean = activeSession?.isActive() == true

    fun start() {
        val wearKit = wearKitProvider() ?: return
        val speechAi = wearKit.speechAiAbility
        if (!speechAi.isSupport()) {
            FissionLogUtils.d(tag, "speechAiAbility not supported, use legacy aIRecordData path")
            return
        }
        if (deviceSessionObserving) return
        deviceSessionObserving = true
        FissionLogUtils.d(tag, "start observeDeviceSession")
        rootDisposables.add(
            speechAi.session.observeDeviceSession()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { session ->
                        FissionLogUtils.d(
                            tag,
                            "device session scene=${session.scene} origin=${session.origin} source=${session.source}",
                        )
                        attachSession(session)
                    },
                    { error ->
                        FissionLogUtils.w(tag, "observeDeviceSession error: ${error.message}")
                        deviceSessionObserving = false
                    },
                ),
        )
    }

    fun stopActiveSession(reason: String = "app_stop") {
        val session = activeSession ?: return
        val scene = session.scene
        releaseSessionInternal(session, reason)
        callbacks.onSessionEnded(scene, reason)
    }

    fun release() {
        releaseSessionInternal(activeSession, "bridge_release")
        activeSession = null
        sessionDisposables.clear()
        rootDisposables.clear()
        deviceSessionObserving = false
    }

    private fun attachSession(session: WKSpeechSession) {
        releaseSessionInternal(activeSession, "replaced")
        when (session.scene) {
            WKSpeechSession.Scene.CHAT,
            WKSpeechSession.Scene.RECORD,
            WKSpeechSession.Scene.CALL_RECORD,
            -> {
                activeSession = session
                sessionDisposables = CompositeDisposable()
                sessionDisposables.add(
                    wearKitProvider()?.speechAiAbility?.observeMessage()
                        ?.observeOn(AndroidSchedulers.mainThread())
                        ?.subscribe(
                            { msg ->
                                if (msg.type == WKSpeechAiMessage.Type.SCENE_EXIT &&
                                    msg.data == session.scene
                                ) {
                                    FissionLogUtils.d(tag, "SCENE_EXIT scene=${session.scene}")
                                    val endedScene = session.scene
                                    releaseSessionInternal(session, "SCENE_EXIT")
                                    callbacks.onSessionEnded(endedScene, "SCENE_EXIT")
                                }
                            },
                            { error ->
                                FissionLogUtils.w(tag, "observeMessage error: ${error.message}")
                            },
                        )
                        ?: Disposable.empty(),
                )
                callbacks.onSessionStarted(session.scene, session.origin)
                subscribeAudio(session)
            }

            else -> {
                FissionLogUtils.d(tag, "ignore unsupported scene=${session.scene}")
                session.release()
            }
        }
    }

    private fun subscribeAudio(session: WKSpeechSession) {
        sessionDisposables.add(
            session.audio()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { bytes ->
                        if (bytes.isEmpty()) return@subscribe
                        callbacks.onAudioData(bytes)
                    },
                    { error ->
                        FissionLogUtils.w(tag, "session audio error scene=${session.scene}: ${error.message}")
                        val scene = session.scene
                        releaseSessionInternal(session, error.message ?: "audio_error")
                        callbacks.onSessionEnded(scene, error.message ?: "audio_error")
                    },
                    {
                        FissionLogUtils.d(tag, "session audio complete scene=${session.scene}")
                        val scene = session.scene
                        releaseSessionInternal(session, "audio_complete")
                        callbacks.onSessionEnded(scene, "audio_complete")
                    },
                ),
        )
    }

    private fun releaseSessionInternal(session: WKSpeechSession?, reason: String) {
        if (session == null) return
        if (activeSession === session) {
            activeSession = null
        }
        sessionDisposables.clear()
        runCatching {
            if (session.isActive()) {
                FissionLogUtils.d(tag, "release session scene=${session.scene} reason=$reason")
                session.release()
            }
        }.onFailure {
            FissionLogUtils.w(tag, "session.release failed: ${it.message}")
        }
    }
}
