package com.fission.wear.glasses.sdk.tb

import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ChannelType
import com.fission.wear.glasses.sdk.events.GlassesCmdStrategy
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.strategy.AiUplinkProfile
import com.fission.wear.glasses.sdk.strategy.GlassesStrategyFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow

class TbStrategyFactory : GlassesStrategyFactory {
    override val channel: ChannelType = ChannelType.TB

    /** Opus / 16kHz；channel 待厂商确认（当前按单声道 1 配置 WS sdk-type）。 */
    override val aiUplinkProfile: AiUplinkProfile = AiUplinkProfile(
        glassesUplinkFormat = "opus",
        sampleRate = 16000,
        deviceChannel = 1,
    )

    override fun create(
        config: SdkConfig,
        eventFlow: MutableSharedFlow<GlassesEvent>,
        scope: CoroutineScope,
    ): GlassesCmdStrategy = TbGlassesCmdStrategy(config, eventFlow, scope)
}
