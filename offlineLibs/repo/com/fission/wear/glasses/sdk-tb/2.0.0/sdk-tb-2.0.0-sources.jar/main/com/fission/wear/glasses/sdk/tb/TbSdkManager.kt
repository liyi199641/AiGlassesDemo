package com.fission.wear.glasses.sdk.tb

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.Observer
import com.bluetrum.devicemanager.cmd.request.DeviceInfoRequest
import com.bluetrum.devicemanager.cmd.request.GlassCameraTurnOnRequest
import com.bluetrum.devicemanager.models.AIPicPackage
import com.bluetrum.devicemanager.models.DevicePower
import com.bluetrum.devicemanager.models.GlassVolume
import com.bluetrum.devicemanager.models.MediaInfoMode
import com.bluetrum.devicemanager.models.SpaceInfoMode
import com.fission.wear.glasses.sdk.config.BleComConfig
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.data.cache.GlassesSpUtil
import com.fission.wear.glasses.sdk.data.dto.DeviceCapacityInfoDTO
import com.fission.wear.glasses.sdk.data.dto.DeviceSettingsStateDTO
import com.fission.wear.glasses.sdk.data.dto.DeviceVersionInfoDTO
import com.fission.wear.glasses.sdk.events.CmdResultEvent
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent
import com.fission.wear.glasses.sdk.events.FileSyncEvent
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.events.LiveEvent
import com.fission.wear.glasses.sdk.events.OTAEvent
import com.fission.wear.glasses.sdk.util.BluetoothUnpairHelper
import com.fission.wear.glasses.sdk.util.FileTransferSpeedFormatter
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.topstep.aibuds.earphone.ABMateManager
import com.topstep.aibuds.earphone.ABMateOTAManager
import com.topstep.wearkit.abmate.apis.AbMateSDK
import com.topstep.wearkit.apis.WKWearKit
import com.topstep.wearkit.apis.exception.WKFileTransferException
import com.topstep.wearkit.apis.model.core.WKAuthMode
import com.topstep.wearkit.apis.model.core.WKConnectorState
import com.topstep.wearkit.apis.model.core.WKDeviceType
import com.topstep.wearkit.apis.model.file.WKFileTransferEvent
import com.topstep.wearkit.apis.model.speech.WKSpeechSession
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers
import io.reactivex.rxjava3.disposables.CompositeDisposable
import io.reactivex.rxjava3.disposables.Disposable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import java.io.File

internal class TbSdkManager(
    private val sdkConfig: SdkConfig,
    private val scope: CoroutineScope,
    private val eventBus: MutableSharedFlow<GlassesEvent>,
) {
    private val TAG = "TbSdkManager"
    private val mainHandler = Handler(Looper.getMainLooper())
    private val disposables = CompositeDisposable()

    private var wearKit: WKWearKit? = null
    private var abMateSdk: AbMateSDK? = null
    private var abMateManager: ABMateManager? = null
    private val otaManager = ABMateOTAManager()
    private val actionSyncHelper = TbActionSyncHelper { type, active ->
        emit(CmdResultEvent.ActionSync(type, active))
    }

    private var deviceAddress: String? = null
    private var isOtaMode: Boolean = false
    private var pullDisposable: Disposable? = null
    private var wifiOtaDisposable: Disposable? = null
    private var connectorDisposable: Disposable? = null

    private var powerObserver: Observer<DevicePower?>? = null
    private var volumeObserver: Observer<GlassVolume?>? = null
    private var storageObserver: Observer<SpaceInfoMode?>? = null
    private var mediaCountObserver: Observer<MediaInfoMode?>? = null
    private var glassVersionObserver: Observer<String?>? = null
    private var firmwareVersionObserver: Observer<Int?>? = null
    private var aiPicObserver: Observer<AIPicPackage?>? = null
    private var aiRecordDataObserver: Observer<ByteArray?>? = null
    private var stateAIChatObserver: Observer<Int?>? = null

    /** AI 识图：拍照后等待 aiPicPackage 分片回传 */
    private var awaitingAiPicTransfer = false
    private val aiPicChunks = ArrayList<ByteArray>()

    var onAiImageBytesReady: ((ByteArray) -> Unit)? = null
    var onAiChatStateChanged: ((Int) -> Unit)? = null
    var onAiRecordData: ((ByteArray) -> Unit)? = null
    var onGlassWorkStateChanged: ((Int) -> Unit)? = null

    private var lastGlassVersion: String? = null
    private var lastFirmwareVersion: String? = null
    private var pendingVersionRequest = false
    private var pendingCapacityRequest = false
    private var pendingVolumeRequest = false
    private var pendingSettingsRequest = false
    private var pendingVoiceWakeUpRequest = false
    private var repositoryObserversAttached = false

    private var videoLimitObserver: Observer<Int?>? = null
    private var audioLimitObserver: Observer<Int?>? = null
    private var supportAudioObserver: Observer<Int?>? = null
    private var screenConfigObserver: Observer<ByteArray?>? = null
    private var voiceRecognitionObserver: Observer<Boolean?>? = null
    private var glassWorkStateObserver: Observer<Int?>? = null
    private var glassTakePhotoObserver: Observer<Int?>? = null
    private var deviceInEarObserver: Observer<Boolean?>? = null
    private var settingsPublishTimeoutRunnable: Runnable? = null
    private var speechAiBridge: TbSpeechAiBridge? = null

    var onSpeechAiSessionStarted: ((scene: WKSpeechSession.Scene) -> Unit)? = null
    var onSpeechAiAudioData: ((ByteArray) -> Unit)? = null
    var onSpeechAiSessionEnded: ((scene: WKSpeechSession.Scene, reason: String) -> Unit)? = null

    fun ensureReady(context: Context) {
        if (abMateSdk != null) return
        val sdk = TbWearKitBootstrap.requireAbMateSdk(context)
        wearKit = TbWearKitBootstrap.requireWearKit(context)
        abMateSdk = sdk
        abMateManager = sdk.abMateManager
        attachConnectorObserver()
        attachRepositoryObservers()
        ensureSpeechAiBridge()
    }

    private fun ensureSpeechAiBridge() {
        if (wearKit == null) return
        if (speechAiBridge == null) {
            speechAiBridge = TbSpeechAiBridge(
                wearKitProvider = { wearKit },
                callbacks = object : TbSpeechAiBridge.Callbacks {
                    override fun onSessionStarted(
                        scene: WKSpeechSession.Scene,
                        origin: WKSpeechSession.Origin,
                    ) {
                        FissionLogUtils.d(TAG, "speechAi session started scene=$scene origin=$origin")
                        onSpeechAiSessionStarted?.invoke(scene)
                    }

                    override fun onAudioData(bytes: ByteArray) {
                        onSpeechAiAudioData?.invoke(bytes)
                    }

                    override fun onSessionEnded(
                        scene: WKSpeechSession.Scene,
                        reason: String,
                    ) {
                        FissionLogUtils.d(TAG, "speechAi session ended scene=$scene reason=$reason")
                        onSpeechAiSessionEnded?.invoke(scene, reason)
                    }
                },
            )
        }
        speechAiBridge?.start()
    }

    fun isSpeechAiSessionActive(): Boolean = speechAiBridge?.hasActiveSession() == true

    fun isSpeechAiSupported(): Boolean = speechAiBridge?.isSupported == true

    fun connect(params: BleComConfig) {
        val context = params.context ?: sdkConfig.context
        ensureReady(context)
        val mac = params.mac?.trim().orEmpty()
        if (mac.isEmpty()) {
            emit(ConnectionStateEvent.Failed(IllegalArgumentException("TB connect: empty mac")))
            return
        }
        deviceAddress = mac
        isOtaMode = params.isOtaMode
        val authCode = params.deviceName?.takeIf { it.isNotBlank() }
        emit(ConnectionStateEvent.Connecting)
        wearKit!!.connector.connect(
            type = WKDeviceType.AB_MATE,
            address = mac,
            authMode = WKAuthMode.AUTO,
            authCode = authCode,
            userId = "1234",
            sex = true,
            age = 20,
            height = 170f,
            weight = 180f,
        )
    }

    fun disconnect(unpair: Boolean) {
        if (unpair) {
            val address = deviceAddress
            val kit = wearKit
            if (kit != null) {
                disposables.add(
                    kit.connector.clear(true).onErrorComplete().subscribe(
                        { finishUnpair(address) },
                        { error ->
                            FissionLogUtils.e(TAG, "connector.clear error: ${error.message}")
                            finishUnpair(address)
                        },
                    ),
                )
            } else {
                finishUnpair(address)
            }
            return
        }
        wearKit?.connector?.close()
    }

    /** WearKit 解绑完成后，再断开 A2DP/HFP 并解除系统 BT 配对。 */
    private fun finishUnpair(address: String?) {
        FissionLogUtils.d(TAG, "connector.clear done, unpair BT")
        BluetoothUnpairHelper.unpairAsync(
            context = sdkConfig.context,
            deviceAddress = address,
            onComplete = { GlassesSpUtil.remove(GlassesSpUtil.KEY_MAC_ADDRESS) },
        )
    }

    fun release() {
        cancelSettingsPublishTimeout()
        stopPullMedia()
        stopWifiOta()
        speechAiBridge?.release()
        speechAiBridge = null
        actionSyncHelper.reset()
        detachRepositoryObservers()
        connectorDisposable?.dispose()
        connectorDisposable = null
        disposables.clear()
        otaManager.release()
        abMateManager = null
        abMateSdk = null
        wearKit = null
    }

    fun getBatteryLevel() {
        val manager = abMateManager ?: return
        // Demo：电量走 LiveData；requirePower 仅触发查询
        manager.requirePower({}, {})
    }

    fun requestDeviceVersionInfo() {
        pendingVersionRequest = true
        publishVersionIfReady()
        // 触发协处理器版本查询（结果落在 glassVersion LiveData）
        abMateManager?.getCoprocessorVersion({}, {})
    }

    fun getDeviceStorage() {
        pendingCapacityRequest = true
        abMateManager?.getStorageSpaceInfo({}, {})
    }

    fun getMediaFileCount() {
        abMateManager?.getMediaFileCount(
            onSuccess = { count -> emit(CmdResultEvent.MediaFileCount(count)) },
            onFail = { FissionLogUtils.w(TAG, "getMediaFileCount failed") },
        )
    }

    fun syncAllMediaFile() {
        val sdk = abMateSdk ?: return
        val saveDir = File(sdkConfig.context.filesDir, sdkConfig.mediaFilesStorageDirName).apply {
            mkdirs()
        }
        stopPullMedia()
        emit(FileSyncEvent.ConnectSuccess)
        pullDisposable = sdk.fileAbility
            .pullFiles(saveDir)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { event -> handleFileTransferEvent(event) },
                { error ->
                    emit(
                        FileSyncEvent.Failed(
                            error.message ?: error.javaClass.simpleName,
                        ),
                    )
                    stopPullMedia()
                },
            )
    }

    fun getActionState() {
        val manager = abMateManager ?: return
        val repo = manager.getRepository()
        repo.glassWorkState.value?.let { notifyGlassWorkState(it) }
        repo.glassCamera.value?.let { actionSyncHelper.applyGlassTakePhoto(it) }
        repo.deviceInEarStatus.value?.let { actionSyncHelper.applyWearDetection(it) }
        manager.getGlassWorkState(
            onSuccess = { notifyGlassWorkState(it) },
            onFail = { FissionLogUtils.w(TAG, "getGlassWorkState failed") },
        )
    }

    private fun notifyGlassWorkState(value: Int) {
        actionSyncHelper.applyGlassWorkState(value)
        onGlassWorkStateChanged?.invoke(value)
    }

    fun takePicture(awaitImageReturn: Boolean) {
        if (awaitImageReturn) {
            awaitingAiPicTransfer = true
            aiPicChunks.clear()
        }
        abMateManager?.turnOnCamera(
            (if (awaitImageReturn) GlassCameraTurnOnRequest.MODE_AI else GlassCameraTurnOnRequest.MODE_RECORDING).toInt(),
            onSuccess = { code ->
                if (code == 0) {
                    if (!awaitImageReturn) {
                        emit(CmdResultEvent.Success())
                    }
                } else {
                    if (awaitImageReturn) awaitingAiPicTransfer = false
                    emit(CmdResultEvent.Fail("takePicture result=$code", code))
                }
            },
            onFail = {
                if (awaitImageReturn) awaitingAiPicTransfer = false
                emit(CmdResultEvent.Fail("takePicture failed"))
            },
        )
    }

    /** 通知设备端开启 AI 对话（mode=2 走 Opus 上行）。 */
    fun startAiAssistant() {
        ackDeviceAiDialogueOpus()
    }

    /** 应答设备进入 AI 对话，mode=2 启用 Opus 上行（眼镜侧发起时也需回 ACK）。 */
    fun ackDeviceAiDialogueOpus() {
        abMateManager?.sendAIChatState(2)
    }

    fun stopAiAssistant() {
        stopVadAudio()
    }

    fun interruptAiAssistant() {
        stopVadAudio()
    }

    fun stopVadAudio() {
        speechAiBridge?.stopActiveSession("stopVadAudio")
        abMateManager?.sendAIChatState(0)
    }

    fun startVideoRecording() {
        abMateManager?.startVideoRecording(
            onSuccess = { code ->
                if (code == 0) emit(CmdResultEvent.Success())
                else emit(CmdResultEvent.Fail("startVideoRecording result=$code", code))
            },
            onFail = { emit(CmdResultEvent.Fail("startVideoRecording failed")) },
        )
    }

    fun stopVideoRecording() {
        abMateManager?.turnOffCamera(
            onSuccess = { code ->
                if (code == 0) emit(CmdResultEvent.Success())
                else emit(CmdResultEvent.Fail("stopVideoRecording result=$code", code))
            },
            onFail = { emit(CmdResultEvent.Fail("stopVideoRecording failed")) },
        )
    }

    fun startDeviceRecording() {
        abMateManager?.startAudioRecording(
            onSuccess = { code ->
                if (code == 0) emit(CmdResultEvent.Success())
                else emit(CmdResultEvent.Fail("startDeviceRecording result=$code", code))
            },
            onFail = { emit(CmdResultEvent.Fail("startDeviceRecording failed")) },
        )
    }

    fun stopDeviceRecording() {
        abMateManager?.turnOffCamera(
            onSuccess = { code ->
                if (code == 0) emit(CmdResultEvent.Success())
                else emit(CmdResultEvent.Fail("stopDeviceRecording result=$code", code))
            },
            onFail = { emit(CmdResultEvent.Fail("stopDeviceRecording failed")) },
        )
    }

    fun setVideoDuration(seconds: Int) {
        val manager = abMateManager ?: return
        if (!isRecordingLimitSupported()) {
            FissionLogUtils.w(TAG, "setVideoDuration ignored: isSupportAudio != 1")
            emit(CmdResultEvent.Fail("Device does not support video duration config"))
            return
        }
        val minutes = secondsToMinutes(seconds)
        manager.setLimitTime(
            type = 0,
            duration = minutes,
            onSuccess = { emit(CmdResultEvent.Success()) },
            onFail = { emit(CmdResultEvent.Fail("setVideoDuration failed")) },
        )
    }

    fun setVoiceDuration(seconds: Int) {
        val manager = abMateManager ?: return
        if (!isRecordingLimitSupported()) {
            FissionLogUtils.w(TAG, "setVoiceDuration ignored: isSupportAudio != 1")
            emit(CmdResultEvent.Fail("Device does not support audio duration config"))
            return
        }
        val minutes = secondsToMinutes(seconds)
        manager.setLimitTime(
            type = 1,
            duration = minutes,
            onSuccess = { emit(CmdResultEvent.Success()) },
            onFail = { emit(CmdResultEvent.Fail("setVoiceDuration failed")) },
        )
    }

    fun setOfflineVoiceLanguage(language: GlassesConstant.OffLineLanguages) {
        val languageCode = when(language){
            GlassesConstant.OffLineLanguages.Chinese -> 1
            GlassesConstant.OffLineLanguages.English -> 0
        }
        abMateManager?.setAbMateLanguage(languageCode) { ok ->
            if (ok) emit(CmdResultEvent.Success())
            else emit(CmdResultEvent.Fail("setOfflineVoiceLanguage failed"))
        }
    }

    fun restoreFactorySettings() {
        abMateManager?.earPhoneReset { ok ->
            if (ok) {
                emit(CmdResultEvent.Success())
                emit(ConnectionStateEvent.Disconnected)
            }
            else emit(CmdResultEvent.Fail("restoreFactorySettings failed"))
        }
    }

    fun deviceShutDown() {
        abMateManager?.deviceShutDown()
    }

    fun rebootDevice() {
        val ability = abMateSdk?.deviceAbility ?: return
        disposables.add(
            ability.reboot().onErrorComplete().subscribe(
                { FissionLogUtils.d(TAG, "reboot requested") },
                { FissionLogUtils.e(TAG, "reboot error: ${it.message}") },
            ),
        )
    }

    fun setTime() {
        abMateManager?.setGlassTime(
            onSuccess = { emit(CmdResultEvent.Success()) },
            onFail = { emit(CmdResultEvent.Fail("setTime failed")) },
        )
    }

    fun setLedBrightness(level: GlassesConstant.LedBrightnessLevel) {
        abMateManager?.setGlassBrightness(
            level.data.toInt() and 0xFF,
            onSuccess = { emit(CmdResultEvent.Success()) },
            onFail = { emit(CmdResultEvent.Fail("setLedBrightness failed")) },
        )
    }

    fun getDeviceSettingsState() {
        pendingSettingsRequest = true
        val manager = abMateManager ?: return
        FissionLogUtils.d(
            TAG,
            "TB getDeviceSettingsState: burstPhotoCount read unsupported; wearDetection state read unsupported",
        )
        scheduleSettingsPublishTimeout()
        manager.getRepository().deviceCommManager.sendRequest(DeviceInfoRequest.defaultInfoRequest(0))
        publishDeviceSettingsIfRequested()
    }

    fun getVoiceWakeUp() {
        pendingVoiceWakeUpRequest = true
        val enabled = abMateManager?.getRepository()?.deviceVoiceRecognitionStatus?.value
        if (enabled != null) {
            emitVoiceWakeUpState(enabled)
            pendingVoiceWakeUpRequest = false
        } else {
            abMateManager?.getRepository()?.deviceCommManager?.sendRequest(
                DeviceInfoRequest.defaultInfoRequest(0),
            )
        }
    }

    fun setWearDetection(state: GlassesConstant.WearDetectionState) {
        abMateManager?.setDetection(
            state == GlassesConstant.WearDetectionState.ON,
            onSuccess = { emit(CmdResultEvent.Success()) },
            onFail = { emit(CmdResultEvent.Fail("setWearDetection failed")) },
        )
    }

    fun setScreenOrientation(orientation: GlassesConstant.ScreenOrientation) {
        val mode = when (orientation) {
            GlassesConstant.ScreenOrientation.PORTRAIT -> 0
            GlassesConstant.ScreenOrientation.LANDSCAPE -> 1
        }
        abMateManager?.switchScreen(mode) { ok ->
            FissionLogUtils.d("setScreenOrientation: $ok")
            if (ok) emit(CmdResultEvent.Success())
            else emit(CmdResultEvent.Fail("setScreenOrientation failed"))
        }
    }

    fun upVolume() {
        abMateManager?.setVolumeType(0)
    }

    fun downVolume() {
        abMateManager?.setVolumeType(1)
    }

    fun getGlassesVolume() {
        pendingVolumeRequest = true
        val current = abMateManager?.getRepository()?.currentVolume?.value
        if (current != null) {
            emitVolume(current)
            pendingVolumeRequest = false
        } else {
            abMateManager?.requireCallState()
        }
    }

    fun setGlassesVolume(type: GlassesConstant.AudioVolumeType, volume: Int) {
        abMateManager?.setGlassVolume(
            mode = type.data.toInt() and 0xFF,
            volume = volume,
            onSuccess = { emit(CmdResultEvent.Success()) },
            onFail = { emit(CmdResultEvent.Fail("setGlassesVolume failed")) },
        )
    }

    fun controlMusic(enable: Boolean) {
        // 0 play / 1 pause
        abMateManager?.controlMusic(if (enable) 0 else 1)
    }

    fun switchMusic(action: GlassesConstant.MusicSwitchAction) {
        // 2 previous / 3 next
        abMateManager?.controlMusic(
            when (action) {
                GlassesConstant.MusicSwitchAction.PREVIOUS -> 2
                GlassesConstant.MusicSwitchAction.NEXT -> 3
            },
        )
    }

    fun setVoiceWakeUp(localOfflineEnabled: Boolean) {
        // mode: 官方 Demo / 源码以 speech recognition mode 表达
        abMateManager?.setSpeechRecognitionMode(if (localOfflineEnabled) 1 else 0, isFromUser = true)
    }

    /** 蓝汛芯片 BLE OTA（ABMateOTAManager）。 */
    fun startBleOta(filePath: String, version: String) {
        val manager = abMateManager ?: return
        if (!File(filePath).exists()) {
            emit(OTAEvent.Failed("OTA file not found: $filePath"))
            return
        }
        stopWifiOta()
        emit(OTAEvent.Start)
        otaManager.setProgressEvent { percent ->
            if (percent >= 100) {
                emit(OTAEvent.Progress(100, GlassesConstant.OTAStage.OTA))
                emit(OTAEvent.Success)
            } else {
                emit(OTAEvent.Progress(percent.coerceIn(0, 99), GlassesConstant.OTAStage.OTA))
            }
        }
        otaManager.setOtaErrorEvent { code ->
            emit(OTAEvent.Failed("TB BLE OTA error=$code", code))
        }
        otaManager.init(manager)
        otaManager.startOta(filePath, version.ifBlank { "0" })
    }

    /** 全志芯片 WiFi OTA（WKOtaAbility）。 */
    fun startWifiOta(filePath: String) {
        val sdk = abMateSdk ?: return
        val file = File(filePath)
        if (!file.exists()) {
            emit(OTAEvent.Failed("WiFi OTA file not found: $filePath"))
            return
        }
        stopWifiOta()
        emit(OTAEvent.Start)
        var successEmitted = false
        wifiOtaDisposable = sdk.otaAbility
            .ota(file)
            .observeOn(AndroidSchedulers.mainThread())
            .doFinally { stopWifiOta() }
            .subscribe(
                { percent ->
                    if (percent >= 100 && !successEmitted) {
                        successEmitted = true
                        emit(OTAEvent.Progress(100, GlassesConstant.OTAStage.OTA))
                        emit(OTAEvent.Success)
                    } else if (percent < 100) {
                        emit(OTAEvent.Progress(percent.coerceIn(0, 99), GlassesConstant.OTAStage.OTA))
                    }
                },
                { error ->
                    if (successEmitted) return@subscribe
                    val message = when (error) {
                        is WKFileTransferException ->
                            error.message ?: "WiFi OTA transfer failed"
                        else -> error.message ?: error.javaClass.simpleName
                    }
                    emit(OTAEvent.Failed(message))
                },
                {
                    if (!successEmitted) {
                        emit(OTAEvent.Success)
                    }
                },
            )
    }

    fun startLiveStreaming() {
        abMateManager?.startCameraStreaming(
            onSuccess = { rtsp -> emit(LiveEvent.RespSuccess(rtsp)) },
            onFail = { emit(LiveEvent.Failed("startCameraStreaming failed")) },
        )
    }

    fun stopLiveStreaming() {
        abMateManager?.turnOffCamera(
            onSuccess = { emit(LiveEvent.RespStop) },
            onFail = { emit(LiveEvent.Failed("stopLiveStreaming failed")) },
        )
    }

    fun reconnectBluetooth() {
        wearKit?.connector?.reconnect()
    }

    private fun attachConnectorObserver() {
        connectorDisposable?.dispose()
        val sdk = abMateSdk ?: return
        connectorDisposable = sdk.connector.observeConnectorState()
            .startWithItem(sdk.connector.getConnectorState())
            .distinctUntilChanged()
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { state -> onConnectorState(state) },
                { error ->
                    FissionLogUtils.e(TAG, "connector observe error: ${error.message}")
                    emit(ConnectionStateEvent.Failed(error))
                },
            )
    }

    private fun onConnectorState(state: WKConnectorState) {
        FissionLogUtils.d(TAG, "connector state=$state")
        when (state) {
            WKConnectorState.PRE_CONNECTING,
            WKConnectorState.CONNECTING,
            WKConnectorState.PRE_CONNECTED,
            -> emit(ConnectionStateEvent.Connecting)

            WKConnectorState.CONNECTED -> {
                val device = resolveBluetoothDevice(deviceAddress)
                emit(ConnectionStateEvent.Connected(device, isOtaMode))
                emit(ConnectionStateEvent.DeviceReady)
            }

            WKConnectorState.DISCONNECTED -> {
                actionSyncHelper.reset()
                emit(ConnectionStateEvent.Disconnected)
            }
        }
    }

    private fun attachRepositoryObservers() {
        if (repositoryObserversAttached) return
        val repo = abMateManager?.getRepository() ?: return
        repositoryObserversAttached = true

        powerObserver = Observer { power ->
            if (power == null) return@Observer
            val component = power.leftSidePower ?: power.rightSidePower ?: power.casePower
            emit(
                CmdResultEvent.DevicePower(
                    value = component?.powerLevel,
                    isCharging = component?.isCharging,
                ),
            )
        }
        volumeObserver = Observer { volume ->
            if (volume == null) return@Observer
            if (pendingVolumeRequest) {
                emitVolume(volume)
                pendingVolumeRequest = false
            }
        }
        storageObserver = Observer { info ->
            if (info == null) return@Observer
            if (pendingCapacityRequest) {
                emitCapacity(info)
                pendingCapacityRequest = false
            }
        }
        mediaCountObserver = Observer { info ->
            if (info == null) return@Observer
            emit(
                CmdResultEvent.MediaFileCount(
                    info.imageNum + info.videoNum + info.audioNum,
                ),
            )
        }
        glassVersionObserver = Observer { version ->
            lastGlassVersion = version
            if (pendingVersionRequest) publishVersionIfReady()
        }
        firmwareVersionObserver = Observer { version ->
            lastFirmwareVersion = version?.toString()
            if (pendingVersionRequest) publishVersionIfReady()
        }
        aiPicObserver = Observer { pkg ->
            if (pkg == null || !awaitingAiPicTransfer) return@Observer
            when (pkg.status) {
                1 -> appendAiPicChunk(pkg.picFlow)
                0 -> finishAiPicTransfer()
                0xFE -> {
                    awaitingAiPicTransfer = false
                    aiPicChunks.clear()
                    emit(CmdResultEvent.Fail("AI photo: device storage full"))
                }
                0xFF -> {
                    awaitingAiPicTransfer = false
                    aiPicChunks.clear()
                    emit(CmdResultEvent.Fail("AI photo: connection error"))
                }
            }
        }
        aiRecordDataObserver = Observer { data ->
            if (data == null) return@Observer
//            FissionLogUtils.d("aiRecordData : ${data.size}")
            onAiRecordData?.invoke(data)
        }
        stateAIChatObserver = Observer { state ->
            if (state == null) return@Observer
            FissionLogUtils.d("stateAIChat : $state")
            onAiChatStateChanged?.invoke(state)
        }
        videoLimitObserver = Observer {
            publishDeviceSettingsIfRequested()
        }
        audioLimitObserver = Observer {
            publishDeviceSettingsIfRequested()
        }
        supportAudioObserver = Observer {
            publishDeviceSettingsIfRequested()
            if (!pendingSettingsRequest && it != null) {
                buildDeviceSettingsSnapshot()?.let { snapshot ->
                    emit(CmdResultEvent.DeviceSettingsStateEvent(snapshot))
                }
            }
        }
        screenConfigObserver = Observer { value ->
            handleScreenConfigUpdated(value)
        }
        voiceRecognitionObserver = Observer { enabled ->
            if (enabled != null && pendingVoiceWakeUpRequest) {
                emitVoiceWakeUpState(enabled)
                pendingVoiceWakeUpRequest = false
            }
            publishDeviceSettingsIfRequested()
        }
        glassWorkStateObserver = Observer { value ->
            if (value == null) return@Observer
            notifyGlassWorkState(value)
        }
        glassTakePhotoObserver = Observer { value ->
            actionSyncHelper.applyGlassTakePhoto(value)
        }
        deviceInEarObserver = Observer { value ->
            actionSyncHelper.applyWearDetection(value)
        }

        mainHandler.post {
            repo.devicePower.observeForever(powerObserver!!)
            repo.currentVolume.observeForever(volumeObserver!!)
            repo.glassStorageInfo.observeForever(storageObserver!!)
            repo.glassMediaCount.observeForever(mediaCountObserver!!)
            repo.glassVersion.observeForever(glassVersionObserver!!)
            repo.deviceFirmwareVersion.observeForever(firmwareVersionObserver!!)
            repo.aiPicPackage.observeForever(aiPicObserver!!)
            repo.aIRecordData.observeForever(aiRecordDataObserver!!)
            repo.stateAIChat.observeForever(stateAIChatObserver!!)
            repo.videoLimitTime.observeForever(videoLimitObserver!!)
            repo.audioLimitTime.observeForever(audioLimitObserver!!)
            repo.isSupportAudio.observeForever(supportAudioObserver!!)
            repo.screenConfig.observeForever(screenConfigObserver!!)
            repo.deviceVoiceRecognitionStatus.observeForever(voiceRecognitionObserver!!)
            repo.glassWorkState.observeForever(glassWorkStateObserver!!)
            repo.glassCamera.observeForever(glassTakePhotoObserver!!)
            repo.deviceInEarStatus.observeForever(deviceInEarObserver!!)
            repo.glassWorkState.value?.let { notifyGlassWorkState(it) }
        }
    }

    private fun handleScreenConfigUpdated(value: ByteArray?) {
        val orientation = TbScreenOrientationParser.parse(value) ?: return
        if (pendingSettingsRequest) {
            publishDeviceSettingsIfRequested()
            return
        }
        emit(CmdResultEvent.DeviceSettingsStateEvent(DeviceSettingsStateDTO(orientation = orientation)))
    }

    private fun publishDeviceSettingsIfRequested() {
        if (!pendingSettingsRequest) return
        val snapshot = buildDeviceSettingsSnapshot() ?: return
        if (snapshot.orientation == null) return
        cancelSettingsPublishTimeout()
        pendingSettingsRequest = false
        emit(CmdResultEvent.DeviceSettingsStateEvent(snapshot))
    }

    private fun scheduleSettingsPublishTimeout() {
        cancelSettingsPublishTimeout()
        settingsPublishTimeoutRunnable = Runnable {
            if (!pendingSettingsRequest) return@Runnable
            val snapshot = buildDeviceSettingsSnapshot() ?: return@Runnable
            cancelSettingsPublishTimeout()
            pendingSettingsRequest = false
            emit(CmdResultEvent.DeviceSettingsStateEvent(snapshot))
        }
        mainHandler.postDelayed(settingsPublishTimeoutRunnable!!, SETTINGS_PUBLISH_TIMEOUT_MS)
    }

    private fun cancelSettingsPublishTimeout() {
        settingsPublishTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        settingsPublishTimeoutRunnable = null
    }

    private fun buildDeviceSettingsSnapshot(): DeviceSettingsStateDTO? {
        val repo = abMateManager?.getRepository() ?: return null
        val volume = repo.currentVolume.value
        val recordDurationMinutes = repo.videoLimitTime.value
        val audioDurationMinutes = repo.audioLimitTime.value
        val orientation = TbScreenOrientationParser.parse(repo.screenConfig.value)
        val voiceEnabled = repo.deviceVoiceRecognitionStatus.value
        val recordingLimitSupported = repo.isSupportAudio.value?.let { it == 1 }
        if (
            recordDurationMinutes == null &&
            audioDurationMinutes == null &&
            orientation == null &&
            voiceEnabled == null &&
            volume == null &&
            recordingLimitSupported == null
        ) {
            return null
        }
        return DeviceSettingsStateDTO(
            recordDuration = recordDurationMinutes
                ?.let(::minutesToSeconds)
                .takeIf { recordingLimitSupported == true },
            audioRecordDuration = audioDurationMinutes
                ?.let(::minutesToSeconds)
                .takeIf { recordingLimitSupported == true },
            systemVolume = volume?.systemVolume,
            mediaVolume = volume?.mediaVolume,
            callVolume = volume?.callVolume,
            voiceCommandEnabled = voiceEnabled,
            orientation = orientation,
            recordingLimitSupported = recordingLimitSupported,
        )
    }

    private fun isRecordingLimitSupported(): Boolean {
        return abMateManager?.getRepository()?.isSupportAudio?.value == 1
    }

    private fun minutesToSeconds(minutes: Int): Int = minutes * SECONDS_PER_MINUTE

    private fun secondsToMinutes(seconds: Int): Int {
        if (seconds <= 0) return 0
        return maxOf(1, (seconds + SECONDS_PER_MINUTE - 1) / SECONDS_PER_MINUTE)
    }

    private fun emitVoiceWakeUpState(recognitionEnabled: Boolean) {
        emit(
            CmdResultEvent.VoiceCommandDisableState(
                localOfflineVoiceDisabled = !recognitionEnabled,
                // TB 仅暴露离线语音识别开关，Opus 推送状态设备侧无独立读回接口。
                opusStreamPushDisabled = false,
            ),
        )
    }

    private fun appendAiPicChunk(chunk: ByteArray?) {
        if (chunk == null || chunk.isEmpty()) return
        aiPicChunks.add(chunk)
    }

    private fun finishAiPicTransfer() {
        awaitingAiPicTransfer = false
        if (aiPicChunks.isEmpty()) {
            emit(CmdResultEvent.Fail("AI photo: empty image"))
            return
        }
        val totalSize = aiPicChunks.sumOf { it.size }
        val imageBytes = ByteArray(totalSize)
        var offset = 0
        for (chunk in aiPicChunks) {
            chunk.copyInto(imageBytes, offset)
            offset += chunk.size
        }
        aiPicChunks.clear()
        onAiImageBytesReady?.invoke(imageBytes)
    }

    private fun detachRepositoryObservers() {
        val repo = abMateManager?.getRepository() ?: run {
            repositoryObserversAttached = false
            return
        }
        mainHandler.post {
            powerObserver?.let { repo.devicePower.removeObserver(it) }
            volumeObserver?.let { repo.currentVolume.removeObserver(it) }
            storageObserver?.let { repo.glassStorageInfo.removeObserver(it) }
            mediaCountObserver?.let { repo.glassMediaCount.removeObserver(it) }
            glassVersionObserver?.let { repo.glassVersion.removeObserver(it) }
            firmwareVersionObserver?.let { repo.deviceFirmwareVersion.removeObserver(it) }
            aiPicObserver?.let { repo.aiPicPackage.removeObserver(it) }
            aiRecordDataObserver?.let { repo.aIRecordData.removeObserver(it) }
            stateAIChatObserver?.let { repo.stateAIChat.removeObserver(it) }
            videoLimitObserver?.let { repo.videoLimitTime.removeObserver(it) }
            audioLimitObserver?.let { repo.audioLimitTime.removeObserver(it) }
            supportAudioObserver?.let { repo.isSupportAudio.removeObserver(it) }
            screenConfigObserver?.let { repo.screenConfig.removeObserver(it) }
            voiceRecognitionObserver?.let { repo.deviceVoiceRecognitionStatus.removeObserver(it) }
            glassWorkStateObserver?.let { repo.glassWorkState.removeObserver(it) }
            glassTakePhotoObserver?.let { repo.glassCamera.removeObserver(it) }
            deviceInEarObserver?.let { repo.deviceInEarStatus.removeObserver(it) }
            powerObserver = null
            volumeObserver = null
            storageObserver = null
            mediaCountObserver = null
            glassVersionObserver = null
            firmwareVersionObserver = null
            aiPicObserver = null
            aiRecordDataObserver = null
            stateAIChatObserver = null
            videoLimitObserver = null
            audioLimitObserver = null
            supportAudioObserver = null
            screenConfigObserver = null
            voiceRecognitionObserver = null
            glassWorkStateObserver = null
            glassTakePhotoObserver = null
            deviceInEarObserver = null
            pendingSettingsRequest = false
            pendingVoiceWakeUpRequest = false
            awaitingAiPicTransfer = false
            aiPicChunks.clear()
            onAiImageBytesReady = null
            onAiChatStateChanged = null
            onAiRecordData = null
            onGlassWorkStateChanged = null
            repositoryObserversAttached = false
        }
    }

    private fun publishVersionIfReady() {
        if (!pendingVersionRequest) return
        val firmware = lastFirmwareVersion.orEmpty()
        val glass = lastGlassVersion.orEmpty()
        if (firmware.isEmpty() && glass.isEmpty()) return
        pendingVersionRequest = false
        emit(
            CmdResultEvent.DeviceVersionInfoEvent(
                DeviceVersionInfoDTO(
                    firmwareVersion = firmware.ifEmpty { glass },
                    wifiVersion = glass,
                    hardwareVersion = "",
                ),
            ),
        )
    }

    private fun emitCapacity(info: SpaceInfoMode) {
        val usedKb = info.usedSpaceMb.toLong() * 1024L
        val freeKb = info.freeSpaceMb.toLong() * 1024L
        emit(
            CmdResultEvent.DeviceCapacityInfoEvent(
                DeviceCapacityInfoDTO(
                    deviceRole = 0,
                    usedSizeKb = usedKb,
                    totalSizeKb = usedKb + freeKb,
                ),
            ),
        )
    }

    private fun emitVolume(volume: GlassVolume) {
        emit(
            CmdResultEvent.DeviceVolumeState(
                systemVolume = volume.systemVolume,
                mediaVolume = volume.mediaVolume,
                callVolume = volume.callVolume,
            ),
        )
    }

    private fun handleFileTransferEvent(event: WKFileTransferEvent) {
        when (event) {
            is WKFileTransferEvent.OnFileProgress -> {
                emit(
                    FileSyncEvent.DownloadProgress(
                        progress = event.progress,
                        curFileIndex = event.index,
                        totalFileCount = event.count,
                        speed = FileTransferSpeedFormatter.format(event.speed),
                    ),
                )
            }

            is WKFileTransferEvent.OnFileCompleted -> {
                val path = event.savePath
                val size = File(path).takeIf { it.exists() }?.length() ?: 0L
                emit(
                    FileSyncEvent.DownloadSuccess(
                        filePath = path,
                        curFileIndex = event.index,
                        totalFileCount = event.count,
                        remoteUrl = "",
                        fileSizeInBytes = size,
                        fileModifiedTime = "",
                        fpath = event.devicePath,
                    ),
                )
            }

            is WKFileTransferEvent.OnAllCompleted -> {
                emit(
                    FileSyncEvent.BatchDownloadFinished(
                        successCount = event.savePaths.size,
                        totalFileCount = event.savePaths.size,
                    ),
                )
                stopPullMedia()
            }
        }
    }

    private fun stopPullMedia() {
        pullDisposable?.dispose()
        pullDisposable = null
    }

    private fun stopWifiOta() {
        wifiOtaDisposable?.dispose()
        wifiOtaDisposable = null
    }

    private fun resolveBluetoothDevice(address: String?): BluetoothDevice? {
        if (address.isNullOrBlank()) return null
        return try {
            BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(address)
        } catch (_: Exception) {
            null
        }
    }

    private fun emit(event: GlassesEvent) {
        scope.launch { eventBus.emit(event) }
    }

    private companion object {
        const val SETTINGS_PUBLISH_TIMEOUT_MS = 1_000L
        const val SECONDS_PER_MINUTE = 60
    }
}
