package com.fission.wear.glasses.sdk.tb

import com.fission.wear.glasses.sdk.AiAssistantClient
import com.fission.wear.glasses.sdk.GlassesManage
import com.fission.wear.glasses.sdk.config.BleComConfig
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_IMAGE_SAVE
import com.fission.wear.glasses.sdk.data.model.BaseWsMessage
import com.fission.wear.glasses.sdk.data.model.LiveStreamingConfig
import com.fission.wear.glasses.sdk.data.model.McpData
import com.fission.wear.glasses.sdk.events.AgentEvent
import com.fission.wear.glasses.sdk.events.AiAssistantEvent
import com.fission.wear.glasses.sdk.events.AudioStateEvent
import com.fission.wear.glasses.sdk.events.CmdResultEvent
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent
import com.fission.wear.glasses.sdk.events.FileSyncEvent
import com.fission.wear.glasses.sdk.events.GlassesCmdStrategy
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.events.LiveEvent
import com.fission.wear.glasses.sdk.events.OTAEvent
import com.fission.wear.glasses.sdk.state.SdkBleConnectionState
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.topstep.wearkit.apis.model.speech.WKSpeechSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * TB（拓步 / Topstep AbMate）渠道策略：将 [GlassesCmdStrategy] 映射到 WearKit / ABMateManager。
 */
class TbGlassesCmdStrategy(
    private val sdkConfig: SdkConfig,
    private val eventBus: MutableSharedFlow<GlassesEvent>,
    private val scope: CoroutineScope,
) : GlassesCmdStrategy {

    private val TAG = "TbGlassesCmdStrategy"
    private val manager = TbSdkManager(sdkConfig, scope, eventBus)

    private var isAiRecording = false
    private var speechAiSessionActive = false
    private var lastGlassWorkState: Int? = null
    private var aiAssistantBridgeJob: Job? = null
    private var wifiExclusiveSessionObserverJob: Job? = null
    private val rawAiAudioDumper = TbRawAiAudioDumper(sdkConfig.context)

    private fun aiAssistantListenMode(): String =
        GlassesConstant.AI_ASSISTANT_TYPE_LISTEN_MODE_AUTO

    init {
        manager.onAiImageBytesReady = { bytes -> handleImageComplete(bytes) }
        manager.onAiRecordData = { bytes ->
            when {
                bytes.isEmpty() -> Unit
                manager.isSpeechAiSessionActive() ->
                    FissionLogUtils.d(TAG, "skip aIRecordData: speechAi session active")
                else -> handleDeviceAiAudio(bytes, source = "aIRecordData")
            }
        }
        manager.onSpeechAiSessionStarted = { scene -> handleSpeechAiSessionStarted(scene) }
        manager.onSpeechAiAudioData = { bytes ->
            if (bytes.isNotEmpty()) {
                handleDeviceAiAudio(bytes, source = "speechAi")
            }
        }
        manager.onSpeechAiSessionEnded = { scene, reason -> handleSpeechAiSessionEnded(scene, reason) }
        manager.onAiChatStateChanged = { state -> handleAiChatState(state) }
        manager.onGlassWorkStateChanged = { state -> handleGlassWorkStateForAi(state) }

        aiAssistantBridgeJob = scope.launch {
            AiAssistantClient.getInstance().aiAgentEventFlow().collect { event ->
                when (event) {
                    is AiAssistantEvent.AiImageRecognition -> {
                        FissionLogUtils.d(TAG, "AI识图触发拍照")
                        AiAssistantClient.getInstance().startAiImageRecognition(event.data)
                        takePicture(true)
                    }

                    AiAssistantEvent.AgentAudioPlaybackFinished -> {
                        if (AiAssistantClient.getInstance().isAwaitingMcpImageRecognitionFollowUp()) {
                            FissionLogUtils.i(TAG, "MCP 识图跟进中，暂不关闭 AI 录音")
                            return@collect
                        }
                        stopVadAudio()
                    }

                    is AgentEvent.AiAssistantConnectState -> {
                        if (event.state == GlassesConstant.WS_CONNECTION_STATE_DISCONNECTED &&
                            GlassesManage.currentConnectionState().bleState == SdkBleConnectionState.CONNECTED &&
                            isAiRecording
                        ) {
                            if (AiAssistantClient.getInstance().isListenBlockedByWsReconnect()) {
                                FissionLogUtils.d(TAG, "WS 重建中，忽略 DISCONNECTED 停麦")
                                return@collect
                            }
                            isAiRecording = false
                            stopVadAudio()
                        }
                    }

                    else -> Unit
                }
            }
        }

        wifiExclusiveSessionObserverJob = scope.launch {
            eventBus.collect { event ->
                when (event) {
                    is FileSyncEvent.Failed,
                    is FileSyncEvent.BatchDownloadFinished,
                    is OTAEvent.Failed,
                    is OTAEvent.Cancelled,
                    is OTAEvent.Success,
                    is LiveEvent.Failed,
                    is LiveEvent.RespStop,
                    LiveEvent.StoppedByNotification -> endAssistantAfterWifiExclusiveSession()

                    is ConnectionStateEvent.Disconnected ->
                        AiAssistantClient.getInstance().cancelWifiExclusiveSession()

                    else -> Unit
                }
            }
        }
    }

    override fun release() {
        aiAssistantBridgeJob?.cancel()
        aiAssistantBridgeJob = null
        wifiExclusiveSessionObserverJob?.cancel()
        wifiExclusiveSessionObserverJob = null
        isAiRecording = false
        speechAiSessionActive = false
        lastGlassWorkState = null
        rawAiAudioDumper.endSession("release")
        manager.release()
    }

    override fun connect(params: Any) {
        if (params is BleComConfig) {
            manager.connect(params)
        } else {
            FissionLogUtils.w(TAG, "connect skipped: params is not BleComConfig")
        }
    }

    override fun disConnect(unpair: Boolean) {
        isAiRecording = false
        speechAiSessionActive = false
        lastGlassWorkState = null
        rawAiAudioDumper.endSession("disconnect")
        manager.disconnect(unpair)
    }

    override fun getMediaFileCount() {
        manager.getMediaFileCount()
    }

    override fun syncAllMediaFile(wifiMode: GlassesConstant.WifiMode) {
        scope.launch {
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            manager.syncAllMediaFile()
        }
    }

    override fun setVideoDuration(times: Int) {
        manager.setVideoDuration(times)
    }

    override fun setVoiceDuration(times: Int) {
        manager.setVoiceDuration(times)
    }

    override fun rebootDevice() {
        manager.rebootDevice()
    }

    override fun upVolume() {
        manager.upVolume()
    }

    override fun downVolume() {
        manager.downVolume()
    }

    override fun takePicture(takePhotoOnly: Boolean) {
        manager.takePicture(awaitImageReturn = takePhotoOnly)
    }

    override fun aiImageRecognitionTts(baseWsMessage: BaseWsMessage<McpData>) {
        AiAssistantClient.getInstance().sendIotCommand(baseWsMessage)
    }

    override fun startVideoRecording() {
        manager.startVideoRecording()
    }

    override fun stopVideoRecording() {
        manager.stopVideoRecording()
    }

    override fun startAiAssistant() {
        manager.startAiAssistant()
    }

    override fun stopAiAssistant() {
        manager.stopAiAssistant()
    }

    override fun interruptAiAssistant() {
        manager.interruptAiAssistant()
    }

    override fun stopVadAudio() {
        isAiRecording = false
        manager.stopVadAudio()
    }

    override fun getBatteryLevel() {
        manager.getBatteryLevel()
    }

    override fun startDeviceRecording() {
        manager.startDeviceRecording()
    }

    override fun stopDeviceRecording() {
        manager.stopDeviceRecording()
    }

    override fun deviceShutDown() {
        manager.deviceShutDown()
    }

    override fun restoreFactorySettings() {
        manager.restoreFactorySettings()
    }

    override fun setTime() {
        manager.setTime()
    }

    override fun requestDeviceVersionInfo() {
        manager.requestDeviceVersionInfo()
    }

    override fun getDeviceStorage() {
        manager.getDeviceStorage()
    }

    override fun setLedBrightness(level: GlassesConstant.LedBrightnessLevel) {
        manager.setLedBrightness(level)
//        FissionLogUtils.d(TAG, "Not supported for now：setLedBrightness")
    }

    override fun setGestureShortcut(
        gesture: GlassesConstant.GestureType,
        action: GlassesConstant.GestureAction,
    ) {
        FissionLogUtils.d(TAG, "Not supported for now：setGestureShortcut")
    }

    override fun setWearDetection(state: GlassesConstant.WearDetectionState) {
        manager.setWearDetection(state)
    }

    override fun setScreenOrientation(orientation: GlassesConstant.ScreenOrientation) {
        manager.setScreenOrientation(orientation)
    }

    override fun resetGestureShortcuts() {
        FissionLogUtils.d(TAG, "Not supported for now：resetGestureShortcuts")
    }

    override fun getDeviceSettingsState() {
        manager.getDeviceSettingsState()
    }

    override fun startOTA(
        filePath: String,
        otaType: GlassesConstant.OtaType,
        version: String,
    ) {
        scope.launch {
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            when (otaType) {
                GlassesConstant.OtaType.FIRMWARE -> manager.startBleOta(filePath, version)
                GlassesConstant.OtaType.WIFI_ISP -> manager.startWifiOta(filePath)
            }
        }
    }

    override fun startLiveStreaming(liveStreamingConfig: LiveStreamingConfig) {
        scope.launch {
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            manager.startLiveStreaming()
        }
    }

    override fun startPushLiveStreaming(liveUrl: String) {
        FissionLogUtils.d(TAG, "Not supported for now：startPushLiveStreaming")
    }

    override fun stopLiveStreaming() {
        manager.stopLiveStreaming()
        endAssistantAfterWifiExclusiveSession()
    }

    private fun endAssistantAfterWifiExclusiveSession() {
        AiAssistantClient.getInstance().endWifiExclusiveSession()
    }

    override fun setLivePreviewMicState(enableState: GlassesConstant.EnableState) {
        FissionLogUtils.d(TAG, "Not supported for now：setLivePreviewMicState")
    }

    override fun getActionState() {
        manager.getActionState()
    }

    override fun setOfflineVoiceLanguage(language: GlassesConstant.OffLineLanguages) {
        manager.setOfflineVoiceLanguage(language)
    }

    override fun controlMusic(enable: Boolean) {
        manager.controlMusic(enable)
    }

    override fun switchMusic(action: GlassesConstant.MusicSwitchAction) {
        manager.switchMusic(action)
    }

    override fun getVoiceWakeUp() {
        manager.getVoiceWakeUp()
    }

    override fun setVoiceWakeUp(
        localOfflineEnabled: Boolean,
        opusPushEnabled: Boolean,
    ) {
        manager.setVoiceWakeUp(localOfflineEnabled)
    }

    override fun getGlassesVolume() {
        manager.getGlassesVolume()
    }

    override fun setGlassesVolume(
        type: GlassesConstant.AudioVolumeType,
        volume: Int,
    ) {
        manager.setGlassesVolume(type, volume)
    }

    override fun getDeviceSupportedFeatures() {
        FissionLogUtils.d(TAG, "Not supported for now：getDeviceSupportedFeatures")
    }

    override fun answerPhoneCall() {
        FissionLogUtils.d(TAG, "Not supported for now：answerPhoneCall")
    }

    override fun hangUpPhoneCall() {
        FissionLogUtils.d(TAG, "Not supported for now：hangUpPhoneCall")
    }

    override fun reconnectBluetooth() {
        manager.reconnectBluetooth()
    }

    private fun handleSpeechAiSessionStarted(scene: WKSpeechSession.Scene) {
        speechAiSessionActive = true
        rawAiAudioDumper.beginSession("speechAi_$scene")
        when (scene) {
            WKSpeechSession.Scene.CHAT,
            WKSpeechSession.Scene.RECORD,
            WKSpeechSession.Scene.CALL_RECORD,
            -> ensureDeviceAiRecordingStarted()
            else -> Unit
        }
    }

    private fun handleSpeechAiSessionEnded(scene: WKSpeechSession.Scene, reason: String) {
        speechAiSessionActive = false
        rawAiAudioDumper.endSession("speechAi_$scene:$reason")
        when (scene) {
            WKSpeechSession.Scene.CHAT -> {
                if (lastGlassWorkState != TbGlassWorkState.AI_DIALOGUE) {
                    exitAiDialogueIfNeeded(reason)
                } else {
                    isAiRecording = false
                }
            }
            WKSpeechSession.Scene.RECORD,
            WKSpeechSession.Scene.CALL_RECORD,
            -> {
                if (lastGlassWorkState != TbGlassWorkState.AI_DIALOGUE) {
                    exitAiDialogueIfNeeded(reason)
                } else {
                    isAiRecording = false
                }
            }
            else -> Unit
        }
    }

    private fun handleDeviceAiAudio(bytes: ByteArray, source: String) {
        if (source == "aIRecordData" &&
            lastGlassWorkState != TbGlassWorkState.AI_DIALOGUE &&
            !speechAiSessionActive
        ) {
            FissionLogUtils.w(TAG, "$source before session start, size=${bytes.size}")
        }
        rawAiAudioDumper.appendPacket(bytes)
        ensureDeviceAiRecordingStarted()
        scope.launch { eventBus.emit(AudioStateEvent.ReceivingAudioData(bytes.toList())) }
        sendReceivingAudioData(aiAssistantListenMode(), bytes)
    }

    /**
     * TB AI 对话以 [TbGlassWorkState.AI_DIALOGUE]（7）进入、[TbGlassWorkState.IDLE]（3）退出。
     * 新固件优先走 [WKSpeechSession]（speechAi）；不支持时回退 aIRecordData + glassWorkState。
     */
    private fun handleGlassWorkStateForAi(state: Int) {
        FissionLogUtils.d(TAG, "glassWorkState(AI)=$state last=$lastGlassWorkState")
        when (state) {
            TbGlassWorkState.AI_DIALOGUE -> enterAiDialogue()
            TbGlassWorkState.IDLE -> exitAiDialogueIfNeeded("glassWorkState=3")
        }
        lastGlassWorkState = state
    }

    private fun enterAiDialogue() {
        if (lastGlassWorkState != TbGlassWorkState.AI_DIALOGUE) {
            FissionLogUtils.d(TAG, "enter AI dialogue (glassWorkState=7)")
            if (!manager.isSpeechAiSessionActive()) {
                manager.ackDeviceAiDialogueOpus()
            }
            if (!speechAiSessionActive) {
                rawAiAudioDumper.beginSession("glassWorkState=7")
            }
        }
        ensureDeviceAiRecordingStarted()
    }

    /** [stateAIChat] 仅处理异常（0xFF）；正常开/关听以 glassWorkState 7/3 为准。 */
    private fun handleAiChatState(state: Int) {
        FissionLogUtils.d(TAG, "stateAIChat=$state (ignored unless 0xFF)")
        when (state) {
            0xFF -> {
                exitAiDialogueIfNeeded("stateAIChat error")
                AiAssistantClient.getInstance().notifyDeviceDialogueCancelled()
                scope.launch { eventBus.emit(AudioStateEvent.CancelRecording) }
                cancelReceivingAudio()
            }

            else -> Unit
        }
    }

    private fun exitAiDialogueIfNeeded(reason: String) {
        if (!isAiRecording &&
            lastGlassWorkState != TbGlassWorkState.AI_DIALOGUE &&
            !speechAiSessionActive
        ) {
            return
        }
        FissionLogUtils.d(TAG, "exit AI dialogue: $reason")
        rawAiAudioDumper.endSession(reason)
        speechAiSessionActive = false
        isAiRecording = false
        stopReceivingAudio(aiAssistantListenMode())
        AiAssistantClient.getInstance().notifyDeviceDialogueCancelled()
        scope.launch { eventBus.emit(AudioStateEvent.CancelRecording) }
    }

    private fun ensureDeviceAiRecordingStarted() {
        if (isAiRecording) return
        if (AiAssistantClient.getInstance().isListenBlockedByWsReconnect()) {
            FissionLogUtils.w(TAG, "WS 重连中，忽略 AI 音频流")
            stopVadAudio()
            return
        }
        isAiRecording = true
        AiAssistantClient.getInstance().notifyDeviceDialogueRecordingStarted()
        scope.launch { eventBus.emit(AudioStateEvent.StartRecording) }
        startReceivingAudio(
            aiAssistantListenMode(),
            AiAssistantClient.getInstance().getAiDialogueLanguage(),
        )
    }

    private fun handleImageComplete(img: ByteArray) {
        FissionLogUtils.d(TAG, "AI识图图片接收完毕，大小=${img.size}")
        scope.launch(Dispatchers.IO) {
            val imageDir = File(sdkConfig.context.filesDir, sdkConfig.aiImageRecognitionStorageDirName)
                .apply { mkdirs() }
            val path = File(imageDir, "${System.currentTimeMillis()}.jpg").absolutePath
            val file = File(path)
            try {
                file.writeBytes(img)
                scope.launch { eventBus.emit(CmdResultEvent.ImageFile(file)) }
                val started = AiAssistantClient.getInstance().aiImageRecognition(path)
                if (!started) {
                    FissionLogUtils.d(TAG, "AI识图缺少MCP消息")
                }
            } catch (e: Exception) {
                FissionLogUtils.d(TAG, "图片保存或AI识别异常: ${e.message}")
                scope.launch {
                    eventBus.emit(CmdResultEvent.Fail("图片保存或AI识别异常", ERROR_CODE_IMAGE_SAVE))
                }
                AiAssistantClient.getInstance().clearPendingAiImageRecognition()
            }
        }
    }

    private fun startReceivingAudio(mode: String, language: Int) {
        AiAssistantClient.getInstance().startReceivingAudio(mode, language)
    }

    private fun sendReceivingAudioData(mode: String, byteArray: ByteArray) {
        // 与 LY/RTK 一致：Opus 解码 + DSP 后按 PCM 上行（后台默认只收 PCM）
        AiAssistantClient.getInstance().sendAudio(mode, byteArray)
    }

    private fun stopReceivingAudio(mode: String) {
        AiAssistantClient.getInstance().stopReceivingAudio(mode)
    }

    private fun cancelReceivingAudio() {
        AiAssistantClient.getInstance().cancelReceivingAudio()
    }
}
