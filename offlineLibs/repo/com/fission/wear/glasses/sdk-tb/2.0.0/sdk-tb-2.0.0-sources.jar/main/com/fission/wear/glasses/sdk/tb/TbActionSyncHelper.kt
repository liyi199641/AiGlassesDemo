package com.fission.wear.glasses.sdk.tb

import com.fission.wear.glasses.sdk.constant.GlassesConstant.ActionSyncType
import com.fission.wear.glasses.sdk.util.FissionLogUtils

/**
 * 将 TB AbMate [glassWorkState] 映射为 [ActionSyncType] 事件。
 *
 * 设备上报枚举（拓步确认）：
 * - 3  空闲 / 退出 AI 对话
 * - 7  AI 对话中（进入 AI 对话；开听/停听由 [TbGlassesCmdStrategy] 处理）
 * - 9  拍照中
 * - 10 AI 拍照中
 * - 11 录像中
 * - 12 录音中
 * - 13 文件导入中
 *
 * 动作结束后设备会再次上报 [TbGlassWorkState.IDLE]（3）。
 */
internal class TbActionSyncHelper(
    private val emit: (ActionSyncType, Boolean) -> Unit,
) {
    private val TAG = "TbActionSyncHelper"
    private val lastStates = mutableMapOf<ActionSyncType, Boolean>()

    fun reset() {
        lastStates.clear()
    }

    fun applyGlassWorkState(value: Int?) {
        if (value == null) return
        FissionLogUtils.d(TAG, "glassWorkState=$value")
        when (value) {
            TbGlassWorkState.IDLE -> setAllIdle()
            TbGlassWorkState.PHOTO, TbGlassWorkState.AI_PHOTO -> setExclusiveActive(ActionSyncType.TAKE_PHOTO)
            TbGlassWorkState.VIDEO -> setExclusiveActive(ActionSyncType.RECORD_VIDEO)
            TbGlassWorkState.AUDIO -> setExclusiveActive(ActionSyncType.RECORD_AUDIO)
            TbGlassWorkState.IMPORT -> setExclusiveActive(ActionSyncType.IMPORTING)
            TbGlassWorkState.AI_DIALOGUE -> Unit
            else -> FissionLogUtils.w(TAG, "Unknown glassWorkState=$value")
        }
    }

    fun applyGlassTakePhoto(value: Int?) {
        if (value == null) return
        FissionLogUtils.d(TAG, "glassTakePhoto=$value (ActionSync driven by glassWorkState)")
    }

    fun applyWearDetection(value: Boolean?) {
        if (value == null) return
        emitActionSync(ActionSyncType.WEAR, value)
    }

    fun emitActionSync(type: ActionSyncType, active: Boolean) {
        if (lastStates[type] == active) return
        lastStates[type] = active
        FissionLogUtils.d(TAG, "ActionSync type=$type active=$active")
        emit(type, active)
    }

    private fun setAllIdle() {
        emitActionSync(ActionSyncType.TAKE_PHOTO, false)
        emitActionSync(ActionSyncType.RECORD_VIDEO, false)
        emitActionSync(ActionSyncType.RECORD_AUDIO, false)
        emitActionSync(ActionSyncType.IMPORTING, false)
    }

    private fun setExclusiveActive(active: ActionSyncType) {
        emitActionSync(ActionSyncType.TAKE_PHOTO, active == ActionSyncType.TAKE_PHOTO)
        emitActionSync(ActionSyncType.RECORD_VIDEO, active == ActionSyncType.RECORD_VIDEO)
        emitActionSync(ActionSyncType.RECORD_AUDIO, active == ActionSyncType.RECORD_AUDIO)
        emitActionSync(ActionSyncType.IMPORTING, active == ActionSyncType.IMPORTING)
    }
}
