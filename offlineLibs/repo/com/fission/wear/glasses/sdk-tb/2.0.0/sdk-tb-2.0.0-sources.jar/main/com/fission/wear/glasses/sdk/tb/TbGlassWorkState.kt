package com.fission.wear.glasses.sdk.tb

/**
 * 拓步 AbMate [glassWorkState] 枚举（厂商确认）。
 */
internal object TbGlassWorkState {
    /** 空闲；AI 对话结束也会回到此状态。 */
    const val IDLE = 3

    /** AI 对话中：进入 AI 对话的唯一标识。 */
    const val AI_DIALOGUE = 7

    const val PHOTO = 9
    const val AI_PHOTO = 10
    const val VIDEO = 11
    const val AUDIO = 12
    const val IMPORT = 13
}
