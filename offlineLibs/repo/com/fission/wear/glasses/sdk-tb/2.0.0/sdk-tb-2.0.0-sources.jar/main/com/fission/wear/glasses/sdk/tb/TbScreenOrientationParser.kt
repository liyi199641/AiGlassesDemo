package com.fission.wear.glasses.sdk.tb

import com.fission.wear.glasses.sdk.constant.GlassesConstant

/**
 * 拓步 screenConfig 解析，hex 格式与官方 [com.bluetrum.utils.ParserUtils.bytesToHex]（add0x=false）一致。
 *
 * - 纵向：`0100`（bytes `[0x01, 0x00]`）
 * - 横屏：`0101`（bytes `[0x01, 0x01]`）
 */
internal object TbScreenOrientationParser {
    private val HEX_ARRAY = charArrayOf(
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F',
    )

    /** 与 `ParserUtils.bytesToHex(bytes, false)` 一致。 */
    fun bytesToHex(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        val hexChars = CharArray(bytes.size * 2)
        for (j in bytes.indices) {
            val v = bytes[j].toInt() and 0xFF
            hexChars[j * 2] = HEX_ARRAY[v ushr 4]
            hexChars[j * 2 + 1] = HEX_ARRAY[v and 0x0F]
        }
        return String(hexChars)
    }

    fun parse(screen: ByteArray?): GlassesConstant.ScreenOrientation? {
        if (screen == null || screen.isEmpty()) return null
        val hex = bytesToHex(screen)
        return when (hex) {
            SCREEN_HEX_PORTRAIT -> GlassesConstant.ScreenOrientation.PORTRAIT
            SCREEN_HEX_LANDSCAPE -> GlassesConstant.ScreenOrientation.LANDSCAPE
            else -> parseFromOrientationByte(screen)
        }
    }

    /** 双字节时取方向字节（index=1）；单字节时直接解析。 */
    private fun parseFromOrientationByte(screen: ByteArray): GlassesConstant.ScreenOrientation? {
        val orientationByte = when {
            screen.size >= 2 -> screen[1]
            else -> screen[0]
        }
        return when (orientationByte.toInt() and 0xFF) {
            0x00, 0x30 -> GlassesConstant.ScreenOrientation.PORTRAIT
            0x01, 0x31 -> GlassesConstant.ScreenOrientation.LANDSCAPE
            else -> null
        }
    }

    private const val SCREEN_HEX_PORTRAIT = "0100"
    private const val SCREEN_HEX_LANDSCAPE = "0101"
}
