package com.fission.wear.glasses.sdk.tb

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.fission.wear.glasses.sdk.manager.RxBleClientProvider
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.polidea.rxandroidble3.RxBleClient
import com.topstep.wearkit.abmate.WKAbMateKit
import com.topstep.wearkit.abmate.apis.AbMateSDK
import com.topstep.wearkit.apis.WKWearKit
import com.topstep.wearkit.base.ProcessLifecycleManager
import com.topstep.wearkit.core.buildWKWearKit
import io.reactivex.rxjava3.exceptions.CompositeException
import io.reactivex.rxjava3.exceptions.UndeliverableException
import io.reactivex.rxjava3.functions.Consumer
import io.reactivex.rxjava3.plugins.RxJavaPlugins

/**
 * WearKit / AbMate 单例初始化（对齐官方 Demo [wearkitInit]）。
 */
internal object TbWearKitBootstrap {
    private const val TAG = "TbWearKitBootstrap"

    @Volatile
    private var wearKit: WKWearKit? = null

    @Volatile
    private var abMateSdk: AbMateSDK? = null

    @Volatile
    private var processLifecycleManager: TbProcessLifecycleManager? = null

    fun ensureInitialized(context: Context): AbMateSDK {
        abMateSdk?.let { return it }
        synchronized(this) {
            abMateSdk?.let { return it }
            val app = context.applicationContext as Application
            val lifecycle = processLifecycleManager ?: TbProcessLifecycleManager().also {
                processLifecycleManager = it
                ProcessLifecycleOwner.get().lifecycle.addObserver(it)
            }
            val rxBleClient: RxBleClient = RxBleClientProvider.get(app)

            AbMateSDK.BLE_CONNECTION = false
            // TB 仅注册 AbMate，不引入 FitCloud，避免与 RTK 方案重复 Realtek 类。
            val kit = buildWKWearKit(
                listOf(WKAbMateKit.Builder(app, lifecycle, rxBleClient)),
            )
            installRxJavaErrorHandler(kit)
            wearKit = kit
            val sdk = kit.getRawSDK() as AbMateSDK
            abMateSdk = sdk
            FissionLogUtils.d(TAG, "WearKit / AbMateSDK initialized")
            return sdk
        }
    }

    fun wearKitOrNull(): WKWearKit? = wearKit

    fun abMateSdkOrNull(): AbMateSDK? = abMateSdk

    fun requireWearKit(context: Context): WKWearKit {
        ensureInitialized(context)
        return wearKit!!
    }

    fun requireAbMateSdk(context: Context): AbMateSDK = ensureInitialized(context)

    private fun installRxJavaErrorHandler(kit: WKWearKit) {
        val ignores = HashSet<Class<out Throwable>>()
        ignores.addAll(kit.rxJavaPluginsIgnoreExceptions())
        val previous = RxJavaPlugins.getErrorHandler()
        RxJavaPlugins.setErrorHandler(TbRxJavaPluginsErrorHandler(ignores, previous))
    }
}

internal class TbProcessLifecycleManager : ProcessLifecycleManager(), DefaultLifecycleObserver {
    override fun onStart(owner: LifecycleOwner) {
        setForeground(true)
    }

    override fun onStop(owner: LifecycleOwner) {
        setForeground(false)
    }
}

private class TbRxJavaPluginsErrorHandler(
    private val ignores: Set<Class<out Throwable>>,
    private val previous: Consumer<in Throwable>?,
) : Consumer<Throwable> {
    override fun accept(t: Throwable) {
        if (handle(t)) return
        previous?.accept(t) ?: throw RuntimeException(t)
    }

    private fun handle(throwable: Throwable): Boolean {
        Log.d("TbRxJavaError", "handle", throwable)
        val cause = if (throwable is UndeliverableException) {
            throwable.cause
        } else {
            throwable
        } ?: return true

        if (cause is CompositeException) {
            var nullCount = 0
            for (e in cause.exceptions) {
                when {
                    e == null -> nullCount++
                    isIgnore(e) -> return true
                }
            }
            if (nullCount == cause.exceptions.size) return true
        } else if (isIgnore(cause)) {
            return true
        }
        return false
    }

    private fun isIgnore(throwable: Throwable): Boolean {
        val clazz = throwable::class.java
        return ignores.any { it.isAssignableFrom(clazz) }
    }
}
