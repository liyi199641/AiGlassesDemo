package com.fission.wear.glasses.sdk.util

import com.fission.wear.glasses.sdk.data.model.MediaDownloadProgressInfo
import com.fission.wear.glasses.sdk.rtk.RtkSoftApErrors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/**
 * RTK 媒体同步协调器：管理 AP 开启 → Wi‑Fi 连接 → HTTP 下载 → 关 AP → 后处理。
 *
 * **流水线模式**：每下载完一个文件即提交 [RtkMediaExportQueue]；
 * 后处理在独立单线程执行，[RtkImageCorrector] 使用 imageCorrect 协程封装（非 imageCorrectAsync）。
 *
 * Wi‑Fi 断连：仅在下载阶段、防抖确认后停止 HTTP；已提交的后处理继续完成。
 */
class RtkMediaSyncManager(
    private val scope: CoroutineScope,
    private val downloader: GalleryDownloader,
    private val exportQueue: RtkMediaExportQueue,
    private val callback: RtkMediaSyncCallback,
) {

    private val syncActive = AtomicBoolean(false)
    private val exportPhaseActive = AtomicBoolean(false)
    private val downloadPhaseActive = AtomicBoolean(false)
    private val intentionalApClose = AtomicBoolean(false)
    private val wifiLostDuringSync = AtomicBoolean(false)
    private val progressInfo = MediaDownloadProgressInfo()
    private var wifiDisconnectCheckJob: Job? = null

    val isSyncActive: Boolean
        get() = syncActive.get() || exportPhaseActive.get()

    fun startSync(
        ipAddress: String,
        imageCorrectEnabled: Boolean,
        enableAp: suspend () -> Boolean,
        connectWiFi: suspend () -> Boolean,
        disableAp: () -> Unit,
        unbindNetwork: () -> Unit,
        isWifiStillConnected: () -> Boolean = { false },
    ) {
        scope.launch(Dispatchers.IO) {
            if (!syncActive.compareAndSet(false, true)) {
                FissionLogUtils.w(TAG, "startSync skipped: sync already active")
                return@launch
            }
            wifiLostDuringSync.set(false)
            intentionalApClose.set(false)
            progressInfo.init(0)
            var shouldUnbindNetwork = false
            var syncFailed = false
            var failCode = 0
            var failReason = ""
            var downloadedCount = 0

            exportQueue.startPipeline(imageCorrectEnabled) { result ->
                callback.onFileExported(result, progressInfo.totalFileCount)
            }
            exportPhaseActive.set(true)

            try {
                FissionLogUtils.d(TAG, "startSync -> enableAp")
                if (!enableAp()) {
                    syncFailed = true
                    failCode = RtkSoftApErrors.CODE_AP_ENABLE_FAILED
                    failReason = RtkSoftApErrors.defaultReason(failCode)
                    return@launch
                }
                shouldUnbindNetwork = true

                if (!connectWiFi()) {
                    syncFailed = true
                    failCode = RtkSoftApErrors.CODE_WIFI_JOIN_FAILED
                    failReason = RtkSoftApErrors.defaultReason(failCode)
                    return@launch
                }

                callback.onConnectSuccess()
                downloadPhaseActive.set(true)
                downloadedCount = downloadMediaFiles(ipAddress)
                FissionLogUtils.d(
                    TAG,
                    "HTTP download phase finished, downloaded=$downloadedCount, wifiLost=${wifiLostDuringSync.get()}",
                )
            } finally {
                downloadPhaseActive.set(false)
                wifiDisconnectCheckJob?.cancel()
                wifiDisconnectCheckJob = null
                intentionalApClose.set(true)
                disableAp()
                intentionalApClose.set(false)
                syncActive.set(false)
                if (shouldUnbindNetwork) {
                    unbindNetwork()
                }
            }

            when {
                syncFailed -> {
                    exportQueue.abortPipeline()
                    exportPhaseActive.set(false)
                    callback.onSyncFailed(failCode, failReason)
                }
                downloadedCount == 0 && wifiLostDuringSync.get() -> {
                    val exportedCount = withContext(Dispatchers.IO) {
                        exportQueue.closePipelineAndAwait()
                    }
                    exportPhaseActive.set(false)
                    if (exportedCount > 0) {
                        callback.onSyncFinished(exportedCount, progressInfo.totalFileCount)
                    } else {
                        callback.onSyncFailed(
                            RtkSoftApErrors.CODE_WIFI_JOIN_FAILED,
                            "WiFi 连接已断开，未完成下载",
                        )
                    }
                }
                else -> {
                    val exportedCount = withContext(Dispatchers.IO) {
                        exportQueue.closePipelineAndAwait()
                    }
                    exportPhaseActive.set(false)
                    FissionLogUtils.d(
                        TAG,
                        "sync finished: exported=$exportedCount, total=${progressInfo.totalFileCount}",
                    )
                    callback.onSyncFinished(exportedCount, progressInfo.totalFileCount)
                }
            }
        }
    }

    fun onWifiConnectionStateChanged(connected: Boolean, isWifiStillConnected: () -> Boolean) {
        if (connected) {
            wifiDisconnectCheckJob?.cancel()
            wifiDisconnectCheckJob = null
            return
        }
        if (!downloadPhaseActive.get() || intentionalApClose.get()) {
            return
        }
        // 立即中止 HTTP，避免对剩余文件做无效重试；防抖仅用于误报恢复与上层回调。
        if (wifiLostDuringSync.compareAndSet(false, true)) {
            FissionLogUtils.w(TAG, "wifi lost during download, stop HTTP immediately")
            downloader.stopDownloadProcedure()
        }
        wifiDisconnectCheckJob?.cancel()
        wifiDisconnectCheckJob = scope.launch(Dispatchers.IO) {
            delay(WIFI_DISCONNECT_DEBOUNCE_MS)
            if (!downloadPhaseActive.get() && !wifiLostDuringSync.get()) return@launch
            if (intentionalApClose.get()) return@launch
            if (isWifiStillConnected()) {
                FissionLogUtils.d(TAG, "wifi disconnect debounced: still connected to glasses AP")
                wifiLostDuringSync.set(false)
                return@launch
            }
            if (downloadPhaseActive.get()) {
                downloader.stopDownloadProcedure()
            }
            callback.onWifiDisconnectedDuringSync()
        }
    }

    fun stopSync() {
        wifiLostDuringSync.set(true)
        downloadPhaseActive.set(false)
        wifiDisconnectCheckJob?.cancel()
        wifiDisconnectCheckJob = null
        downloader.stopDownloadProcedure()
        exportQueue.abort()
        exportPhaseActive.set(false)
        syncActive.set(false)
    }

    private fun downloadMediaFiles(ipAddress: String): Int {
        progressInfo.init(0)
        val items = downloader.downloadMediaFiles(
            ipAddress = ipAddress,
            onPrepared = { total ->
                progressInfo.init(total)
                callback.onDownloadPrepared(total, progressInfo)
            },
            onStarted = {
                progressInfo.start()
                callback.onDownloadProgress(progressInfo)
            },
            onProgress = { percent ->
                progressInfo.downloadProgress = percent
                callback.onDownloadProgress(progressInfo)
            },
            onItemDownloaded = { item ->
                exportQueue.submit(item)
            },
        )
        return items.size
    }

    companion object {
        private const val TAG = "RtkMediaSyncManager"
        private const val WIFI_DISCONNECT_DEBOUNCE_MS = 2_000L
    }
}
