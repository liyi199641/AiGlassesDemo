package com.fission.wear.glasses.sdk.rtk.protocol

data class ChargingStatusInfo(
    val isCharging: Boolean,
    val batteryLevel: Int,
    val rawPayload: ByteArray = ByteArray(0)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ChargingStatusInfo) return false
        return isCharging == other.isCharging &&
            batteryLevel == other.batteryLevel &&
            rawPayload.contentEquals(other.rawPayload)
    }

    override fun hashCode(): Int {
        var result = isCharging.hashCode()
        result = 31 * result + batteryLevel
        result = 31 * result + rawPayload.contentHashCode()
        return result
    }
}

data class CustomProtocolEventInfo(
    val eventId: Int,
    val rawPayload: ByteArray,
    val payloadHex: String,
    val summary: String
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is CustomProtocolEventInfo) return false
        return eventId == other.eventId &&
            rawPayload.contentEquals(other.rawPayload) &&
            payloadHex == other.payloadHex &&
            summary == other.summary
    }

    override fun hashCode(): Int {
        var result = eventId
        result = 31 * result + rawPayload.contentHashCode()
        result = 31 * result + payloadHex.hashCode()
        result = 31 * result + summary.hashCode()
        return result
    }
}

data class DeviceVersionPayload(
    val bleVersion: String,
    val wifiVersion: String
)

data class DeviceStatusPayload(
    val charging: Int,
    val battery: Int,
    val wearingReminder: Int,
    val voiceWakeup: Int,
    val led: Int,
    val shootingDirection: Int,
    val videoRecordingDuration: Int,
    val audioRecordingDuration: Int,
    val wearingStatus: Int,
    val photoStatus: Int,
    val audioRecordingStatus: Int,
    val videoRecordingStatus: Int
)

data class MediaStatusPayload(
    val status: Int,
    val reason: Int
)

data class TouchpadGesturePayload(
    val gestureType: Int,
    val action: Int,
)

abstract class RtkCustomCommandCallback {
    abstract fun onExecuteFailed(errorCode: Int)
}

abstract class RtkCustomAckCallback : RtkCustomCommandCallback() {
    abstract fun onExecuteSuccess()
}

abstract class RtkCustomEventCallback<T> : RtkCustomCommandCallback() {
    abstract fun onExecuteSuccess(result: T)
}
