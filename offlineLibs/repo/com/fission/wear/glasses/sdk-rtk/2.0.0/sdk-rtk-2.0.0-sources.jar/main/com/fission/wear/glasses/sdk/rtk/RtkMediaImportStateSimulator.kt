package com.fission.wear.glasses.sdk.rtk

import com.fission.wear.glasses.sdk.constant.GlassesConstant.ActionSyncType

/**
 * RTK 眼镜固件未实现 LY 方案 0x45 动作同步中的「媒体文件导入中」位（index=9）。
 * 在 Wi-Fi 媒体同步期间本地仿造 [ActionSyncType.IMPORTING] 开/关上报，
 * 与 LY 设备侧导入模式状态对齐，供 App 层 ActionSync 订阅者复用。
 */
class RtkMediaImportStateSimulator(
    private val emit: (ActionSyncType, Boolean) -> Unit,
) {
    private var isImporting = false

    /** 媒体同步开始（App 发起 sync 或 SDK 进入下载流程）。 */
    fun onMediaSyncStarted() {
        if (isImporting) return
        isImporting = true
        emit(ActionSyncType.IMPORTING, true)
    }

    /** 媒体同步结束（成功、失败或取消）。 */
    fun onMediaSyncFinished() {
        if (!isImporting) return
        isImporting = false
        emit(ActionSyncType.IMPORTING, false)
    }

    /** 连接断开或 SDK 释放时重置，避免 UI 卡在导入中。 */
    fun reset() {
        onMediaSyncFinished()
    }

    fun isImporting(): Boolean = isImporting
}
