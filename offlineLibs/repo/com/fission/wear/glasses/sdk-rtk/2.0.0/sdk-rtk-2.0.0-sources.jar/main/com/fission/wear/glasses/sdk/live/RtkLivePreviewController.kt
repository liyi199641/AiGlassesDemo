package com.fission.wear.glasses.sdk.live

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ResultReceiver
import android.view.Surface
import android.view.SurfaceHolder
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.realsil.sdk.audioconnect.smartwear.live.PlayerServiceContract
import com.realsil.sdk.audioconnect.smartwear.live.RTKMediaPlayerService
import com.realsil.sdk.audioconnect.smartwear.live.SessionConfig
import com.realsil.sdk.audioconnect.smartwear.live.view.RTKVideoView

/**
 * RTK WIFI(AP) 直播预览/推流封装。
 *
 * 流程对齐官方 [DebugLiveStreamingActivity]：
 * 1. [com.fission.wear.glasses.sdk.manager.RtkSdkManager.startLiveStreaming] → liveStreamingManager（眼镜 AP）
 * 2. onStartLiveStreaming(WIFI_AP) → [startLiveStreamingOnWifiApMode] → RTKMediaPlayerService
 */
internal class RtkLivePreviewController(
    private val appContext: Context,
) {

    private var previewCallback: LivePreviewCallback? = null
    private var previewView: RTKVideoView? = null
    private var surfaceCallback: SurfaceHolder.Callback? = null

    fun attachPreviewView(view: RTKVideoView) {
        if (previewView === view) {
            rebindPreviewSurface()
            return
        }
        detachPreviewView()
        previewView = view
        val callback = object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                FissionLogUtils.d(TAG, "preview surfaceCreated")
                bindPreviewSurface(holder.surface)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                FissionLogUtils.d(TAG, "preview surfaceChanged ${width}x$height")
                if (isSurfaceValid(holder.surface)) {
                    bindPreviewSurface(holder.surface)
                }
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                FissionLogUtils.d(TAG, "preview surfaceDestroyed")
                runCatching { RTKVideoView.nativeDestroyEGLWindow() }
            }
        }
        surfaceCallback = callback
        view.holder.addCallback(callback)
        view.onResume()
        rebindPreviewSurface()
        FissionLogUtils.d(TAG, "preview view attached: $view")
    }

    fun detachPreviewView() {
        val view = previewView ?: return
        surfaceCallback?.let { runCatching { view.holder.removeCallback(it) } }
        surfaceCallback = null
        runCatching { view.onPause() }
        previewView = null
        FissionLogUtils.d(TAG, "preview view detached")
    }

    /** 播放器启动或 Surface 就绪后重新绑定本地预览窗口。 */
    fun rebindPreviewSurface() {
        val view = previewView ?: return
        view.onResume()
        val surface = view.holder.surface
        if (surface != null && isSurfaceValid(surface)) {
            bindPreviewSurface(surface)
        }
    }

    fun setPreviewCallback(callback: LivePreviewCallback?) {
        previewCallback = callback
    }

    fun setPreviewRotation(degrees: Int) {
        previewView?.rotation = degrees.toFloat()
        rebindPreviewSurface()
    }

    /**
     * 启动 [RTKMediaPlayerService]，对齐官方 Demo `startLiveStreamingOnWifiApMode()`。
     *
     * SessionConfig 使用默认 `mInputUrl`（rtsp://192.168.43.1:554），
     * 网络路由由官方播放器内部处理。
     */
    fun startLiveStreamingOnWifiApMode(sessionType: Byte, pushUrl: String?) {
        if (sessionType != SessionConfig.SESSION_TYPE_PUSH) {
            rebindPreviewSurface()
        }
        val sessionConfig = SessionConfig().apply {
            mSessionType = sessionType
            if (!pushUrl.isNullOrBlank()) {
                mPushUrl = pushUrl
            }
        }
        FissionLogUtils.d(
            TAG,
            "startLiveStreamingOnWifiApMode type=$sessionType push=${pushUrl.orEmpty()} input=${sessionConfig.mInputUrl}",
        )
        // PREVIEW_PUSH 在已有预览会话上追加推流，勿 stop()，否则 EGL/VideoView 被销毁且无画面
        startPreviewService(sessionConfig)
    }

    fun stop() {
        runCatching {
            val intent = Intent(appContext, RTKMediaPlayerService::class.java)
            appContext.stopService(intent)
        }
    }

    private fun bindPreviewSurface(surface: Surface) {
        runCatching {
            RTKVideoView.nativeInitEGLWindow(surface)
            FissionLogUtils.d(TAG, "nativeInitEGLWindow ok")
        }.onFailure { e ->
            FissionLogUtils.e(TAG, "nativeInitEGLWindow failed: ${e.message}")
        }
    }

    private fun isSurfaceValid(surface: Surface): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            surface.isValid
        } else {
            true
        }
    }

    private fun startPreviewService(sessionConfig: SessionConfig) {
        val launchPreview = Runnable {
            val resultReceiver = object : ResultReceiver(Handler(Looper.getMainLooper())) {
                override fun onReceiveResult(resultCode: Int, resultData: android.os.Bundle?) {
                    when {
                        resultCode == PlayerServiceContract.RESULT_SUCCESS -> {
                            rebindPreviewSurface()
                            previewCallback?.onPreviewStarted()
                        }
                        resultCode == PlayerServiceContract.RESULT_NETWORK_DISCONNECTED -> {//直播中热点异常
                            previewCallback?.onPreviewFailed(resultCode)
                            FissionLogUtils.i(TAG,"LIVE Preview Network error: $resultCode")
                        }
                        resultCode == PlayerServiceContract.RESULT_LIVE_STOPPED -> {//通知栏关闭直播服务
                            previewCallback?.onLiveStoppedByNotification()
                            FissionLogUtils.i(TAG, "LIVE stopped from notification bar")
                        }
                        resultCode < 0 -> {
                            val reason = PlayerServiceContract.error2Str(resultCode)
                            previewCallback?.onPreviewFailed(resultCode)
                            FissionLogUtils.e(TAG, "LIVE Preview service failed: $reason")
                        }
                    }
                }
            }
            val intent = Intent(appContext, RTKMediaPlayerService::class.java).apply {
                action = RTKMediaPlayerService.ACTION_START
                putExtra(RTKMediaPlayerService.EXTRA_PLAY_PARAMS, sessionConfig)
                putExtra(RTKMediaPlayerService.EXTRA_PLAY_RESULT, resultReceiver)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            launchPreview.run()
        } else {
            Handler(Looper.getMainLooper()).post(launchPreview)
        }
    }

    companion object {
        private const val TAG = "RtkLivePreviewController"
    }
}
