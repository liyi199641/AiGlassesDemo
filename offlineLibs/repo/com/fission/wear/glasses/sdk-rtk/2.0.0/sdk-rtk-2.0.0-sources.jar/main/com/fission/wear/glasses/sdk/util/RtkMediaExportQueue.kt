package com.fission.wear.glasses.sdk.util

import android.content.Context
import com.fission.wear.glasses.sdk.data.model.NameInfo
import com.fission.wear.glasses.sdk.model.RtkDownloadedMediaItem
import com.fission.wear.glasses.sdk.model.RtkMediaExportResult
import com.fission.wear.glasses.sdk.rtk.RtkSyncedMediaClassifier.SyncedMediaKind
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * RTK 媒体导出队列：畸变校正、降噪、音频 mp4→wav 等本地后处理。
 *
 * 支持两种模式：
 * - [processQueue]：批量串行（AP 关闭后一次性处理）
 * - 流水线：[startPipeline] → [submit] × N → [closePipelineAndAwait]
 *   与 [GalleryDownloader] 并行；后处理在独立单线程执行，imageCorrect 走同步 API 协程封装。
 */
class RtkMediaExportQueue(
    private val context: Context,
    private val correctedPictureDir: String,
) {

    private val exportExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "RtkMediaExport").apply { isDaemon = true }
    }

    @Volatile
    private var batchAborted = false

    // --- 流水线状态 ---
    private val pipelineActive = AtomicBoolean(false)
    private val pipelineAborted = AtomicBoolean(false)
    private val pipelineClosed = AtomicBoolean(false)
    private val pipelinePending = AtomicInteger(0)
    @Volatile
    private var pipelineLatch: CountDownLatch? = null
    @Volatile
    private var pipelineImageCorrectEnabled = false
    @Volatile
    private var pipelineOnItemExported: ((RtkMediaExportResult) -> Unit)? = null
    private val pipelineExportedCount = AtomicInteger(0)

    fun abort() {
        batchAborted = true
        abortPipeline()
    }

    /**
     * 批量串行后处理（AP 已全部关闭、下载列表已就绪时使用）。
     */
    fun processQueue(
        items: List<RtkDownloadedMediaItem>,
        imageCorrectEnabled: Boolean,
        timeStampSyncEnabled: Boolean = false,
        onItemExported: (RtkMediaExportResult) -> Unit,
    ): List<NameInfo> {
        batchAborted = false
        if (items.isEmpty()) return emptyList()

        FissionLogUtils.d(TAG, "batch export, size=${items.size}, imageCorrect=$imageCorrectEnabled")
        if (imageCorrectEnabled) {
            RtkImageCorrector.prepareDefaultConfig(context.applicationContext)
        }

        val exported = mutableListOf<NameInfo>()
        for (item in items) {
            if (batchAborted) {
                FissionLogUtils.w(TAG, "batch export aborted at index=${item.fileIndex}")
                break
            }
            val exportPath = exportItem(item, imageCorrectEnabled) ?: continue
            val exportFile = File(exportPath)
            if (!exportFile.exists()) continue

            val result = RtkMediaExportResult(
                exportFile = exportFile,
                mediaName = item.media.name,
                fileIndex = item.fileIndex,
            )
            onItemExported(result)
            exported.add(NameInfo(exportFile, item.media.name, timeStampSyncEnabled))
        }

        FissionLogUtils.d(TAG, "batch export finished, exported=${exported.size}/${items.size}")
        return exported
    }

    /** 启动流水线消费者（单线程串行后处理，可与下载并行）。 */
    fun startPipeline(
        imageCorrectEnabled: Boolean,
        onItemExported: (RtkMediaExportResult) -> Unit,
    ) {
        abortPipeline()
        pipelineAborted.set(false)
        pipelineClosed.set(false)
        pipelinePending.set(0)
        pipelineExportedCount.set(0)
        pipelineImageCorrectEnabled = imageCorrectEnabled
        pipelineOnItemExported = onItemExported
        pipelineLatch = CountDownLatch(1)
        pipelineActive.set(true)

        if (imageCorrectEnabled) {
            RtkImageCorrector.prepareDefaultConfig(context.applicationContext)
        }
        FissionLogUtils.d(TAG, "pipeline started, imageCorrect=$imageCorrectEnabled")
    }

    /** 下载完一项后立即提交；线程安全，可在 HTTP 下载线程调用。 */
    fun submit(item: RtkDownloadedMediaItem) {
        if (!pipelineActive.get() || pipelineAborted.get()) return
        pipelinePending.incrementAndGet()
        exportExecutor.execute {
            if (pipelineAborted.get()) {
                onPipelineItemDone()
                return@execute
            }
            val exportPath = exportItem(item, pipelineImageCorrectEnabled) ?: run {
                onPipelineItemDone()
                return@execute
            }
            val exportFile = File(exportPath)
            if (!exportFile.exists() || pipelineAborted.get()) {
                onPipelineItemDone()
                return@execute
            }
            val result = RtkMediaExportResult(
                exportFile = exportFile,
                mediaName = item.media.name,
                fileIndex = item.fileIndex,
            )
            pipelineOnItemExported?.invoke(result)
            pipelineExportedCount.incrementAndGet()
            onPipelineItemDone()
        }
    }

    /** 下载阶段结束；等待队列中剩余项处理完毕。 */
    fun closePipelineAndAwait(timeoutMs: Long = PIPELINE_AWAIT_TIMEOUT_MS): Int {
        if (!pipelineActive.compareAndSet(true, false)) {
            return pipelineExportedCount.get()
        }
        pipelineClosed.set(true)
        if (pipelinePending.get() == 0) {
            pipelineLatch?.countDown()
        }
        pipelineLatch?.await(timeoutMs, TimeUnit.MILLISECONDS)
        pipelineOnItemExported = null
        FissionLogUtils.d(
            TAG,
            "pipeline closed, exported=${pipelineExportedCount.get()}, pending=${pipelinePending.get()}",
        )
        return pipelineExportedCount.get()
    }

    fun abortPipeline() {
        pipelineAborted.set(true)
        pipelineActive.set(false)
        pipelineClosed.set(true)
        pipelineLatch?.countDown()
        pipelineOnItemExported = null
    }

    private fun onPipelineItemDone() {
        if (pipelinePending.decrementAndGet() == 0 && pipelineClosed.get()) {
            pipelineLatch?.countDown()
        }
    }

    private fun exportItem(
        item: RtkDownloadedMediaItem,
        imageCorrectEnabled: Boolean,
    ): String? {
        return when {
            item.mediaKind == SyncedMediaKind.IMAGE && imageCorrectEnabled -> {
                val correctedOut = File(
                    correctedPictureDir.ifEmpty { item.localFile.parent },
                    item.localFile.name,
                ).absolutePath
                RtkImageCorrector.correctSyncedJpegBlocking(
                    context,
                    item.localFile.absolutePath,
                    correctedOut,
                )
            }

            item.mediaKind == SyncedMediaKind.AUDIO -> {
                val wavFile = Mp4ToWavConverter.convert(item.localFile)
                if (wavFile == null) {
                    FissionLogUtils.w(TAG, "audio mp4 to wav failed, skip: ${item.media.name}")
                    return null
                }
                item.localFile.delete()
                wavFile.absolutePath
            }

            else -> item.localFile.absolutePath
        }
    }

    companion object {
        private const val TAG = "RtkMediaExportQueue"
        private const val PIPELINE_AWAIT_TIMEOUT_MS = 30 * 60 * 1000L
    }
}
