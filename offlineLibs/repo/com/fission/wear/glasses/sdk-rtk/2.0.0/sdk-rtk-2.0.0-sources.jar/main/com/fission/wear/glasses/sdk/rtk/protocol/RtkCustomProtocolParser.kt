package com.fission.wear.glasses.sdk.rtk.protocol

import java.nio.charset.StandardCharsets
import java.util.Locale

object RtkCustomProtocolParser {

    fun bytesToHex(data: ByteArray?): String {
        if (data == null || data.isEmpty()) return "<empty>"
        return buildString {
            data.forEachIndexed { index, byte ->
                if (index > 0) append(' ')
                append(String.format(Locale.US, "%02X", byte.toInt() and 0xFF))
            }
        }
    }

    fun parseChargingStatus(parameters: ByteArray?): ChargingStatusInfo? {
        if (parameters == null || parameters.isEmpty()) return null

        val chargingState = parameters[0].toInt() and 0xFF
        val isCharging = chargingState == 0x01

        var batteryLevel = -1
        if (parameters.size > 1) {
            val rawBatteryLevel = parameters[1].toInt() and 0xFF
            if (rawBatteryLevel <= 100) {
                batteryLevel = rawBatteryLevel
            }
        }
        return ChargingStatusInfo(isCharging, batteryLevel, parameters)
    }

    fun parseDeviceVersionString(payload: ByteArray?): String? {
        if (payload == null || payload.isEmpty()) return null
        val length = payload[0].toInt() and 0xFF
        if (length == 0 || payload.size < length + 1) return null
        return String(payload, 1, length, StandardCharsets.UTF_8)
    }

    /**
     * v0.2.0+: BLE + WiFi 双版本（0x0804）
     * Byte[0]=N, Byte[1..N]=BLE, Byte[N+1]=M, Byte[N+2..N+1+M]=WiFi
     * 兼容 v0.1.0 仅单版本字符串。
     */
    fun parseDeviceVersionReport(payload: ByteArray?): DeviceVersionPayload? {
        if (payload == null || payload.isEmpty()) return null
        val bleLen = payload[0].toInt() and 0xFF
        if (bleLen == 0) {
            return DeviceVersionPayload(bleVersion = "", wifiVersion = "")
        }
        if (payload.size < bleLen + 1) return null

        val bleVersion = try {
            String(payload, 1, bleLen, StandardCharsets.UTF_8)
        } catch (_: Exception) {
            return null
        }

        val wifiLenOffset = 1 + bleLen
        if (payload.size <= wifiLenOffset) {
            return DeviceVersionPayload(bleVersion = bleVersion, wifiVersion = "")
        }

        val wifiLen = payload[wifiLenOffset].toInt() and 0xFF
        if (wifiLen == 0) {
            return DeviceVersionPayload(bleVersion = bleVersion, wifiVersion = "")
        }

        val wifiDataOffset = wifiLenOffset + 1
        val expectedSize = wifiDataOffset + wifiLen
        if (payload.size < expectedSize) {
            return DeviceVersionPayload(bleVersion = bleVersion, wifiVersion = "")
        }

        val wifiVersion = normalizeWifiVersionDisplay(
            parseWifiVersionField(payload, wifiDataOffset, wifiLen)
        )
        return DeviceVersionPayload(bleVersion = bleVersion, wifiVersion = wifiVersion)
    }

    /**
     * WiFi 版本支持两种固件格式：
     * 1. UTF-8 字符串（可能段序反了，如 "42.1.20.3"）
     * 2. 4 字节二进制，小端序：2A 01 14 03 -> "3.20.1.42"
     */
    internal fun parseWifiVersionField(payload: ByteArray, offset: Int, length: Int): String {
        if (length == 4 && isBinaryWifiVersionBytes(payload, offset)) {
            return (3 downTo 0).joinToString(".") { (payload[offset + it].toInt() and 0xFF).toString() }
        }
        return try {
            String(payload, offset, length, StandardCharsets.UTF_8).trim('\u0000')
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * 固件可能返回反序点分版本（42.1.20.3），正确应为 3.20.1.42。
     * 当四段均为数字且首段大于末段时，反转段序。
     */
    internal fun normalizeWifiVersionDisplay(version: String): String {
        if (version.isEmpty()) return version
        val parts = version.split('.')
        if (parts.size != 4) return version
        val numbers = parts.mapNotNull { it.toIntOrNull() }
        if (numbers.size != 4) return version
        return if (numbers[0] > numbers[3]) {
            parts.reversed().joinToString(".")
        } else {
            version
        }
    }

    private fun isBinaryWifiVersionBytes(payload: ByteArray, offset: Int): Boolean {
        return (0 until 4).none { index ->
            val value = payload[offset + index].toInt() and 0xFF
            value in 0x30..0x39 || value == 0x2E
        }
    }

    fun explainWifiVersionAbsence(payload: ByteArray?): String {
        if (payload == null || payload.isEmpty()) return "empty payload"
        val bleLen = payload[0].toInt() and 0xFF
        if (bleLen == 0) return "ble length is 0"
        val wifiLenOffset = 1 + bleLen
        if (payload.size <= wifiLenOffset) {
            return "payload too short for WiFi length byte (size=${payload.size}, need>${wifiLenOffset})"
        }
        val wifiLen = payload[wifiLenOffset].toInt() and 0xFF
        if (wifiLen == 0) return "WiFi length byte is 0x00"
        val expectedSize = wifiLenOffset + 1 + wifiLen
        if (payload.size < expectedSize) {
            return "payload too short for WiFi string (size=${payload.size}, need=$expectedSize, wifiLen=$wifiLen)"
        }
        return "WiFi string present but parse returned empty"
    }

    fun parseLedBrightnessValue(payload: ByteArray?): Int? {
        if (payload == null || payload.isEmpty()) return null
        return payload[0].toInt() and 0xFF
    }

    fun parseDeviceStatusPayload(payload: ByteArray?): DeviceStatusPayload? {
        if (payload == null || payload.isEmpty()) return null
        val videoRecordingDuration = parseUint16Le(payload, 6)
        val audioRecordingDuration = parseUint16Le(payload, 8)
        return DeviceStatusPayload(
            charging = getPayloadByte(payload, 0),
            battery = getPayloadByte(payload, 1),
            wearingReminder = getPayloadByte(payload, 2),
            voiceWakeup = getPayloadByte(payload, 3),
            led = getPayloadByte(payload, 4),
            shootingDirection = getPayloadByte(payload, 5),
            videoRecordingDuration = videoRecordingDuration,
            audioRecordingDuration = audioRecordingDuration,
            wearingStatus = getPayloadByte(payload, 10),
            photoStatus = getPayloadByte(payload, 11),
            audioRecordingStatus = getPayloadByte(payload, 12),
            videoRecordingStatus = getPayloadByte(payload, 13)
        )
    }

    fun parseWearingStatus(payload: ByteArray?): Int? {
        if (payload == null || payload.isEmpty()) return null
        return payload[0].toInt() and 0xFF
    }

    fun parseMediaStatus(payload: ByteArray?): MediaStatusPayload? {
        if (payload == null || payload.isEmpty()) return null
        val status = payload[0].toInt() and 0xFF
        val reason = if (payload.size > 1) payload[1].toInt() and 0xFF else -1
        return MediaStatusPayload(status = status, reason = reason)
    }

    fun parseWifiApStatus(payload: ByteArray?): Boolean? {
        if (payload == null || payload.isEmpty()) return null
        return when (payload[0].toInt() and 0xFF) {
            0x00 -> false
            0x01 -> true
            else -> null
        }
    }

    fun parseTouchpadGesture(payload: ByteArray?): TouchpadGesturePayload? {
        if (payload == null || payload.isEmpty()) return null
        val gestureType = payload[0].toInt() and 0xFF
        val action = if (payload.size > 1) payload[1].toInt() and 0xFF else 0x00
        return TouchpadGesturePayload(gestureType = gestureType, action = action)
    }

    fun buildEventSummary(eventId: Int, payload: ByteArray?): String =
        when (eventId) {
            CustomVendorProtocol.EVENT_CHARGING_STATUS_CHANGED -> {
                val info = parseChargingStatus(payload)
                if (info == null) {
                    "Charging: parse failed"
                } else {
                    String.format(
                        Locale.US,
                        "Charging: %s, Battery: %s",
                        if (info.isCharging) "YES" else "NO",
                        if (info.batteryLevel >= 0) "${info.batteryLevel}%" else "unknown"
                    )
                }
            }

            CustomVendorProtocol.EVENT_DEVICE_VERSION_REPORT -> {
                val version = parseDeviceVersionReport(payload)
                if (version == null) {
                    "Device version: parse failed"
                } else {
                    String.format(
                        Locale.US,
                        "Device version: BLE=%s, WiFi=%s",
                        version.bleVersion.ifEmpty { "unknown" },
                        version.wifiVersion.ifEmpty { "unknown" }
                    )
                }
            }

            CustomVendorProtocol.EVENT_LED_BRIGHTNESS_REPORT ->
                "LED brightness: ${formatLedBrightness(parseLedBrightnessValue(payload))}"

            CustomVendorProtocol.EVENT_DEVICE_STATUS_REPORT ->
                formatDeviceStatusSummary(parseDeviceStatusPayload(payload))

            CustomVendorProtocol.EVENT_TOUCHPAD_GESTURE ->
                formatTouchpadGesture(payload)

            CustomVendorProtocol.EVENT_WEARING_STATUS_CHANGED ->
                formatWearingStatus(parseWearingStatus(payload))

            CustomVendorProtocol.EVENT_PHOTO_STATUS_CHANGED ->
                formatMediaStatus("Photo", parseMediaStatus(payload))

            CustomVendorProtocol.EVENT_AUDIO_RECORDING_STATUS_CHANGED ->
                formatMediaStatus("Audio recording", parseMediaStatus(payload))

            CustomVendorProtocol.EVENT_VIDEO_RECORDING_STATUS_CHANGED ->
                formatMediaStatus("Video recording", parseMediaStatus(payload))

            CustomVendorProtocol.EVENT_LW_WIFI_AP_STATUS_CHANGED ->
                formatWifiApStatus(parseWifiApStatus(payload))

            else -> "Unknown custom event"
        }

    private fun formatLedBrightness(value: Int?): String = when (value) {
        0x00 -> "low"
        0x01 -> "medium"
        0x02 -> "high"
        0xFF -> "unknown"
        null -> "unknown(empty payload)"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatDeviceStatusSummary(status: DeviceStatusPayload?): String {
        if (status == null) return "Status: parse failed"
        return String.format(
            Locale.US,
            "Status: charging=%s, battery=%s, wearingReminder=%s, voiceWakeup=%s, led=%s, shootingDirection=%s, videoDuration=%s, audioDuration=%s, wearing=%s, photo=%s, audioRec=%s, videoRec=%s",
            formatChargingState(status.charging),
            formatBatteryLevel(status.battery),
            formatSwitchState(status.wearingReminder),
            formatSwitchState(status.voiceWakeup),
            formatLedBrightness(status.led),
            formatShootingDirection(status.shootingDirection),
            formatRecordingDuration(status.videoRecordingDuration),
            formatRecordingDuration(status.audioRecordingDuration),
            formatWearingStatus(status.wearingStatus),
            formatPhotoStatus(status.photoStatus),
            formatRecordingStatus(status.audioRecordingStatus),
            formatRecordingStatus(status.videoRecordingStatus)
        )
    }

    private fun formatWearingStatus(value: Int?): String = when (value) {
        0x00 -> "not wearing"
        0x01 -> "wearing"
        0xFF -> "unknown"
        null -> "unknown(empty payload)"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatPhotoStatus(value: Int): String = when (value) {
        0x00 -> "idle"
        0x01 -> "capturing"
        0x02 -> "success"
        0x03 -> "failed"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatRecordingStatus(value: Int): String = when (value) {
        0x00 -> "idle"
        0x01 -> "recording"
        0x02 -> "paused"
        0x03 -> "saving"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatWifiApStatus(enabled: Boolean?): String = when (enabled) {
        true -> "WiFi AP: enabled"
        false -> "WiFi AP: closed"
        null -> "WiFi AP: parse failed"
    }

    private fun formatMediaStatus(label: String, media: MediaStatusPayload?): String {
        if (media == null) return "$label: parse failed"
        val reasonText = if (media.reason >= 0) formatStatusReason(media.reason) else "none"
        return String.format(
            Locale.US,
            "%s: status=%s, reason=%s",
            label,
            when (label) {
                "Photo" -> formatPhotoStatus(media.status)
                else -> formatRecordingStatus(media.status)
            },
            reasonText
        )
    }

    private fun formatStatusReason(value: Int): String = when (value) {
        0x00 -> "none"
        0x01 -> "storage full"
        0x02 -> "device busy"
        0x03 -> "user cancelled"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatTouchpadGesture(payload: ByteArray?): String {
        val gesture = getPayloadByte(payload, 0)
        val action = if (payload != null && payload.size > 1) payload[1].toInt() and 0xFF else 0x00
        return String.format(
            Locale.US,
            "Touchpad: gesture=%s, action=%s",
            formatGestureType(gesture),
            formatGestureAction(action)
        )
    }

    private fun getPayloadByte(payload: ByteArray?, index: Int): Int {
        if (payload == null || payload.size <= index) return 0xFF
        return payload[index].toInt() and 0xFF
    }

    private fun formatChargingState(value: Int): String = when (value) {
        0x00 -> "not charging"
        0x01 -> "charging"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatBatteryLevel(value: Int): String = when {
        value in 0..100 -> "$value%"
        value == 0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatSwitchState(value: Int): String = when (value) {
        0x00 -> "off"
        0x01 -> "on"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatShootingDirection(value: Int): String = when (value) {
        0x00 -> "normal"
        0x01 -> "rotate 90"
        0x02 -> "rotate 180"
        0x03 -> "rotate 270"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatRecordingDuration(value: Int): String = when {
        value < 0 || value == 0xFFFF -> "unknown"
        value == 0 -> "unlimited/default"
        else -> "${value}s"
    }

    private fun formatGestureType(value: Int): String = when (value) {
        0x00 -> "single click"
        0x01 -> "double click"
        0x02 -> "triple click"
        0x03 -> "long press"
        0x04 -> "swipe up"
        0x05 -> "swipe down"
        0x06 -> "swipe left"
        0x07 -> "swipe right"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }

    private fun formatGestureAction(value: Int): String = when (value) {
        0x00 -> "complete"
        0x01 -> "start"
        0x02 -> "continue"
        0x03 -> "end"
        0xFF -> "unknown"
        else -> String.format(Locale.US, "unknown(0x%02X)", value)
    }
}
