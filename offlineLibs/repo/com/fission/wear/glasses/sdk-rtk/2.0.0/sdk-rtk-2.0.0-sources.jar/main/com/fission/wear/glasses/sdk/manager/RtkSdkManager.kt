/**
 * @name RtkWifiDownloaadManager
 * @class name：com.fission.wear.glasses.sdk.manager
 * @author ly
 * @time 2026/4/27 10:58
 * @change
 * @chang time
 * @class describe
 */
package com.fission.wear.glasses.sdk.manager

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.SystemClock
import com.blankj.utilcode.util.FileUtils
import com.blankj.utilcode.util.LogUtils
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.data.model.LifePhotoConfig
import com.fission.wear.glasses.sdk.data.model.LiveStreamingConfig
import com.fission.wear.glasses.sdk.data.model.MediaDownloadProgressInfo
import com.fission.wear.glasses.sdk.data.model.WifiApConfig
import com.fission.wear.glasses.sdk.events.RtkSdkShareEvent
import com.fission.wear.glasses.sdk.live.LiveDisconnectMonitor
import com.fission.wear.glasses.sdk.live.LivePreviewCallback
import com.fission.wear.glasses.sdk.live.LiveStreamErrors
import com.fission.wear.glasses.sdk.rtk.RtkSmartWearWifiClientFactory
import com.fission.wear.glasses.sdk.rtk.RtkWifiConnectSession
import com.fission.wear.glasses.sdk.rtk.RtkWifiFeatureTags
import com.fission.wear.glasses.sdk.live.RtkLivePreviewController
import com.fission.wear.glasses.sdk.ota.rtk.RtkOtaManager
import com.fission.wear.glasses.sdk.rtk.protocol.CustomVendorProtocol
import com.fission.wear.glasses.sdk.rtk.protocol.RtkCustomProtocolDispatcher
import com.fission.wear.glasses.sdk.rtk.protocol.RtkCustomProtocolParser
import com.fission.wear.glasses.sdk.rtk.protocol.booleanToRtkCustomSwitch
import com.fission.wear.glasses.sdk.rtk.protocol.enableStateToRtkCustomSwitch
import com.fission.wear.glasses.sdk.rtk.protocol.intToUint16LeBytes
import com.fission.wear.glasses.sdk.rtk.protocol.toRtkCustomBrightness
import com.fission.wear.glasses.sdk.rtk.protocol.toRtkShootingDirection
import com.fission.wear.glasses.sdk.util.AudioFileUtils
import com.fission.wear.glasses.sdk.util.BlePacketUtils
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.fission.wear.glasses.sdk.util.GalleryDownloader
import com.fission.wear.glasses.sdk.util.RtkMediaExportQueue
import com.fission.wear.glasses.sdk.model.RtkMediaExportResult
import com.fission.wear.glasses.sdk.util.RtkMediaSyncCallback
import com.fission.wear.glasses.sdk.util.RtkMediaSyncManager
import com.realsil.sdk.audioconnect.smartwear.ActionStateNotification
import com.realsil.sdk.audioconnect.smartwear.FileStorageInfo
import com.realsil.sdk.audioconnect.smartwear.SmartWearConfig
import com.realsil.sdk.audioconnect.smartwear.SmartWearConstants
import com.realsil.sdk.audioconnect.smartwear.SmartWearDeviceInfo
import com.realsil.sdk.audioconnect.smartwear.SmartWearModelCallback
import com.realsil.sdk.audioconnect.smartwear.SmartWearModelClient
import com.realsil.sdk.audioconnect.smartwear.SmartWearModelProxy
import com.realsil.sdk.audioconnect.smartwear.WifiApInfo
import com.realsil.sdk.audioconnect.smartwear.WifiStaInfo
import com.realsil.sdk.audioconnect.smartwear.config.LifePhotoConfigInfo
import com.realsil.sdk.audioconnect.smartwear.config.LiveStreamingConfigInfo
import com.realsil.sdk.audioconnect.smartwear.config.LiveStreamingConfigInfo.VideoBitRateMode
import com.realsil.sdk.audioconnect.smartwear.config.LiveStreamingConfigInfo.VideoResolution
import com.realsil.sdk.audioconnect.smartwear.config.LiveStreamingConfigInfo.VideoRotation
import com.realsil.sdk.audioconnect.smartwear.config.WifiParamsConfigInfo
import com.realsil.sdk.audioconnect.smartwear.entity.DeviceCapacityInfo
import com.realsil.sdk.audioconnect.smartwear.entity.ThumbnailPhoto
import com.realsil.sdk.audioconnect.smartwear.entity.WifiAccessInfo
import com.realsil.sdk.audioconnect.smartwear.live.SessionConfig
import com.realsil.sdk.audioconnect.smartwear.live.net.NetworkConnector
import com.realsil.sdk.audioconnect.smartwear.live.view.RTKVideoView
import com.realsil.sdk.bbpro.BeeProParams
import com.realsil.sdk.bbpro.BumblebeeCallback
import com.realsil.sdk.bbpro.MultiPeripheralConnectionManager
import com.realsil.sdk.bbpro.PeripheralConnectionManager
import com.realsil.sdk.bbpro.authentication.AuthenticationState
import com.realsil.sdk.bbpro.core.BeeError
import com.realsil.sdk.bbpro.core.gatt.GattTransportConnParams
import com.realsil.sdk.bbpro.core.peripheral.ConnectionParameters
import com.realsil.sdk.bbpro.core.peripheral.Peripheral
import com.realsil.sdk.bbpro.core.peripheral.PeripheralParameters
import com.realsil.sdk.bbpro.core.spp.SppTransportConnParams
import com.realsil.sdk.bbpro.core.transportlayer.AckPacket
import com.realsil.sdk.bbpro.core.transportlayer.Command
import com.realsil.sdk.bbpro.core.transportlayer.TransportLayerPacket
import com.realsil.sdk.bbpro.model.DeviceInfo
import com.realsil.sdk.bbpro.model.KeyMmiSettings
import com.realsil.sdk.bbpro.multilink.MultiLinkInfo
import com.realsil.sdk.bbpro.vendor.VendorModelCallback
import com.realsil.sdk.core.RtkConfigure
import com.realsil.sdk.core.RtkCore
import com.realsil.sdk.core.bluetooth.compat.BluetoothDeviceCompat
import com.realsil.sdk.core.bluetooth.connection.le.GattConnParams
import com.realsil.sdk.core.logger.ZLogger
import com.realsil.sdk.dfu.RtkDfu
import com.realtek.sdk.core.net.RtkNetworkUtils
import com.realtek.sdk.core.net.wifi.RtkWifiAdapter
import com.realtek.sdk.core.net.wifi.SoftApConfigurationCompat
import com.realtek.sdk.core.net.wifi.WifiConnectParameter
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference

class RtkSdkManager(
    private val mContext: Context,
    private val mScope: CoroutineScope,
    private val sdkConfig: SdkConfig,
) {
    private val TAG: String = "RtkSdkManager"
    private var wifiSsid: String = "AI_GLASS_AP"
    private var wifiPassword: String = "rtkglass"
    private var ipAddress: String = "192.168.43.1"
    private var liveRtspUrl: String = ""
    private var mSmartWearModelClient: SmartWearModelClient? = null
    private var wifiConnected = false
    private val _rtkEvent: MutableSharedFlow<RtkSdkShareEvent> =
        MutableSharedFlow(extraBufferCapacity = 64)
    val rtkEvent: SharedFlow<RtkSdkShareEvent> = _rtkEvent.asSharedFlow()
    private val pendingMediaConfigAck = AtomicReference<PendingMediaConfigAck?>(null)
    private var wifiAdapter: RtkWifiAdapter = RtkWifiAdapter(mContext)
    /** 媒体同步 connectWiFi 时 ping-pong 专用（下载由 [GalleryDownloader] 内部独立 client 负责）。 */
    private lateinit var syncWifiSession: RtkWifiConnectSession
    /** OTA SoftAP 推包专用。 */
    private lateinit var otaWifiSession: RtkWifiConnectSession
    /** 直播 Wi‑Fi 会话（预留独立 client，避免与同步/OTA 串扰）。 */
    private lateinit var liveWifiSession: RtkWifiConnectSession
    private var galleryDownloader: GalleryDownloader? = null
    private var mediaExportQueue: RtkMediaExportQueue? = null
    private var mediaSyncManager: RtkMediaSyncManager? = null
    private val mediaSyncCallback = object : RtkMediaSyncCallback {
        override fun onConnectSuccess() {
            sendEvent(RtkSdkShareEvent.OnSyncConnectSuccess)
        }

        override fun onDownloadPrepared(totalFileCount: Int, progressInfo: MediaDownloadProgressInfo) {
            downloadProgressInfo.init(totalFileCount)
            sendEvent(
                RtkSdkShareEvent.OnSyncFileProgress(
                    downloadProgressInfo.downloadProgress,
                    downloadProgressInfo.downloadIndex,
                    downloadProgressInfo.totalFileCount,
                    "",
                ),
            )
        }

        override fun onDownloadProgress(progressInfo: MediaDownloadProgressInfo) {
            downloadProgressInfo.downloadProgress = progressInfo.downloadProgress
            downloadProgressInfo.downloadIndex = progressInfo.downloadIndex
            downloadProgressInfo.totalFileCount = progressInfo.totalFileCount
            sendEvent(
                RtkSdkShareEvent.OnSyncFileProgress(
                    downloadProgressInfo.downloadProgress,
                    downloadProgressInfo.downloadIndex,
                    downloadProgressInfo.totalFileCount,
                    "",
                ),
            )
        }

        override fun onFileExported(result: RtkMediaExportResult, totalFileCount: Int) {
            sendEvent(
                RtkSdkShareEvent.OnSyncFileSuccess(
                    result.exportFile.absolutePath,
                    result.fileIndex,
                    totalFileCount,
                    "",
                    result.exportFile.length(),
                    "",
                ),
            )
        }

        override fun onWifiDisconnectedDuringSync() {
            FissionLogUtils.w(TAG, "WiFi disconnected during download phase, continue export for queued items")
        }

        override fun onSyncFailed(code: Int, reason: String) {
            sendEvent(RtkSdkShareEvent.OnSyncFileFail(code, reason))
        }

        override fun onSyncFinished(successCount: Int, totalFileCount: Int) {
            sendEvent(
                RtkSdkShareEvent.OnSyncBatchDownloadFinished(
                    successCount = successCount,
                    totalFileCount = totalFileCount,
                ),
            )
        }
    }
    private var downloadProgressInfo = MediaDownloadProgressInfo()
    private var mediaFolderDir: String = ""
    private val GALLERY_FOLDER_NAME = "gallery"
    private val wifiApStateLock = Any()
    private var wifiApStateChangedDeferred: CompletableDeferred<WifiApInfo>? = null
    private var lastWifiApStateChangedAt = 0L
    private var lastWifiApInfo: WifiApInfo? = null
    private var isSmartWearReady = false
    private val smartWearInitLock = Any()
    private val smartWearClientLock = Any()
    private var smartWearInitDeferred: CompletableDeferred<Boolean>? = null
    private var lastSmartWearInitSuccessAt = 0L
    private var mConnectionManager: PeripheralConnectionManager? = null
    /** startConnect 发起后、DATA_PREPARED 前的本地连接中标记，避免上层重复 connect。 */
    private var isDeviceConnecting = false
    private var mDeviceAddress: String = ""
    private val WIFI_AP_ENABLE_TIMEOUT_MS = 30 * 1000L
    private val WIFI_AP_ENABLE_MAX_RETRIES = 1
    private val WIFI_AP_RETRY_DELAY_MS = 3_000L
    private val WIFI_AP_JOIN_MAX_RETRIES = 3
    /** 设备可能在短时间内对同一 AP 状态重复回调，做去重避免 enableAp 等待与上层事件重复。 */
    private val WIFI_AP_STATE_DEDUP_MS = 200L
    /** RTK step3 读 SmartWearDeviceInfo.getWifiApInfo()，须等 SDK 写入后再 startLiveStreaming */
    private val SMART_WEAR_WIFI_AP_INFO_POLL_MS = 100L
    private val SMART_WEAR_WIFI_AP_INFO_POLL_COUNT = 50
    private var lastWifiApStateFingerprint: String? = null
    private var lastWifiApStateCallbackAt = 0L
    /** 设备可能在短时间内多次回调 onStartReceiveUserVoice，做 leading-edge 防抖。 */
    private val START_RECEIVE_USER_VOICE_DEBOUNCE_MS = 50L
    private var lastStartReceiveUserVoiceAt = 0L
    private val WIFI_AP_JOIN_RETRY_DELAY_MS = 2_000L
    private val WIFI_AP_JOIN_SPECIFIER_TIMEOUT_MS = 25_000L
    private val SMART_WEAR_INIT_TIMEOUT_MS = 30 * 1000L
    /** SmartWear init 失败后最多重试次数（不含首次）。 */
    private val MAX_SMART_WEAR_INIT_RETRY = 3
    private val SMART_WEAR_INIT_RETRY_DELAY_MS = 1_500L
    private var smartWearInitRetryCount = 0
    private var smartWearInitRetryJob: Job? = null
    private var mLiveStreamingConfigInfo: LiveStreamingConfigInfo? = null
    private var mLiveStreamingConfig: LiveStreamingConfig? = null
    private lateinit var rtkOtaManager: RtkOtaManager
    private lateinit var livePreviewController: RtkLivePreviewController
    private lateinit var liveDisconnectMonitor: LiveDisconnectMonitor
    private var isLiveSessionActive = false
    /** 已调用 startPushLiveStreaming，RTMP 推流阶段 */
    private var isLivePushActive = false
    private var liveDisconnectNotified = false
    /** 通知栏关播清理中：抑制 stopLiveStreaming 触发的 AP 关闭误报 [LiveDisconnected]。 */
    private var liveStoppingByNotification = false
    private var customProtocolCallbackRegistered = false

    private val customProtocolBumblebeeCallback = object : BumblebeeCallback() {
        override fun onAckReceived(peripheral: Peripheral, packet: AckPacket) {
            val commandId = packet.toAckId
            if (!CustomVendorProtocol.isCustomCommand(commandId)) return
            FissionLogUtils.d(
                TAG,
                "custom ACK cmd=0x${commandId.toString(16)} status=${packet.status}",
            )
            sendEvent(
                RtkSdkShareEvent.CustomProtocolCommandResult(
                    commandId = commandId,
                    success = packet.status == AckPacket.ACK_STATUS_COMPLETE,
                    errorCode = packet.status.toInt() and 0xFF,
                ),
            )
        }

        override fun onDataReceived(peripheral: Peripheral, packet: TransportLayerPacket) {
            val eventId = packet.opcode
            if (!CustomVendorProtocol.isCustomEvent(eventId)) return
            val payload = packet.parameters
            FissionLogUtils.d(
                TAG,
                "custom EVENT id=0x${eventId.toString(16)} len=${payload?.size ?: 0} " +
                    RtkCustomProtocolParser.buildEventSummary(eventId, payload),
            )
            RtkCustomProtocolDispatcher.dispatchEvent(eventId, payload) { event ->
                if (event is RtkSdkShareEvent.CustomProtocolWifiApStatusChanged) {
                    handleCustomWifiApStatusChanged(event.enabled)
                }
                sendEvent(event)
            }
        }
    }

    private val wifiAdapterCallback = object :
        RtkWifiAdapter.WiFiAdapterCallback() {
        override fun onWifiConnectionStateChanged(connected: Boolean) {
            super.onWifiConnectionStateChanged(connected)
            LogUtils.d(TAG,"onWifiConnectionStateChanged: $connected")
            wifiConnected = connected
            if (!connected) {
                mediaSyncManager?.onWifiConnectionStateChanged(false) {
                    wifiAdapter.isSpecificWifiConnected(wifiSsid)
                }
            }
        }

        override fun onSoftApStarted(softApConfiguration: SoftApConfigurationCompat) {
            super.onSoftApStarted(softApConfiguration)
            LogUtils.d(TAG,"onSoftApStarted:$softApConfiguration")
            mScope.launch(Dispatchers.Main) {
                mLiveStreamingConfigInfo?.let {
                    val wifiApInfo = WifiApInfo.Builder()
                            .ssid(softApConfiguration.ssid)
                            .password(softApConfiguration.password)
                            .build()

                    it.liveStreamingChannel = LiveStreamingConfigInfo.LiveStreamingChannel.WIFI_STATION

                    it.wifiApInfo = wifiApInfo

                    getSmartWearModelClient()?.liveStreamingManager?.startLiveStreaming(it)
                }
            }
        }

        override fun onSoftApFailed(reason: Int) {
            super.onSoftApFailed(reason)
            LogUtils.d(TAG,"打开Wifi 失败:$reason")
            if (isLiveSessionActive) {
                abortLiveStreamingStart(LiveStreamErrors.CODE_HOTSPOT_START_FAILED)
            } else {
                sendEvent(
                    RtkSdkShareEvent.RespFailed(
                        LiveStreamErrors.defaultReason(LiveStreamErrors.CODE_HOTSPOT_START_FAILED),
                        LiveStreamErrors.CODE_HOTSPOT_START_FAILED,
                    ),
                )
            }
        }

        override fun onSoftApStopped() {
            super.onSoftApStopped()
            LogUtils.d(TAG,"onSoftApStopped")
            if (isLiveSessionActive) {
                notifyLiveDisconnected(
                    LiveDisconnectMonitor.REASON_GLASSES_AP_CLOSED,
                    GlassesConstant.ERROR_CODE_LIVE_GLASSES_AP_CLOSED,
                )
            } else {
                sendEvent(RtkSdkShareEvent.RespStop)
            }
        }
    }

    private var nextTime = 0L
    private val mAIGlassModelCallback: SmartWearModelCallback =
        object : SmartWearModelCallback() {

            override fun onSmartWearDeviceInitSuccess() {
                FissionLogUtils.d(TAG, "rtk----onSmartWearDeviceInitSuccess")
                cancelSmartWearInitRetry()
                isSmartWearReady = true
                lastSmartWearInitSuccessAt = SystemClock.elapsedRealtime()
                synchronized(smartWearInitLock) {
                    smartWearInitDeferred?.complete(true)
                }
                // 与瑞昱 Demo MainActivity.updateInitState 一致：init 成功后拉取 bud 信息
                getSmartWearModelClient()?.budInfo
                sendEvent(RtkSdkShareEvent.OnSmartWearDeviceInitSuccess)
            }

            override fun onSmartWearDeviceInitFail() {
                FissionLogUtils.e(TAG, "rtk----onSmartWearDeviceInitFail")
                isSmartWearReady = false
                smartWearInitRetryCount++
                if (smartWearInitRetryCount <= MAX_SMART_WEAR_INIT_RETRY &&
                    getPeripheralConnectionManager().isConnected
                ) {
                    FissionLogUtils.w(
                        TAG,
                        "onSmartWearDeviceInitFail: retry $smartWearInitRetryCount/$MAX_SMART_WEAR_INIT_RETRY",
                    )
                    scheduleSmartWearInitRetry()
                    return
                }
                handleSmartWearInitExhausted()
            }

            override fun onFileStorageInfoChanged(fileStorageInfo: FileStorageInfo) {
                super.onFileStorageInfoChanged(fileStorageInfo)
                FissionLogUtils.d(
                    TAG,
                    "onFileStorageInfoChanged: ${fileStorageInfo.toString()}",
                )
                sendEvent(RtkSdkShareEvent.OnFileStorageInfoChanged(fileStorageInfo))
            }

            override fun onReceivedDeviceCapacityInfo(deviceRole: Int, capacityInfo: DeviceCapacityInfo) {
                super.onReceivedDeviceCapacityInfo(deviceRole, capacityInfo)
                 if (deviceRole.toByte() == SmartWearConstants.DEVICE_ROLE_SINGLE) {
                           val usedSizeKB = capacityInfo.usedSize
                           val totalSizeKB = capacityInfo.totalSize
                         }
            }

            override fun onReceivedDeviceBatteryInfo(primaryBattery: Int, secondaryBattery: Int) {
                super.onReceivedDeviceBatteryInfo(primaryBattery, secondaryBattery)
                // 充电状态以自定义协议 0x0801 为准，此处仅补充电量
                sendEvent(RtkSdkShareEvent.DevicePower(primaryBattery, null))
            }

            override fun onWifiApStateChanged(wifiApInfo: WifiApInfo) {
                super.onWifiApStateChanged(wifiApInfo)
                val fingerprint =
                    "${wifiApInfo.isOk}|${wifiApInfo.mode}|${wifiApInfo.ssid.orEmpty()}|${wifiApInfo.password.orEmpty()}"
                val now = SystemClock.elapsedRealtime()
                if (fingerprint == lastWifiApStateFingerprint &&
                    now - lastWifiApStateCallbackAt < WIFI_AP_STATE_DEDUP_MS
                ) {
                    FissionLogUtils.d(TAG, "onWifiApStateChanged deduped: ssid=${wifiApInfo.ssid}")
                    return
                }
                lastWifiApStateFingerprint = fingerprint
                lastWifiApStateCallbackAt = now
                FissionLogUtils.d(
                    TAG,
                    "rtk----wifiApInfo: ssid=${wifiApInfo.ssid} isOk=${wifiApInfo.isOk} mode=${wifiApInfo.mode}",
                )
                if (wifiApInfo.isOk && !wifiApInfo.ssid.isNullOrBlank()) {
                    wifiSsid = wifiApInfo.ssid
                    wifiPassword = wifiApInfo.password
                }
                synchronized(wifiApStateLock) {
                    lastWifiApStateChangedAt = SystemClock.elapsedRealtime()
                    lastWifiApInfo = wifiApInfo
                    // 空 SSID / 失败态常见于 AP 关闭过程，不能当作 enableAp 完成
                    if (wifiApInfo.isOk && !wifiApInfo.ssid.isNullOrBlank()) {
                        wifiApStateChangedDeferred?.complete(wifiApInfo)
                    }
                }
                sendEvent(RtkSdkShareEvent.OnWifiApStateChanged(wifiApInfo))
                if (isLiveSessionActive &&
                    liveRtspUrl.isNotBlank() &&
                    (!wifiApInfo.isOk || wifiApInfo.ssid.isNullOrBlank())
                ) {
                    notifyLiveDisconnected(
                        LiveDisconnectMonitor.REASON_GLASSES_AP_CLOSED,
                        GlassesConstant.ERROR_CODE_LIVE_GLASSES_AP_CLOSED,
                    )
                }
            }

            override fun onWifiStaStateChanged(wifiStaInfo: WifiStaInfo) {
                super.onWifiStaStateChanged(wifiStaInfo)
                sendEvent(RtkSdkShareEvent.OnWifiStaStateChanged(wifiStaInfo))
                FissionLogUtils.d(
                    TAG,
                    String.format(
                        Locale.US,
                        "rtk----onWifiStaStateChanged：syncState.state=%d,bud=%d, ipAddress=%s",
                        wifiStaInfo.bud,
                        wifiStaInfo.ipAddress
                    )
                )
            }

            override fun onStartReceiveUserVoice() {
                val now = SystemClock.elapsedRealtime()
                nextTime = now
                if (now - lastStartReceiveUserVoiceAt < START_RECEIVE_USER_VOICE_DEBOUNCE_MS) {
                    FissionLogUtils.d(
                        TAG,
                        "onStartReceiveUserVoice debounced, interval=${now - lastStartReceiveUserVoiceAt}ms",
                    )
                    return
                }
                lastStartReceiveUserVoiceAt = now
                sendEvent(RtkSdkShareEvent.OnStartReceiveUserVoice)
                val filePath =
                    "${mContext.externalCacheDir}/${System.currentTimeMillis()}.pcm"  // 创建文件路径
                AudioFileUtils.createFile(filePath)  // 创建文件并获取文件输出流
                FissionLogUtils.d(TAG, "onStartReceiveUserVoice: $filePath")
            }

            override fun onReceivedUserVoice(voiceData: ByteArray) {
//                LogUtils.d(TAG, "onReceivedUserVoice:-> (${BlePacketUtils.bytesToHex(voiceData).length}) -- ${BlePacketUtils.bytesToHex(voiceData)}")
                val now = SystemClock.elapsedRealtime()
                if (now-nextTime > 100){
                    LogUtils.d(TAG, "onReceivedUserVoice:-> (${BlePacketUtils.bytesToHex(voiceData).length})  -- ${now-nextTime}")
                }
                nextTime = now
                AudioFileUtils.writeDataToFile(voiceData)
                sendEvent(RtkSdkShareEvent.OnReceivedUserVoice(voiceData))
            }

            override fun onStopReceiveUserVoice() {
                lastStartReceiveUserVoiceAt = 0L
                FissionLogUtils.d(TAG, "onStopReceiveUserVoice 收到停止录音")
                AudioFileUtils.stopRecording()
                sendEvent(RtkSdkShareEvent.OnStopReceiveUserVoice)
            }

            override fun onTakePhotoSuccess(imgFiles: MutableList<ThumbnailPhoto>) {
                sendEvent(RtkSdkShareEvent.OnTakePhotoSuccess(imgFiles))
//                if (imgFiles.isNotEmpty()) {
//                    aiImageRecognition(imgFiles[0].photoFile.absolutePath, mcpMsg!!)
//
//                    emitEvent(
//                        AiAssistantEvent.AiAssistantResult(
//                            AiChatMessageDTO(
//                                question = imgFiles[0].photoFile.absolutePath,
//                                questionType = AiContentType.IMAGE_PATH,
//                                isFinished = true
//                            )
//                        )
//                    )
//                }


            }

            override fun onDeviceTriggeredTakePhoto() {
                sendEvent(RtkSdkShareEvent.OnDeviceTriggeredTakePhoto)
            }


            override fun onTakePhotoFail(errorCode: Int) {
                FissionLogUtils.d("clx", "onTakePhotoFail:$errorCode")
                sendEvent(RtkSdkShareEvent.OnTakePhotoFail(errorCode))
//                emitEvent(CmdResultEvent.Fail("图片保存或AI识别异常", ERROR_CODE_IMAGE_SAVE))
            }

            override fun onStartLiveStreaming(
                liveChannel: Byte,
                startResult: Boolean,
                wifiAccessInfo: WifiAccessInfo?,
            ) {
                FissionLogUtils.d(
                    TAG,
                    "onStartLiveStreaming channel=$liveChannel success=$startResult wifiAccessInfo=${wifiAccessInfo.toString()}",
                )
                if (!startResult) {
                    handleLiveStreamingStartFailed()
                    return
                }
                // 对齐 DebugLiveStreamingActivity.mSmartWearModelCallback（仅 WIFI AP）：
                // 眼镜 AP/RTSP/WiFi 就绪后，再启动手机侧 RTKMediaPlayerService。
                if (liveChannel != LiveStreamingConfigInfo.LiveStreamingChannel.WIFI_AP) {
                    abortLiveStreamingStart(LiveStreamErrors.CODE_GLASSES_START_FAILED)
                    FissionLogUtils.w(TAG, "Only WIFI_AP live mode is supported, channel=$liveChannel")
                    return
                }
                liveRtspUrl = "rtsp://${ipAddress}:554"
                sendEvent(RtkSdkShareEvent.RespSuccess(liveRtspUrl))
                // RTK SDK 第 3 步（NetworkConnector.connectToWifi）完成后才回调此处；
                // 断连监测须在 WiFi 已连上后再启动，避免与系统连热点请求冲突。
                startLiveDisconnectMonitorIfNeeded()
                startLiveStreamingOnWifiApMode()
            }

            override fun onReceivedLiveStreamingData(p0: ByteArray) {
                super.onReceivedLiveStreamingData(p0)
                sendEvent(RtkSdkShareEvent.OnReceivedLiveStreamingData(p0))
            }

            override fun onActionStateNotificationChanged(p0: ActionStateNotification) {
                super.onActionStateNotificationChanged(p0)
                sendEvent(RtkSdkShareEvent.OnActionStateNotificationChanged(p0))
            }

            override fun onStateChanged(p0: Int) {
                super.onStateChanged(p0)
                sendEvent(RtkSdkShareEvent.OnStateChanged(p0))
            }

            override fun onFwVersionChanged(p0: Int) {
                super.onFwVersionChanged(p0)
                LogUtils.d("onFwVersionChanged","$p0")
            }

            override fun onModelClientRegistered() {
                super.onModelClientRegistered()
            }

            override fun onOperationComplete(p0: Int, p1: Byte) {
                super.onOperationComplete(p0, p1)
                LogUtils.d("onOperationComplete","$p0 , $p1")
            }

            override fun onReceivedDeviceAction(p0: Int) {
                super.onReceivedDeviceAction(p0)
                LogUtils.d("onReceivedDeviceAction","$p0")
            }

            override fun onUpdateWifiInfo(p0: Boolean) {
                super.onUpdateWifiInfo(p0)
                LogUtils.d("onUpdateWifiInfo", "$p0")
                // setLifePhotoConfigInfo / setWifiParamsConfigInfo 共用此 ACK
                when (pendingMediaConfigAck.getAndSet(null)) {
                    PendingMediaConfigAck.LIFE_PHOTO ->
                        sendEvent(RtkSdkShareEvent.OnLifePhotoConfigResult(p0))
                    PendingMediaConfigAck.WIFI_AP ->
                        sendEvent(RtkSdkShareEvent.OnWifiApConfigResult(p0))
                    null -> Unit
                }
            }

            override fun onSetGpsInfo(p0: Boolean) {
                super.onSetGpsInfo(p0)
                LogUtils.d("onSetGpsInfo","$p0")
            }
        }

    private val innerVendorModelCallback = object : VendorModelCallback() {

        override fun onMultiLinkInfoChanged(multilinkInfo: MultiLinkInfo) {
            LogUtils.i("onMultiLinkInfoChanged","-----> ${multilinkInfo.toString()}")
        }

        override fun onDeviceInfoChanged(indicator: Int, deviceInfo: DeviceInfo) {
//            LogUtils.i("onDeviceInfoChanged","-----> $indicator , ${deviceInfo.toString()}")
        }

        override fun onOperationComplete(operation: Int, status: Byte) {
        }

        override fun onStateChanged(state: Int) {
            LogUtils.d(TAG, "onStateChanged-> $state  (261-连接中，260-断开连接 262-断连中 263-已连接 264-成功 513-同步数据)")
            when (state) {
                PeripheralConnectionManager.STATE_DEVICE_CONNECTING    -> {
                    isDeviceConnecting = true
                    sendEvent(RtkSdkShareEvent.Connecting)
                }

                PeripheralConnectionManager.STATE_DATA_PREPARED        -> {//数据
                    isDeviceConnecting = false
                    // 连接就绪后强制确保自定义协议回调在位（SDK 重连可能清掉 callback 列表）
                    customProtocolCallbackRegistered = false
                    ensureCustomProtocolCallback()
                    configAudioFormat()//配置AI音频流格式
                    getSmartWearModelClient()
                    scheduleInitSmartWearDevice()
                    sendEvent(RtkSdkShareEvent.Connected(null, false))
                }
                PeripheralConnectionManager.STATE_DEVICE_DISCONNECTING,PeripheralConnectionManager.STATE_DEVICE_DISCONNECTED  -> {
                    isDeviceConnecting = false
                    if (mediaSyncManager?.isSyncActive == true) {
                        stopMediaSyncProcedure()
                    }
                    if (isLiveSessionActive) {
                        notifyLiveDisconnected(
                            LiveDisconnectMonitor.REASON_GLASSES_DISCONNECTED,
                            GlassesConstant.ERROR_CODE_LIVE_GLASSES_DISCONNECTED,
                        )
                    }
                    resetSmartWearModelClient()
                    sendEvent(RtkSdkShareEvent.Disconnected)
                }
            }
        }

        override fun onAuthenticationStateChanged(state: AuthenticationState) {

        }

        override fun onKeyeventReported(p0: Int) {
            super.onKeyeventReported(p0)
            LogUtils.i("onKeyeventReported","-----> $p0")
        }

        override fun onKeyMapSettingsReported(p0: List<KeyMmiSettings?>?) {
            super.onKeyMapSettingsReported(p0)
            LogUtils.i("onKeyMapSettingsReported","-----> ${p0.toString()}")
        }

    }

    init {
        val configure = RtkConfigure.Builder()
                .debugEnabled(true)
                .printLog(true)
                .globalLogLevel(ZLogger.INFO)
                .logTag("AudioConnect")
                .devModeEnabled(true)
                .dumpData(true)
                .build()

        RtkDfu.initialize(mContext, true)
        RtkCore.initialize(mContext, configure)


        wifiAdapter = RtkWifiAdapter(mContext)
        wifiAdapter.registerWiFiAdapterCallback(wifiAdapterCallback)

        val builder = BeeProParams.Builder()
                .syncDataWhenConnected(true)
                .connectA2dp(true)
                .listenHfp(true)
        val initResult = MultiPeripheralConnectionManager.getInstance(mContext)
                .initialize(builder.build())
        FissionLogUtils.d("sdk 初始化：$initResult")
        syncWifiSession = RtkWifiConnectSession(
            RtkWifiFeatureTags.SYNC,
            RtkSmartWearWifiClientFactory.create(mContext, ipAddress),
        )
        otaWifiSession = RtkWifiConnectSession(
            RtkWifiFeatureTags.OTA,
            RtkSmartWearWifiClientFactory.create(mContext, ipAddress),
        )
        liveWifiSession = RtkWifiConnectSession(
            RtkWifiFeatureTags.LIVE,
            RtkSmartWearWifiClientFactory.create(mContext, ipAddress),
        )

        this.mediaFolderDir = mContext.getExternalFilesDir(null)
                                      .toString() + "/${GALLERY_FOLDER_NAME}"
        val originalPictureDir =
            "$mediaFolderDir/${GalleryDownloader.SUBDIR_ORIGINAL}"
        val correctedPictureDir =
            "$mediaFolderDir/${GalleryDownloader.SUBDIR_CORRECTED}"
        FileUtils.createOrExistsDir(mediaFolderDir)
        FileUtils.createOrExistsDir(originalPictureDir)
        FileUtils.createOrExistsDir(correctedPictureDir)
        FissionLogUtils.d(
            TAG,
            "sync media dirs: original=$originalPictureDir, corrected=$correctedPictureDir"
        )

        galleryDownloader = GalleryDownloader(
            mContext,
            pictureDir = mediaFolderDir,
            videoDir = mediaFolderDir,
            originalPictureDir = originalPictureDir,
            correctedPictureDir = correctedPictureDir,
            ipAddress = ipAddress,
        )
        mediaExportQueue = RtkMediaExportQueue(
            mContext,
            correctedPictureDir = correctedPictureDir,
        )
        mediaSyncManager = RtkMediaSyncManager(
            scope = mScope,
            downloader = galleryDownloader!!,
            exportQueue = mediaExportQueue!!,
            callback = mediaSyncCallback,
        )

        rtkOtaManager = RtkOtaManager(
            appContext = mContext,
            getDeviceAddress = { mDeviceAddress },
            getSmartWearModelClient = { getSmartWearModelClient() },
            getSmartApClient = { otaWifiSession.pingClient },
            wifiAdapter = wifiAdapter,
            getWifiSsid = { wifiSsid },
            enableAp = { enableApWithRetry() },
            connectWiFi = { connectWiFi(otaWifiSession) },
            recoverNetworkHandle = { disconnectGlassesAp, stopGlassesSoftAp ->
                recoverNetworkHandle(disconnectGlassesAp, stopGlassesSoftAp)
            },
            sendEvent = { sendEvent(it) }
        )
        livePreviewController = RtkLivePreviewController(mContext)
        liveDisconnectMonitor = LiveDisconnectMonitor(
            appContext = mContext,
            shouldMonitorApLink = { isLiveSessionActive && liveRtspUrl.isNotBlank() },
            onPhoneWifiDisabled = {
                notifyLiveDisconnected(
                    LiveDisconnectMonitor.REASON_PHONE_WIFI_OFF,
                    GlassesConstant.ERROR_CODE_LIVE_PHONE_WIFI_OFF,
                )
            },
            onGlassesApLinkLost = {
                notifyLiveDisconnected(
                    LiveDisconnectMonitor.REASON_GLASSES_AP_LINK_LOST,
                    GlassesConstant.ERROR_CODE_LIVE_GLASSES_AP_LINK_LOST,
                )
            },
        )
        livePreviewController.setPreviewCallback(object : LivePreviewCallback {
            override fun onPreviewStarted() {
                sendEvent(RtkSdkShareEvent.PreviewStarted)
            }

            override fun onPreviewFailed(errorCode: Int) {
                if (isInLivePushPhase()) {
                    notifyLiveDisconnected(
                        LiveDisconnectMonitor.REASON_LIVE_INTERRUPTED,
                        GlassesConstant.ERROR_CODE_LIVE_INTERRUPTED,
                    )
                } else {
                    stopLiveStreamingBestEffort()
                    clearLiveSessionState()
                    sendEvent(
                        RtkSdkShareEvent.PreviewFailed(
                            LiveStreamErrors.previewStartFailedReason(errorCode),
                            LiveStreamErrors.CODE_PREVIEW_START_FAILED,
                        ),
                    )
                }
            }

            override fun onLiveStoppedByNotification() {
                handleLiveStoppedByNotification()
            }
        })
    }

    /**
     * 配置AI对话音频流格式
     */
    private fun configAudioFormat(){
        val smartWearConfig =  SmartWearConfig.Builder()
                .setOutputAudioSampleRate(SmartWearConstants.AudioSampleRate.SAMPLE_RATE_16000)
                .setOutputAudioSampleChannel(SmartWearConstants.AudioChannel.CHANNEL_MONO)
                .build()
        getSmartWearModelClient()?.setSmartWearDeviceParam(smartWearConfig)
    }


    private fun getSmartWearModelClient(): SmartWearModelClient? {
        synchronized(smartWearClientLock) {
            if (mDeviceAddress.isEmpty()) return null
            if (mSmartWearModelClient == null) {
                val client = SmartWearModelProxy.getInstance().getModelClient(mDeviceAddress)
                // 避免并发 getModelClient 时重复 register，同一 listener 被回调两次
                client.unregisterCallback(mAIGlassModelCallback)
                client.registerCallback(mAIGlassModelCallback)
                mSmartWearModelClient = client
                // 与瑞昱 Demo 一致：自定义协议回调挂在 SmartWear 的 ConnectionManager 上
                mConnectionManager = client.connectionManager as? PeripheralConnectionManager
                    ?: mConnectionManager
                customProtocolCallbackRegistered = false
                ensureCustomProtocolCallback()
            }
            return mSmartWearModelClient
        }
    }

    /** RTK SDK 的 initSmartWearDevice 必须在主线程调用（内部会创建 Handler）。 */
    private fun scheduleInitSmartWearDevice() {
        mScope.launch(Dispatchers.Main.immediate) {
            getSmartWearModelClient()?.initSmartWearDevice()
        }
    }

    /** 断开/重连时丢弃陈旧 SmartWear client，避免 init 回调丢失。 */
    private fun resetSmartWearModelClient() {
        synchronized(smartWearClientLock) {
            cancelSmartWearInitRetry()
            pendingMediaConfigAck.set(null)
            mSmartWearModelClient?.unregisterCallback(mAIGlassModelCallback)
            mSmartWearModelClient = null
            isSmartWearReady = false
            lastSmartWearInitSuccessAt = 0L
            lastWifiApStateFingerprint = null
            lastWifiApStateCallbackAt = 0L
            synchronized(smartWearInitLock) {
                smartWearInitDeferred?.complete(false)
                smartWearInitDeferred = null
            }
        }
    }

    private fun scheduleSmartWearInitRetry() {
        smartWearInitRetryJob?.cancel()
        smartWearInitRetryJob = mScope.launch {
            delay(SMART_WEAR_INIT_RETRY_DELAY_MS)
            if (!getPeripheralConnectionManager().isConnected) {
                FissionLogUtils.w(TAG, "scheduleSmartWearInitRetry: device disconnected, abort retry")
                cancelSmartWearInitRetry()
                synchronized(smartWearInitLock) {
                    smartWearInitDeferred?.complete(false)
                }
                return@launch
            }
            scheduleInitSmartWearDevice()
        }
    }

    private fun cancelSmartWearInitRetry() {
        smartWearInitRetryJob?.cancel()
        smartWearInitRetryJob = null
        smartWearInitRetryCount = 0
    }

    /** SmartWear init 重试用尽：通知上层断开并释放陈旧 SPP 连接。 */
    private fun handleSmartWearInitExhausted() {
        cancelSmartWearInitRetry()
        synchronized(smartWearInitLock) {
            smartWearInitDeferred?.complete(false)
        }
        sendEvent(RtkSdkShareEvent.OnSmartWearDeviceInitFail)
        if (getPeripheralConnectionManager().isConnected) {
            disConnect()
        }
    }

    private suspend fun initSmartWearDeviceOnMain() {
        withContext(Dispatchers.Main.immediate) {
            getSmartWearModelClient()?.initSmartWearDevice()
        }
    }

    /**
     * connect remote device
     * */
    fun connectDevice(address: String?, forceSmartWearReinit: Boolean = false) {
        if (address.isNullOrBlank()) {
            return
        }
        if (isDeviceConnectionInProgress()) {
            if (address.equals(mDeviceAddress, ignoreCase = true)) {
                FissionLogUtils.d(
                    TAG,
                    "connectDevice skipped: connection already in progress for $address",
                )
            } else {
                FissionLogUtils.w(
                    TAG,
                    "connectDevice skipped: connecting to $mDeviceAddress, ignore $address",
                )
            }
            return
        }
        cancelSmartWearInitRetry()
        mDeviceAddress = address
        SmartWearModelProxy.initialize(mContext)

        if (getPeripheralConnectionManager().isConnected) {
            FissionLogUtils.d(TAG, "Tips: Device has connected currently")
            if (forceSmartWearReinit || !isSmartWearReady) {
                resetSmartWearModelClient()
            }
            getSmartWearModelClient()
            scheduleInitSmartWearDevice()
            return
        }

        val params = ConnectionParameters.Builder(mDeviceAddress)
                .channelType(ConnectionParameters.CHANNEL_TYPE_SPP)
                .gattTransportConnParams(
                    GattTransportConnParams.Builder(mDeviceAddress)
                            .connParams(
                                GattConnParams.Builder().address(mDeviceAddress)
                                        .createBond(true, BluetoothDeviceCompat.TRANSPORT_BREDR)
                                        .transport(GattConnParams.TRANSPORT_LE)
                                        .a2dp(true)
                                        .hfp(true)
                                        .ignoreEnableNotificationResponse(true)
                                        .build()
                            )
                            .build()
                )
                .sppTransportConnParams(
                    SppTransportConnParams.Builder(mDeviceAddress)
                            .createBond(true, BluetoothDeviceCompat.TRANSPORT_BREDR)
                            .build()
                )
                .peripheralParameters(
                    PeripheralParameters.Builder()
                            .syncDataWhenConnected(true)
                            .connectA2dp(true)
                            .listenHfp(true).build()
                )
                .build()

        FissionLogUtils.d(TAG, "------connectDevice-------:${mDeviceAddress}")
        getSmartWearModelClient()
        isDeviceConnecting = true
        val connectResult = getPeripheralConnectionManager().startConnect(params)
        if (connectResult != BeeError.SUCCESS) {
            isDeviceConnecting = false
            FissionLogUtils.w(TAG, "connectDevice startConnect failed: code=$connectResult")
        }

        FissionLogUtils.d(TAG, "------connectDevice result: -------: $connectResult")
    }

    /** 设备是否处于连接握手/同步中，避免重复 startConnect 引发 SDK 异常。 */
    private fun isDeviceConnectionInProgress(): Boolean {
        if (isDeviceConnecting) return true
        val manager = mConnectionManager ?: return false
        return when (manager.connectState) {
            PeripheralConnectionManager.STATE_DEVICE_CONNECTING,
            PeripheralConnectionManager.STATE_DEVICE_DISCONNECTING,
            PeripheralConnectionManager.STATE_DEVICE_CONNECTED,
            PeripheralConnectionManager.STATE_DATA_SYNC_PROCESSING -> true
            else -> false
        }
    }

    fun getBatteryLevel() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_GET_CHARGING_STATUS)
    }

    /**
     * 拨打电话
     * @param phoneNumberStr +8612009090101
     */
    fun dialoutWithPhoneNumber(phoneNumberStr:String){
        getSmartWearModelClient()?.dialoutWithPhoneNumber(phoneNumberStr)
    }

    fun deviceShutDown() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_REBOOT_DEVICE)
    }

    fun requestDeviceVersionInfo() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_GET_DEVICE_VERSION)
    }

    fun setLedBrightness(level: GlassesConstant.LedBrightnessLevel) {
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_LED_BRIGHTNESS,
            byteArrayOf(level.toRtkCustomBrightness().toByte()),
        )
    }

    fun requestLedBrightness() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_GET_LED_BRIGHTNESS)
    }

    fun setWearDetectionSwitch(enabled: Boolean) {
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_WEARING_DETECTION_SWITCH,
            byteArrayOf(booleanToRtkCustomSwitch(enabled)),
        )
    }

    fun getVoiceWakeupSwitch(){

    }

    fun setVoiceWakeupSwitch(enabled: Boolean) {
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_VOICE_WAKEUP_SWITCH,
            byteArrayOf(booleanToRtkCustomSwitch(enabled)),
        )
    }

    fun setLivePreviewMicState(
        state: GlassesConstant.EnableState) {
        // 固件暂未支持 0x0818，麦默认开启；仍下发以便后续固件兼容，但不据此 remount 预览
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_MIC_ENABLED_STATUS,
            byteArrayOf(enableStateToRtkCustomSwitch(state)),
        )
    }

    fun requestDeviceStatus() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_GET_DEVICE_STATUS)
    }

    fun getDeviceCapacityInfo(){
        getSmartWearModelClient()?.deviceCapacityInfo
    }

    fun resetGestureShortcuts(){

    }

    fun upVolume() {
        getPeripheralConnectionManager().vendorClient.volumeUp()
    }

    fun downVolume() {
        getPeripheralConnectionManager().vendorClient.volumeDown()
    }

    fun startTakePhotoProcess(takePhotoOnly: Boolean) {
        mScope.launch {
            if (!awaitSmartWearReady()) {
                FissionLogUtils.e(TAG, "startTakePhotoProcess: SmartWear init not ready")
                sendEvent(RtkSdkShareEvent.OnTakePhotoFail(1001))
                return@launch
            }
            if (takePhotoOnly) {
                getSmartWearModelClient()?.startTakePhotoProcess()
            } else {
                getSmartWearModelClient()?.startTakeLifePhotoProcess()
            }
        }
    }

    /**
     * 配置高清拍照参数（异步）。成功/失败通过 [RtkSdkShareEvent.OnLifePhotoConfigResult] 回调。
     */
    fun setLifePhotoConfig(config: LifePhotoConfig) {
        mScope.launch {
            if (!awaitSmartWearReady()) {
                FissionLogUtils.e(TAG, "setLifePhotoConfig: SmartWear init not ready")
                sendEvent(RtkSdkShareEvent.OnLifePhotoConfigResult(false))
                return@launch
            }
            val client = getSmartWearModelClient()
            if (client == null) {
                FissionLogUtils.e(TAG, "setLifePhotoConfig: SmartWearModelClient is null")
                sendEvent(RtkSdkShareEvent.OnLifePhotoConfigResult(false))
                return@launch
            }
            val quality = config.jpegQuality.coerceIn(
                LifePhotoConfig.JPEG_QUALITY_MIN,
                LifePhotoConfig.JPEG_QUALITY_MAX,
            )
            val rotation = when (config.rotationDegrees) {
                0 -> LifePhotoConfigInfo.ROTATION_0
                90 -> LifePhotoConfigInfo.ROTATION_90
                180 -> LifePhotoConfigInfo.ROTATION_180
                270 -> LifePhotoConfigInfo.ROTATION_270
                else -> {
                    FissionLogUtils.e(
                        TAG,
                        "setLifePhotoConfig: unsupported rotationDegrees=${config.rotationDegrees}",
                    )
                    sendEvent(RtkSdkShareEvent.OnLifePhotoConfigResult(false))
                    return@launch
                }
            }
            val info = LifePhotoConfigInfo().apply {
                photoWidth = config.photoWidth
                photoHeight = config.photoHeight
                jpegQuality = quality
                setRotation(rotation)
            }
            pendingMediaConfigAck.set(PendingMediaConfigAck.LIFE_PHOTO)
            val ret = client.setLifePhotoConfigInfo(info)
            if (ret.code != BeeError.SUCCESS) {
                pendingMediaConfigAck.compareAndSet(PendingMediaConfigAck.LIFE_PHOTO, null)
                FissionLogUtils.e(
                    TAG,
                    "setLifePhotoConfig: send failed code=${ret.code} msg=${ret.message}",
                )
                sendEvent(RtkSdkShareEvent.OnLifePhotoConfigResult(false))
            }
        }
    }

    /**
     * 修改 SoftAP 热点名称与密码（异步）。结果通过 [RtkSdkShareEvent.OnWifiApConfigResult] 回调。
     */
    fun setWifiApConfig(config: WifiApConfig) {
        mScope.launch {
            val validationError = validateWifiApConfig(config)
            if (validationError != null) {
                FissionLogUtils.e(TAG, "setWifiApConfig: $validationError")
                sendEvent(RtkSdkShareEvent.OnWifiApConfigResult(false))
                return@launch
            }
            if (!awaitSmartWearReady()) {
                FissionLogUtils.e(TAG, "setWifiApConfig: SmartWear init not ready")
                sendEvent(RtkSdkShareEvent.OnWifiApConfigResult(false))
                return@launch
            }
            val client = getSmartWearModelClient()
            if (client == null) {
                FissionLogUtils.e(TAG, "setWifiApConfig: SmartWearModelClient is null")
                sendEvent(RtkSdkShareEvent.OnWifiApConfigResult(false))
                return@launch
            }
            val info = WifiParamsConfigInfo.create(config.ssid, config.password)
            if (info == null) {
                FissionLogUtils.e(TAG, "setWifiApConfig: WifiParamsConfigInfo.create returned null")
                sendEvent(RtkSdkShareEvent.OnWifiApConfigResult(false))
                return@launch
            }
            pendingMediaConfigAck.set(PendingMediaConfigAck.WIFI_AP)
            val ret = client.setWifiParamsConfigInfo(info)
            if (ret.code != BeeError.SUCCESS) {
                pendingMediaConfigAck.compareAndSet(PendingMediaConfigAck.WIFI_AP, null)
                FissionLogUtils.e(
                    TAG,
                    "setWifiApConfig: send failed code=${ret.code} msg=${ret.message}",
                )
                sendEvent(RtkSdkShareEvent.OnWifiApConfigResult(false))
            } else {
                // 下发成功后先更新本地缓存，便于后续 SoftAP 连接使用新凭据
                wifiSsid = config.ssid
                wifiPassword = config.password
            }
        }
    }

    private fun validateWifiApConfig(config: WifiApConfig): String? {
        val ssidBytes = try {
            config.ssid.toByteArray(StandardCharsets.US_ASCII)
        } catch (_: Exception) {
            return "SSID must be ASCII"
        }
        val pwdBytes = try {
            config.password.toByteArray(StandardCharsets.US_ASCII)
        } catch (_: Exception) {
            return "password must be ASCII"
        }
        // 非 ASCII 字符经 US_ASCII 会变成 '?'，用 round-trip 再判一次
        if (String(ssidBytes, StandardCharsets.US_ASCII) != config.ssid) {
            return "SSID must be ASCII"
        }
        if (String(pwdBytes, StandardCharsets.US_ASCII) != config.password) {
            return "password must be ASCII"
        }
        if (ssidBytes.size !in WifiApConfig.SSID_BYTES_MIN..WifiApConfig.SSID_BYTES_MAX) {
            return "SSID ASCII length must be ${WifiApConfig.SSID_BYTES_MIN}..${WifiApConfig.SSID_BYTES_MAX}"
        }
        if (pwdBytes.size !in WifiApConfig.PWD_BYTES_MIN..WifiApConfig.PWD_BYTES_MAX) {
            return "password ASCII length must be ${WifiApConfig.PWD_BYTES_MIN}..${WifiApConfig.PWD_BYTES_MAX}"
        }
        return null
    }

    fun startDeviceRecording() {
        getSmartWearModelClient()?.startAudioRecording()
    }

    fun stopDeviceRecording() {
        getSmartWearModelClient()?.stopAudioRecording()
    }

    fun startVideoRecording() {
        getSmartWearModelClient()?.startRecordingProcess()
    }

    fun stopVideoRecording() {
        getSmartWearModelClient()?.stopRecordingProcess()
    }

    fun getMediaFileCount() {
        getSmartWearModelClient()?.remoteDeviceFileCount //onFileStorageInfoChanged返回
    }

    fun rebootDevice() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_REBOOT_DEVICE)
    }

    fun restoreFactorySettings() {
        sendCustomVendorCommand(CustomVendorProtocol.CMD_FACTORY_RESET)
    }

    fun setVideoDuration(times: Int) {
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_VIDEO_RECORDING_DURATION,
            intToUint16LeBytes(times),
        )
    }

    fun setAudioRecordingDuration(times: Int) {
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_AUDIO_RECORDING_DURATION,
            intToUint16LeBytes(times),
        )
    }

    fun setScreenOrientation(orientation: GlassesConstant.ScreenOrientation) {
        sendCustomVendorCommand(
            CustomVendorProtocol.CMD_SET_SHOOTING_DIRECTION,
            byteArrayOf(orientation.toRtkShootingDirection().toByte()),
        )
    }

    fun startUserVoiceInput(){
        getSmartWearModelClient()?.startUserVoiceInput()
    }

    fun stopUserVoiceInput(){
        getSmartWearModelClient()?.stopUserVoiceInput()
    }



    fun release() {
        mDeviceAddress = ""
        clearCustomProtocolCallback()
        mConnectionManager?.unregisterVendorModelCallback(innerVendorModelCallback)
        mConnectionManager = null
        resetSmartWearModelClient()
//        FissionLogUtils.d(TAG, "release 释放了： ${mConnectionManager == null}")
    }

    fun disConnect() {
        cancelSmartWearInitRetry()
        isDeviceConnecting = false
        val ret = getPeripheralConnectionManager().disconnect()
        FissionLogUtils.d(TAG, "disConnect---->  ${ret.code == BeeError.SUCCESS}")
        clearCustomProtocolCallback()
        mConnectionManager = null
        resetSmartWearModelClient()
    }

    /**
     * Step 1 — 对齐 [DebugLiveStreamingActivity.startLiveStreaming]（WIFI AP 模式）：
     * 组装 [LiveStreamingConfigInfo] 并异步调用 `liveStreamingManager.startLiveStreaming()`。
     * 眼镜开 AP、起 RTSP、手机连热点均在 Realtek SDK 内部完成；
     * Step 2 见 [onStartLiveStreaming] → [startLiveStreamingOnWifiApMode]。
     */
    suspend fun startLiveStreaming(liveStreamingConfig: LiveStreamingConfig) {
        markLiveSessionStarted()
        mLiveStreamingConfig = liveStreamingConfig
        FissionLogUtils.d(
            TAG,
            "startLiveStreaming mode=${liveStreamingConfig.mode} " +
                "hasPushUrl=${!liveStreamingConfig.pushUrl.isNullOrBlank()}",
        )
        if (liveStreamingConfig.includesPreview()) {
            (liveStreamingConfig.previewView as? RTKVideoView)?.let(::attachLivePreviewView)
        }
        liveRtspUrl = ""
        // pushUrl 可稍后由 startPushLiveStreaming 提供；PUSH 无地址时只起眼镜 RTSP
        val liveStreamingConfigInfo = LiveStreamingConfigInfo().apply {
            liveStreamingChannel = LiveStreamingConfigInfo.LiveStreamingChannel.WIFI_AP
            videoEncoding = LiveStreamingConfigInfo.VideoEncoding.H264
            if (liveStreamingConfig.videoPictureWidth > 0 && liveStreamingConfig.videoPictureHeight > 0) {
                videoResolutionType = VideoResolution.RESOLUTION_HD
                videoPictureWidth = liveStreamingConfig.videoPictureWidth
                videoPictureHeight = liveStreamingConfig.videoPictureHeight
                fps = liveStreamingConfig.fps
                bps = liveStreamingConfig.bps
                maxQp = liveStreamingConfig.maxQp
                minQp = liveStreamingConfig.minQp
                videoRotationType = VideoRotation.RESOLUTION_0
                videoBitRateMode = mapVideoBitRateMode(liveStreamingConfig.videoBitRateMode)
            }
        }
        mLiveStreamingConfigInfo = liveStreamingConfigInfo

        val client = getSmartWearModelClient()
        if (client == null) {
            abortLiveStreamingStart(LiveStreamErrors.CODE_DEVICE_NOT_CONNECTED)
            return
        }
        if (!awaitSmartWearReady()) {
            abortLiveStreamingStart(LiveStreamErrors.CODE_DEVICE_NOT_READY)
            return
        }
        // RTKLiveStreamingManager step3 直接读 SmartWearDeviceInfo.getWifiApInfo().ssid，为 null 会 NPE
        if (!awaitSmartWearWifiApInfoForLive()) {
            abortLiveStreamingStart(LiveStreamErrors.CODE_HOTSPOT_INFO_UNAVAILABLE)
            return
        }
        resolveSmartWearWifiApInfo()?.let { liveStreamingConfigInfo.wifiApInfo = it }
        // Step 1: 交给 Realtek liveStreamingManager（内部 open AP → RTSP → connect WiFi）
        client.liveStreamingManager?.startLiveStreaming(mLiveStreamingConfigInfo)
    }

    private fun handleLiveStreamingStartFailed() {
        if (isInLivePushPhase()) {
            notifyLiveDisconnected(
                LiveDisconnectMonitor.REASON_LIVE_INTERRUPTED,
                GlassesConstant.ERROR_CODE_LIVE_INTERRUPTED,
            )
            return
        }
        val ssid = wifiSsid.orEmpty()
        val code = if (ssid.isNotBlank() && !isPhoneAssociatedToGlassesAp(ssid)) {
            LiveStreamErrors.CODE_WIFI_JOIN_REJECTED
        } else {
            LiveStreamErrors.CODE_GLASSES_START_FAILED
        }
        abortLiveStreamingStart(code)
    }

    /**
     * Step 2 — 对齐 [DebugLiveStreamingActivity.startLiveStreamingOnWifiApMode]：
     * 在 `onStartLiveStreaming(startResult=true, WIFI_AP)` 后启动 [RTKMediaPlayerService] 本地预览/推流。
     */
    private fun startLiveStreamingOnWifiApMode() {
        val config = mLiveStreamingConfig ?: run {
            FissionLogUtils.w(TAG, "startLiveStreamingOnWifiApMode: missing LiveStreamingConfig")
            return
        }
        if (!::livePreviewController.isInitialized) return
        val mode = config.mode
        FissionLogUtils.d(TAG, "startLiveStreamingOnWifiApMode mode=$mode rtsp=$liveRtspUrl")
        when (mode) {
            GlassesConstant.LiveStreamingMode.PUSH -> {
                val pushUrl = config.pushUrl
                if (pushUrl.isNullOrBlank()) {
                    FissionLogUtils.d(
                        TAG,
                        "PUSH mode: glasses RTSP ready, waiting startPushLiveStreaming(rtmp)",
                    )
                    return
                }
                isLivePushActive = true
                livePreviewController.startLiveStreamingOnWifiApMode(
                    sessionType = SessionConfig.SESSION_TYPE_PUSH,
                    pushUrl = pushUrl,
                )
            }
            GlassesConstant.LiveStreamingMode.PREVIEW -> {
                livePreviewController.startLiveStreamingOnWifiApMode(
                    sessionType = SessionConfig.SESSION_TYPE_PREVIEW,
                    pushUrl = null,
                )
            }
            GlassesConstant.LiveStreamingMode.PREVIEW_PUSH,
            GlassesConstant.LiveStreamingMode.PREVIEW_PUSH_MANUAL -> {
                val pushUrl = config.pushUrl
                if (pushUrl.isNullOrBlank()) {
                    livePreviewController.startLiveStreamingOnWifiApMode(
                        sessionType = SessionConfig.SESSION_TYPE_PREVIEW,
                        pushUrl = null,
                    )
                } else {
                    isLivePushActive = true
                    livePreviewController.startLiveStreamingOnWifiApMode(
                        sessionType = SessionConfig.SESSION_TYPE_PREVIEW_PUSH,
                        pushUrl = pushUrl,
                    )
                }
            }
        }
    }

    private fun mapVideoBitRateMode(mode: GlassesConstant.VideoBitRateMode): Byte =
        when (mode) {
            GlassesConstant.VideoBitRateMode.CBR -> VideoBitRateMode.BITRATE_MODE_CBR
            GlassesConstant.VideoBitRateMode.VBR -> VideoBitRateMode.BITRATE_MODE_VBR
        }

    fun setLivePreviewRotation(degrees: Int) {
        if (::livePreviewController.isInitialized) {
            livePreviewController.setPreviewRotation(degrees)
        }
    }

    fun attachLivePreviewView(view: RTKVideoView) {
        if (!::livePreviewController.isInitialized) return
        livePreviewController.attachPreviewView(view)
    }

    fun detachLivePreviewView() {
        if (::livePreviewController.isInitialized) {
            livePreviewController.detachPreviewView()
        }
    }

    /**
     * 开始/切换到 RTMP 推流（官方 RTK 播放器内部完成 RTSP→RTMP，网络路由由播放器处理）。
     *
     * - [LiveStreamingMode.PUSH]：直接推（无本地预览）
     * - [LiveStreamingMode.PREVIEW_PUSH]：在已有预览会话上追加推流
     */
    fun startPushLiveStreaming(liveUrl: String) {
        if (liveUrl.isBlank()) return
        if (!::livePreviewController.isInitialized) return
        val config = mLiveStreamingConfig
        FissionLogUtils.d(TAG, "startPushLiveStreaming mode=${config?.mode}")
        isLivePushActive = true
        if (config?.includesPreview() == true) {
            (config.previewView as? RTKVideoView)?.let(::attachLivePreviewView)
        }
        val sessionType = if (config?.includesPreview() == true) {
            SessionConfig.SESSION_TYPE_PREVIEW_PUSH
        } else {
            SessionConfig.SESSION_TYPE_PUSH
        }
        livePreviewController.startLiveStreamingOnWifiApMode(
            sessionType = sessionType,
            pushUrl = liveUrl,
        )
    }

    private fun isPhoneAssociatedToGlassesAp(ssid: String): Boolean {
        if (wifiAdapter.isSpecificWifiConnected(ssid)) return true
        val current = runCatching { wifiAdapter.getCurrentSsid() }.getOrNull()
            ?.trim()
            ?.trim('"')
            .orEmpty()
        if (current.equals(ssid, ignoreCase = true)) return true
        return findActiveWifiNetwork() != null
    }

    @SuppressLint("MissingPermission")
    private fun findActiveWifiNetwork(): Network? {
        val connectivityManager =
            mContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivityManager.allNetworks.firstOrNull { network ->
            val caps = connectivityManager.getNetworkCapabilities(network) ?: return@firstOrNull false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }
    }

    fun stopRtspStream() {
        val shouldEmitRespStop = isLiveSessionActive && !liveDisconnectNotified
        stopLiveStreamingBestEffort()
        clearLiveSessionState()
        if (shouldEmitRespStop) {
            sendEvent(RtkSdkShareEvent.RespStop)
        }
    }

    /** 通知栏关闭 RTKMediaPlayerService：清理会话并上报 [RtkSdkShareEvent.LiveStoppedByNotification]。 */
    private fun handleLiveStoppedByNotification() {
        liveStoppingByNotification = true
        FissionLogUtils.i(TAG, "live stopped by notification bar")
        if (isLiveSessionActive) {
            stopLiveStreamingBestEffort()
            clearLiveSessionState()
        }
        liveStoppingByNotification = false
        sendEvent(RtkSdkShareEvent.LiveStoppedByNotification)
    }

    /**
     * 对齐官方 [DebugLiveStreamingActivity.stopLiveStreaming] 核心三步：
     * 1. 关本地播放器（RTKMediaPlayerService）
     * 2. 通知眼镜关播 `liveStreamingManager.stopLiveStreaming(channel)`
     * 3. 释放 `liveStreamingManager.release()`
     *
     * 直播正常结束、开播失败（含 WiFi 连接失败 callback）、网络切换/系统关 WiFi 等异常均需调用。
     */
    private fun stopLiveStreamingBestEffort() {
        FissionLogUtils.d(TAG, "stopLiveStreamingBestEffort")
        stopLivePreviewBestEffort()
        val liveChannel = mLiveStreamingConfigInfo?.liveStreamingChannel
            ?: LiveStreamingConfigInfo.LiveStreamingChannel.WIFI_AP
        runCatching {
            getSmartWearModelClient()?.liveStreamingManager?.stopLiveStreaming(liveChannel)
            getSmartWearModelClient()?.liveStreamingManager?.release()
        }.onFailure {
            FissionLogUtils.w(TAG, "stopLiveStreamingBestEffort failed: ${it.message}")
        }
        recoverNetworkHandle(disconnectGlassesAp = true, stopGlassesSoftAp = true)
    }

    private fun clearLiveSessionState() {
        markLiveSessionStopped()
        mLiveStreamingConfig = null
        mLiveStreamingConfigInfo = null
        liveRtspUrl = ""
    }

    /** 开播前/中失败：先 stopLiveStreaming 清理，再上报 Failed。 */
    private fun abortLiveStreamingStart(code: Int, reason: String? = null) {
        stopLiveStreamingBestEffort()
        clearLiveSessionState()
        sendEvent(
            RtkSdkShareEvent.RespFailed(
                reason ?: LiveStreamErrors.defaultReason(code),
                code,
            ),
        )
    }

    /** 先停 RTKMediaPlayer 本地预览/推流。 */
    private fun stopLivePreviewBestEffort() {
        runCatching {
            detachLivePreviewView()
            if (::livePreviewController.isInitialized) {
                livePreviewController.stop()
            }
        }.onFailure {
            FissionLogUtils.w(TAG, "stopLivePreview failed: ${it.message}")
        }
    }

    private fun markLiveSessionStarted() {
        isLiveSessionActive = true
        isLivePushActive = false
        liveDisconnectNotified = false
        liveStoppingByNotification = false
    }

    private fun markLiveSessionStopped() {
        isLiveSessionActive = false
        isLivePushActive = false
        if (::liveDisconnectMonitor.isInitialized) {
            liveDisconnectMonitor.stop()
        }
    }

    /**
     * 官方 Demo 未使用 WifiLock；在 RTK NetworkConnector.connectToWifi 之前持有
     * WIFI_MODE_FULL_HIGH_PERF 锁时，部分 ROM 会抑制 WiFi 扫描/切网，导致找不到眼镜 AP。
     */
    private fun startLiveDisconnectMonitorIfNeeded() {
        if (!::liveDisconnectMonitor.isInitialized) return
        liveDisconnectMonitor.start()
        liveDisconnectMonitor.refreshTrackedApNetwork()
    }

    private fun isInLivePushPhase(): Boolean = isLivePushActive

    private fun handleCustomWifiApStatusChanged(enabled: Boolean) {
        FissionLogUtils.d(TAG, "custom WiFi AP status changed: enabled=$enabled")
        if (!enabled && isLiveSessionActive) {
            notifyLiveDisconnected(
                LiveDisconnectMonitor.REASON_GLASSES_AP_CLOSED,
                GlassesConstant.ERROR_CODE_LIVE_GLASSES_AP_CLOSED,
            )
        }
    }

    private fun notifyLiveDisconnected(
        reason: String,
        code: Int = GlassesConstant.ERROR_CODE_LIVE_INTERRUPTED,
    ) {
        if (liveStoppingByNotification) {
            FissionLogUtils.d(TAG, "skip live disconnected during notification stop: $reason")
            return
        }
        if (!isLiveSessionActive || liveDisconnectNotified) return
        liveDisconnectNotified = true
        FissionLogUtils.w(TAG, "live disconnected: code=$code reason=$reason")
        stopLiveStreamingBestEffort()
        markLiveSessionStopped()
        mLiveStreamingConfig = null
        mLiveStreamingConfigInfo = null
        liveRtspUrl = ""
        sendEvent(RtkSdkShareEvent.LiveDisconnected(reason, code))
    }

    suspend fun startOta(path: String, type: GlassesConstant.OtaType, versionName: String?){
        rtkOtaManager.startOta(path, type, versionName)
    }

    suspend fun startOtaFromPackageDir(extractedDirPath: String) {
        rtkOtaManager.startOtaFromPackageDir(extractedDirPath)
    }

    suspend fun startOtaBoth(btPath: String?, btVer: String?, wifiZipPath: String?) {
        rtkOtaManager.startOtaBoth(btPath, btVer, wifiZipPath)
    }

    fun stopOta(){
        rtkOtaManager.stopOta()
    }

    fun syncMediaFile() {
        val imageCorrectEnabled = sdkConfig.deviceLensType.needsDistortionCorrect()
        mediaSyncManager?.startSync(
            ipAddress = ipAddress,
            imageCorrectEnabled = imageCorrectEnabled,
            enableAp = { enableAp() },
            connectWiFi = { connectWiFi(syncWifiSession) },
            disableAp = {
                getSmartWearModelClient()?.setWifiModule(SmartWearConstants.WifiMode.WIFI_MODE_IDLE)
            },
            unbindNetwork = { recoverNetworkHandle(disconnectGlassesAp = true, stopGlassesSoftAp = false) },
            isWifiStillConnected = { wifiAdapter.isSpecificWifiConnected(wifiSsid) },
        )
    }

    /**
     * 释放眼镜 SoftAP / [NetworkConnector] 占用的进程网络绑定，恢复手机访问公网。
     *
     * OTA、直播、文件同步连接眼镜 AP 后，Realtek SDK 可能通过
     * [ConnectivityManager.bindProcessToNetwork] 将本进程绑到无公网的热点；流程结束需调用本方法恢复。
     */
    @SuppressLint("MissingPermission")
    private fun recoverNetworkHandle(
        disconnectGlassesAp: Boolean = true,
        stopGlassesSoftAp: Boolean = false,
    ) {
        FissionLogUtils.i(
            TAG,
            "recoverNetworkHandle disconnectAp=$disconnectGlassesAp stopSoftAp=$stopGlassesSoftAp",
        )

        runCatching { NetworkConnector.release(mContext) }
            .onFailure { FissionLogUtils.w(TAG, "recoverNetworkHandle NetworkConnector.release: ${it.message}") }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            runCatching {
                val cm = mContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val ok = cm.bindProcessToNetwork(null)
                FissionLogUtils.i(TAG, "recoverNetworkHandle bindProcessToNetwork(null) -> $ok")
            }.onFailure {
                FissionLogUtils.w(TAG, "recoverNetworkHandle bindProcessToNetwork(null): ${it.message}")
            }
        }

        if (disconnectGlassesAp) {
            runCatching {
                val ssid = wifiSsid.trim().trim('"')
                if (ssid.isNotEmpty() && wifiAdapter.isSpecificWifiConnected(ssid)) {
                    FissionLogUtils.d(TAG, "recoverNetworkHandle disconnect from $ssid")
                    wifiAdapter.disconnect()
                }
            }.onFailure { FissionLogUtils.w(TAG, "recoverNetworkHandle disconnect: ${it.message}") }
        }

        if (stopGlassesSoftAp) {
            runCatching { wifiAdapter.stopSoftAp() }
                .onFailure { FissionLogUtils.w(TAG, "recoverNetworkHandle stopSoftAp: ${it.message}") }
        }

        runCatching { wifiAdapter.updateWifiConnectionState(false) }
            .onFailure {
                FissionLogUtils.w(TAG, "recoverNetworkHandle updateWifiConnectionState: ${it.message}")
            }
        wifiConnected = false
        if (::syncWifiSession.isInitialized) syncWifiSession.oldWifiConfiguration = null
        if (::otaWifiSession.isInitialized) otaWifiSession.oldWifiConfiguration = null
        if (::liveWifiSession.isInitialized) liveWifiSession.oldWifiConfiguration = null
    }


    private suspend fun enableApWithRetry(): Boolean {
        repeat(WIFI_AP_ENABLE_MAX_RETRIES) { attempt ->
            if (enableAp()) {
                return true
            }
            if (attempt < WIFI_AP_ENABLE_MAX_RETRIES - 1) {
                FissionLogUtils.w(TAG, "enableAp failed, retry ${attempt + 2}/$WIFI_AP_ENABLE_MAX_RETRIES")
                runCatching {
                    getSmartWearModelClient()?.liveStreamingManager?.stopLiveStreaming(
                        LiveStreamingConfigInfo.LiveStreamingChannel.WIFI_AP,
                    )
                }
                delay(WIFI_AP_RETRY_DELAY_MS)
                runCatching {
                    getSmartWearModelClient()?.openWifiModule()
                }
            }
        }
        return false
    }

    private suspend fun enableAp(): Boolean {
        val client = getSmartWearModelClient() ?: return false
        val ret = client.openWifiModule()
        if (ret.code != BeeError.SUCCESS) {
            return false
        }

        val waitStartAt = SystemClock.elapsedRealtime()
        val apStateChangedDeferred = CompletableDeferred<WifiApInfo>()
        synchronized(wifiApStateLock) {
            val cached = lastWifiApInfo
            // 仅当 wait 开始后已收到「成功且有 SSID」的 AP 信息时才短路；且 SmartWearDeviceInfo 必须已同步
            if (lastWifiApStateChangedAt >= waitStartAt &&
                cached?.isOk == true &&
                !cached.ssid.isNullOrBlank() &&
                resolveSmartWearWifiApInfo() != null
            ) {
                return true
            }
            wifiApStateChangedDeferred = apStateChangedDeferred
        }

        val wifiApInfo = withTimeoutOrNull(WIFI_AP_ENABLE_TIMEOUT_MS) {
            apStateChangedDeferred.await()
        }
        clearWifiApStateChangedDeferred(apStateChangedDeferred)
        if (wifiApInfo?.isOk != true || wifiApInfo.ssid.isNullOrBlank()) {
            return false
        }
        return waitSmartWearDeviceWifiApInfoSynced("enableAp")
    }

    /**
     * RTK 直播 step3 使用 [SmartWearDeviceInfo.getWifiApInfo]（非 App 回调缓存）。
     * 须先 enableAp 触发 0x842C，由 SDK 内部写入 SmartWearDeviceInfo，再调用 liveStreamingManager。
     */
    private suspend fun awaitSmartWearWifiApInfoForLive(): Boolean {
        resolveSmartWearWifiApInfo()?.let {
            FissionLogUtils.d(TAG, "awaitSmartWearWifiApInfo: ready ssid=${it.ssid}")
            return true
        }

        FissionLogUtils.d(TAG, "awaitSmartWearWifiApInfo: prefetch via enableAp")
        if (!enableAp()) {
            FissionLogUtils.w(TAG, "awaitSmartWearWifiApInfo: enableAp failed")
            return false
        }
        return waitSmartWearDeviceWifiApInfoSynced("awaitSmartWearWifiApInfo")
    }

    private fun resolveSmartWearWifiApInfo(): WifiApInfo? {
        return SmartWearDeviceInfo.getInstance().wifiApInfo?.takeIf { info ->
            info.isOk && !info.ssid.isNullOrBlank() && !info.password.isNullOrBlank()
        }
    }

    private suspend fun waitSmartWearDeviceWifiApInfoSynced(logPrefix: String): Boolean {
        repeat(SMART_WEAR_WIFI_AP_INFO_POLL_COUNT) {
            resolveSmartWearWifiApInfo()?.let { info ->
                FissionLogUtils.d(TAG, "$logPrefix: SmartWearDeviceInfo ready ssid=${info.ssid}")
                return true
            }
            delay(SMART_WEAR_WIFI_AP_INFO_POLL_MS)
        }
        FissionLogUtils.w(TAG, "$logPrefix: SmartWearDeviceInfo.wifiApInfo still null")
        return false
    }

    private suspend fun awaitSmartWearReady(): Boolean {
        if (mDeviceAddress.isBlank()) return false
        if (getSmartWearModelClient() == null) return false
        if (isSmartWearReady) return true

        val waitStartAt = SystemClock.elapsedRealtime()
        synchronized(smartWearInitLock) {
            if (lastSmartWearInitSuccessAt >= waitStartAt) {
                return true
            }
        }

        val (initDeferred, shouldTriggerInit) = synchronized(smartWearInitLock) {
            if (isSmartWearReady) {
                return true
            }
            if (lastSmartWearInitSuccessAt >= waitStartAt) {
                return true
            }
            val existing = smartWearInitDeferred
            if (existing != null) {
                Pair(existing, false)
            } else {
                val deferred = CompletableDeferred<Boolean>()
                smartWearInitDeferred = deferred
                Pair(deferred, true)
            }
        }

        if (shouldTriggerInit) {
            initSmartWearDeviceOnMain()
        }

        val ready = withTimeoutOrNull(SMART_WEAR_INIT_TIMEOUT_MS) {
            initDeferred.await()
        }
        synchronized(smartWearInitLock) {
            if (smartWearInitDeferred === initDeferred) {
                smartWearInitDeferred = null
            }
        }
        return ready == true || isSmartWearReady
    }

    private fun clearWifiApStateChangedDeferred(deferred: CompletableDeferred<WifiApInfo>) {
        synchronized(wifiApStateLock) {
            if (wifiApStateChangedDeferred === deferred) {
                wifiApStateChangedDeferred = null
            }
        }
    }

    private fun connectWiFi(
        session: RtkWifiConnectSession,
        ssid: String = wifiSsid,
        password: String = wifiPassword,
    ): Boolean {
        session.wifiConnectParameter = WifiConnectParameter(
            ssid, password,
            true, 30 * 1000L,
            true,
            true
        )

        if (session.oldWifiConfiguration == null) {
            session.oldWifiConfiguration =
                wifiAdapter.getOldWifiConfiguration(session.wifiConnectParameter)
            FissionLogUtils.v(
                TAG,
                "${session.featureTag} update oldWifiConfiguration:${session.oldWifiConfiguration}",
            )
        }

        var ret = true
        var connected = false
        val pingPongDelayEnabled = true
        val pingPongDelayTime = 2 * 1000L
        val connectionTimes = 3
        for (connIndex in 0 until connectionTimes) {
            runBlocking {
                if (wifiAdapter.isSpecificWifiConnected(ssid)) {
                    FissionLogUtils.d(TAG, "${session.featureTag} wifi already connected")
                    ret = true
                } else {
                    try {
                        ret = wifiAdapter.connect(session.wifiConnectParameter)
                    } catch (e: Exception) {
                        FissionLogUtils.w(TAG, "${session.featureTag} connectWiFi: ${e.message}")
                        e.printStackTrace()
                    }

                    FissionLogUtils.v(
                        TAG,
                        "${session.featureTag} connectWiFi(${connIndex + 1}/$connectionTimes):$ret",
                    )
                }
                if (pingPongDelayEnabled) {
                    delay(pingPongDelayTime)
                }
            }

            if (!ret) {
                continue
            }

            val pingpongTimes = 2
            for (index in 0 until pingpongTimes) {
                FissionLogUtils.v(
                    TAG,
                    "${session.featureTag} pending to ping-pong(${(index + 1)}/$pingpongTimes)",
                )
                val isNetworkConnected = RtkNetworkUtils.isNetworkConnected(mContext)
                val currentSsid = wifiAdapter.getCurrentSsid()
                FissionLogUtils.d(
                    TAG,
                    "${session.featureTag} isNetworkConnected：$currentSsid=$isNetworkConnected",
                )
                connected = session.pingClient.pingpong()
                if (connected) {
                    break
                }
            }
            if (connected) {
                break
            }
        }

        wifiConnected = connected
        return connected
    }

    private fun stopMediaSyncProcedure() {
        mediaSyncManager?.stopSync()
        recoverNetworkHandle(disconnectGlassesAp = true, stopGlassesSoftAp = false)
    }

    private fun sendEvent(event: RtkSdkShareEvent) {
        mScope.launch {
            _rtkEvent.emit(event)
        }
    }

    private fun clearCustomProtocolCallback() {
        mConnectionManager?.removeManagerCallback(customProtocolBumblebeeCallback)
        customProtocolCallbackRegistered = false
    }

    private fun ensureCustomProtocolCallback() {
        val manager = mConnectionManager ?: return
        if (customProtocolCallbackRegistered) return
        manager.addManagerCallback(customProtocolBumblebeeCallback)
        customProtocolCallbackRegistered = true
        FissionLogUtils.d(TAG, "custom protocol BumblebeeCallback registered")
    }

    private fun sendCustomVendorCommand(commandId: Int, payload: ByteArray = CustomVendorProtocol.PARAMS_EMPTY) {
        if (mDeviceAddress.isBlank()) {
            FissionLogUtils.w(TAG, "sendCustomVendorCommand skipped: device not connected")
            return
        }
        // 优先走 SmartWearModelClient，与瑞昱 Demo SmartWearModelAdapter 一致
        getSmartWearModelClient()
        getPeripheralConnectionManager()
        ensureCustomProtocolCallback()

        val expectedEventId = CustomVendorProtocol.commandToEvent(commandId)
        val builder = Command.Builder()
            .writeType(Command.WRITE_TYPE_WITH_RESPONSE)
            .packet(commandId, payload)
        if (expectedEventId > 0) {
            builder.eventId(expectedEventId)
        }
        val command = builder.build()

        val client = mSmartWearModelClient
        val result = if (client != null) {
            client.sendVendorCommand(command)
        } else {
            getPeripheralConnectionManager().sendVendorCommand(command)
        }
        FissionLogUtils.d(
            TAG,
            "sendCustomVendorCommand: cmd=0x${commandId.toString(16)} " +
                "event=0x${if (expectedEventId > 0) expectedEventId.toString(16) else "-"} " +
                "payload=${payload.size} result=$result",
        )
    }

    private fun getPeripheralConnectionManager(): PeripheralConnectionManager {
        if (mConnectionManager == null) {
            // 旧 manager 已丢弃时必须允许重新注册，否则重连后 ACK/EVENT 全部丢失
            customProtocolCallbackRegistered = false
            mConnectionManager = MultiPeripheralConnectionManager.getInstance(mContext)
                    .getPeripheralConnectionManager(mDeviceAddress)
            mConnectionManager?.registerVendorModelCallback(innerVendorModelCallback)
            ensureCustomProtocolCallback()
        }
        return mConnectionManager!!
    }


}

/** 等待 onUpdateWifiInfo 时区分配置类型。 */
private enum class PendingMediaConfigAck {
    LIFE_PHOTO,
    WIFI_AP,
}

