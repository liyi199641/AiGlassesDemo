package com.fission.wear.glasses.sdk.ota.rtk

import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.Locale

/**
 * 对齐《瑞昱眼镜 OTA 升级实现说明 V1.0.1》的 ota.json。
 * APP / SDK 只校验与按序传输，不改写 mode。
 */
data class RtkOtaPackageItem(
    val type: Int,
    val version: String,
    val file: String,
    val size: Long,
    val sha256: String,
) {
    companion object {
        const val TYPE_WIFI = 1
        const val TYPE_BOOT = 2
        const val TYPE_NN = 3
        const val TYPE_ISP_IQ = 4
    }
}

data class RtkOtaManifest(
    val schemaVersion: Int,
    val totalVersion: String,
    val mode: String,
    val packages: List<RtkOtaPackageItem>,
)

object RtkOtaModeWhitelist {
    /** mode → 规定的 type 顺序 */
    private val MODE_ORDER: Map<String, List<Int>> = mapOf(
        "0x02" to listOf(RtkOtaPackageItem.TYPE_WIFI),
        "0x03" to listOf(RtkOtaPackageItem.TYPE_BOOT, RtkOtaPackageItem.TYPE_WIFI),
        "0x0A" to listOf(RtkOtaPackageItem.TYPE_NN, RtkOtaPackageItem.TYPE_WIFI),
        "0x0B" to listOf(RtkOtaPackageItem.TYPE_BOOT, RtkOtaPackageItem.TYPE_NN, RtkOtaPackageItem.TYPE_WIFI),
        "0x12" to listOf(RtkOtaPackageItem.TYPE_ISP_IQ, RtkOtaPackageItem.TYPE_WIFI),
        "0x13" to listOf(RtkOtaPackageItem.TYPE_BOOT, RtkOtaPackageItem.TYPE_ISP_IQ, RtkOtaPackageItem.TYPE_WIFI),
        "0x1A" to listOf(RtkOtaPackageItem.TYPE_NN, RtkOtaPackageItem.TYPE_ISP_IQ, RtkOtaPackageItem.TYPE_WIFI),
        "0x1B" to listOf(
            RtkOtaPackageItem.TYPE_BOOT,
            RtkOtaPackageItem.TYPE_NN,
            RtkOtaPackageItem.TYPE_ISP_IQ,
            RtkOtaPackageItem.TYPE_WIFI,
        ),
    )

    fun normalizeMode(mode: String): String {
        val hex = mode.trim().lowercase(Locale.US).removePrefix("0x")
        return "0x" + hex.padStart(2, '0')
    }

    fun expectedOrder(mode: String): List<Int>? = MODE_ORDER[normalizeMode(mode)]
}

object RtkOtaManifestParser {
    fun parse(jsonFile: File): RtkOtaManifest {
        val text = jsonFile.readText(Charsets.UTF_8)
        val root = JSONObject(text)
        val packagesJson = root.getJSONArray("packages")
        val packages = buildList {
            for (i in 0 until packagesJson.length()) {
                val item = packagesJson.getJSONObject(i)
                add(
                    RtkOtaPackageItem(
                        type = item.getInt("type"),
                        version = item.getString("version").trim(),
                        file = item.getString("file").trim(),
                        size = item.getLong("size"),
                        sha256 = item.getString("sha256").trim().lowercase(Locale.US),
                    ),
                )
            }
        }
        return RtkOtaManifest(
            schemaVersion = root.getInt("schemaVersion"),
            totalVersion = root.getString("totalVersion").trim(),
            mode = root.getString("mode").trim(),
            packages = packages,
        )
    }

    /**
     * @return null 表示通过；非空为失败原因
     */
    fun validate(workDir: File, manifest: RtkOtaManifest): String? {
        if (manifest.schemaVersion != 1) {
            return "unsupported schemaVersion=${manifest.schemaVersion}"
        }
        // 产品 totalVersion 为 Vx.x.x.x（四段）；旧测试包偶发 Vx.x.x（三段）
        if (!manifest.totalVersion.matches(Regex("""^V\d+(\.\d+){2,3}$"""))) {
            return "invalid totalVersion=${manifest.totalVersion}"
        }
        if (manifest.packages.isEmpty()) {
            return "packages empty"
        }
        val expected = RtkOtaModeWhitelist.expectedOrder(manifest.mode)
            ?: return "mode not in whitelist: ${manifest.mode}"
        val actualTypes = manifest.packages.map { it.type }
        if (actualTypes != expected) {
            return "packages order/set mismatch mode=${manifest.mode} expected=$expected actual=$actualTypes"
        }
        if (actualTypes.toSet().size != actualTypes.size) {
            return "duplicate package type"
        }
        for (pkg in manifest.packages) {
            val expectedName = expectedFileName(pkg.type, pkg.version)
                ?: return "unknown package type=${pkg.type}"
            if (pkg.file != expectedName) {
                return "file name mismatch type=${pkg.type}: expect=$expectedName actual=${pkg.file}"
            }
            val bin = File(workDir, pkg.file)
            if (!bin.isFile) {
                return "missing file ${pkg.file}"
            }
            if (bin.length() != pkg.size) {
                return "size mismatch ${pkg.file}: expect=${pkg.size} actual=${bin.length()}"
            }
            val digest = sha256Hex(bin)
            if (!digest.equals(pkg.sha256, ignoreCase = true)) {
                return "sha256 mismatch ${pkg.file}"
            }
        }
        return null
    }

    fun expectedFileName(type: Int, version: String): String? {
        val v = version.trim().removePrefix("V").removePrefix("v")
        return when (type) {
            RtkOtaPackageItem.TYPE_WIFI -> "wifi_ota_v$v.bin"
            RtkOtaPackageItem.TYPE_BOOT -> "boot_ota_v$v.bin"
            RtkOtaPackageItem.TYPE_NN -> "nn_ota_v$v.bin"
            RtkOtaPackageItem.TYPE_ISP_IQ -> "isp_iq_ota_v$v.bin"
            else -> null
        }
    }

    fun versionToBytes(version: String): ByteArray? {
        val parts = version.trim().removePrefix("V").removePrefix("v").split(".")
        if (parts.size != 4) return null
        return try {
            byteArrayOf(
                parts[0].toInt().toByte(),
                parts[1].toInt().toByte(),
                parts[2].toInt().toByte(),
                parts[3].toInt().toByte(),
            )
        } catch (_: Exception) {
            null
        }
    }

    fun sha256Hex(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buf)
                if (read < 0) break
                digest.update(buf, 0, read)
            }
        }
        return digest.digest().joinToString("") { b ->
            String.format(Locale.US, "%02x", b)
        }
    }
}
