package com.fission.wear.glasses.sdk.ota.rtk

import android.content.Context
import android.os.Build
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.events.RtkSdkShareEvent
import com.fission.wear.glasses.sdk.rtk.RtkOtaErrors
import com.fission.wear.glasses.sdk.rtk.RtkSoftApErrors
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.realsil.sdk.audioconnect.smartwear.SmartWearConstants
import com.realsil.sdk.audioconnect.smartwear.SmartWearModelClient
import com.realsil.sdk.audioconnect.smartwear.SmartWearWifiClient
import com.realsil.sdk.dfu.DfuConstants
import com.realsil.sdk.dfu.DfuException
import com.realsil.sdk.dfu.model.BinParameters
import com.realsil.sdk.dfu.model.DfuConfig
import com.realsil.sdk.dfu.model.OtaDeviceInfo
import com.realsil.sdk.dfu.smartwear.SmartWearBinConfig
import com.realsil.sdk.dfu.utils.ConnectParams
import com.realsil.sdk.dfu.utils.DfuAdapter
import com.realsil.sdk.dfu.utils.SmartWearDfuAdapter
import com.realtek.sdk.core.net.wifi.RtkWifiAdapter
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile

/**
 * RTK SoftAP 推包 + SmartWearDfuAdapter 激活。
 * 支持：
 * 1) 旧单文件 [startOta]
 * 2) ZIP 解压目录（含 ota.json）[startOtaFromPackageDir] — 对齐 OTA 实现说明 V1.0.1
 */
class RtkOtaManager(
    private val appContext: Context,
    private val getDeviceAddress: () -> String,
    private val getSmartWearModelClient: () -> SmartWearModelClient?,
    private val getSmartApClient: () -> SmartWearWifiClient?,
    private val wifiAdapter: RtkWifiAdapter,
    private val getWifiSsid: () -> String,
    private val enableAp: suspend () -> Boolean,
    private val connectWiFi: suspend () -> Boolean,
    private val recoverNetworkHandle: (Boolean, Boolean) -> Unit,
    private val sendEvent: (RtkSdkShareEvent) -> Unit
) {
    private val TAG: String = "RtkOtaManager"
    private val DFU_PREPARED_TIMEOUT_MS = 30 * 1000L
    private val dfuPreparedLock = Any()
    private var dfuPreparedDeferred: CompletableDeferred<OtaDeviceInfo?>? = null
    private val dfuAdapter: SmartWearDfuAdapter = SmartWearDfuAdapter.getDfuAdapter(appContext)
    private val inDfu: AtomicBoolean = AtomicBoolean(false)
    private val smartWearBinConfig: SmartWearBinConfig = SmartWearBinConfig()
    private val dfuConfig: DfuConfig = DfuConfig()
    private var mOtaDeviceInfo: OtaDeviceInfo = OtaDeviceInfo()

    private val mDfuHelperCallback: SmartWearDfuAdapter.SmartWearDfuAdapterCallback =
        object : SmartWearDfuAdapter.SmartWearDfuAdapterCallback() {
            override fun onStateChanged(state: Int) {
                super.onStateChanged(state)
                FissionLogUtils.d(TAG, "OTA-> onStateChanged - state$state")
                when (state) {
                    DfuAdapter.STATE_PREPARED -> {
                        val otaDeviceInfo = dfuAdapter.otaDeviceInfo
                        mOtaDeviceInfo = otaDeviceInfo ?: OtaDeviceInfo()
                        completeDfuPrepared(otaDeviceInfo)
                        if (inDfu.get()) {
                            FissionLogUtils.v("device connected")
                            sendEvent(RtkSdkShareEvent.OtaStart)
                        }
                    }

                    else -> Unit
                }
            }

            override fun onError(type: Int, code: Int) {
                FissionLogUtils.d(TAG, "OTA-> onError - code : $code")
                completeDfuPrepared(null)
                if (inDfu.get()) {
                    onOtaTerminal()
                    if (code == DfuException.ERROR_DFU_PROCEDURE_CANCELED) {
                        sendEvent(RtkSdkShareEvent.OtaCancelled)
                    } else {
                        sendEvent(
                            RtkSdkShareEvent.OtaFailed(
                                "DFU error: $code",
                                RtkOtaErrors.CODE_DFU_PROCEDURE_FAILED,
                            ),
                        )
                    }
                }
            }

            override fun onProcessStateChanged(state: Int) {
                super.onProcessStateChanged(state)
                when (state) {
                    DfuConstants.PROGRESS_IMAGE_ACTIVE_SUCCESS -> {
                        if (inDfu.get()) {
                            onOtaTerminal()
                            sendEvent(RtkSdkShareEvent.OtaSuccess)
                        }
                    }
                    else -> Unit
                }
            }

            override fun onSmartWearProgressChanged(p0: SmartWearDfuAdapter.SmartWearDfuProgressInfo) {
                super.onSmartWearProgressChanged(p0)
                if (inDfu.get()) {
                    sendEvent(RtkSdkShareEvent.OtaProgress(p0.totalProgressValue, GlassesConstant.OTAStage.OTA))
                }
            }
        }

    init {
        dfuAdapter.initialize(mDfuHelperCallback)
    }

    suspend fun startOta(path: String, type: GlassesConstant.OtaType, versionName: String?) {
        if (versionName.isNullOrBlank()) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_PACKAGE_INVALID),
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        FissionLogUtils.v(TAG, ">>>>>>>>>> startOta type=$type version=$versionName")
        val otaFile = File(path)
        if (!otaFile.exists()) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_PACKAGE_INVALID),
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        val versionBytes = RtkOtaManifestParser.versionToBytes(versionName)
        if (versionBytes == null) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    "Invalid version number：$versionName",
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        if (!prepareDfuSession()) return
        if (!prepareSoftApAndWifi()) return

        inDfu.set(false)
        smartWearBinConfig.reset()
        var needActive = true
        when (type) {
            GlassesConstant.OtaType.FIRMWARE -> {
                smartWearBinConfig.btFirmwareEnabled = true
                smartWearBinConfig.btFirmwareVersion = versionBytes
                val ok = getSmartApClient()?.saveBtOtaFile(otaFile, versionName) ?: false
                needActive = ok
                dfuConfig.binParameters = BinParameters.Builder().filePath(otaFile.path).build()
            }
            GlassesConstant.OtaType.WIFI_ISP -> {
                smartWearBinConfig.wifiFirmwareEnabled = true
                smartWearBinConfig.wifiFirmwareVersion = versionBytes
                val remoteName = RtkOtaManifestParser.expectedFileName(
                    RtkOtaPackageItem.TYPE_WIFI,
                    versionName,
                ) ?: otaFile.name
                val ok = getSmartApClient()?.saveWiFiOtaFile(otaFile, remoteName) ?: false
                needActive = ok
            }
        }
        finishPushAndActivate(needActive)
    }

    /**
     * BT + WiFi 同时升级。
     * - BT：传入单个固件文件路径 + 版本号
     * - WiFi：传入压缩包路径（内含 ota.json），由 SDK 负责解压，按 [startOtaFromPackageDir] 方式推送解压目录内所有包
     * - 任一为 null 或空则跳过该部分，仅升级另一种
     *
     * @param btPath      BT 固件文件路径（null/空 = 不升 BT）
     * @param btVer       BT 固件版本号
     * @param wifiZipPath WiFi 固件压缩包路径（内含 ota.json，null/空 = 不升 WiFi）
     */
    suspend fun startOtaBoth(
        btPath: String?,
        btVer: String?,
        wifiZipPath: String?,
    ) {
        val hasBt = !btPath.isNullOrBlank() && !btVer.isNullOrBlank()
        val hasWifi = !wifiZipPath.isNullOrBlank()

        if (!hasBt && !hasWifi) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_PACKAGE_INVALID),
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }

        // ── BT 前置校验 ──
        val btFile = if (hasBt) File(btPath) else null
        if (hasBt && (btFile == null || !btFile.exists())) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_BT_FILE_NOT_FOUND),
                    RtkOtaErrors.CODE_BT_FILE_NOT_FOUND,
                ),
            )
            return
        }
        val btVersionBytes = if (hasBt) RtkOtaManifestParser.versionToBytes(btVer) else null
        if (hasBt && btVersionBytes == null) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    "Invalid BT version: $btVer",
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }

        // ── WiFi 前置校验（解压压缩包后复用 startOtaFromPackageDir 的 ota.json 解析逻辑）──
        var wifiManifest: RtkOtaManifest? = null
        var wifiPackageDir: File? = null
        if (hasWifi) {
            val zipFile = File(wifiZipPath)
            if (!zipFile.isFile) {
                sendEvent(
                    RtkSdkShareEvent.OtaFailed(
                        "WiFi OTA zip missing",
                        RtkOtaErrors.CODE_PACKAGE_INVALID,
                    ),
                )
                return
            }
            val workDir = extractWifiZip(zipFile)
            if (workDir == null) {
                sendEvent(
                    RtkSdkShareEvent.OtaFailed(
                        "WiFi zip extract fail",
                        RtkOtaErrors.CODE_PACKAGE_INVALID,
                    ),
                )
                return
            }
            val jsonFile = resolveOtaJson(workDir)
            if (jsonFile == null || !jsonFile.isFile) {
                sendEvent(
                    RtkSdkShareEvent.OtaFailed(
                        "WiFi zip: ota.json missing",
                        RtkOtaErrors.CODE_PACKAGE_INVALID,
                    ),
                )
                return
            }
            wifiPackageDir = jsonFile.parentFile ?: workDir
            try {
                wifiManifest = RtkOtaManifestParser.parse(jsonFile)
            } catch (e: Exception) {
                sendEvent(
                    RtkSdkShareEvent.OtaFailed(
                        "WiFi ota.json parse fail: ${e.message}",
                        RtkOtaErrors.CODE_PACKAGE_INVALID,
                    ),
                )
                return
            }
            val validateError = RtkOtaManifestParser.validate(wifiPackageDir, wifiManifest)
            if (validateError != null) {
                FissionLogUtils.w(TAG, "WiFi package validate fail: $validateError")
                sendEvent(
                    RtkSdkShareEvent.OtaFailed(
                        validateError,
                        RtkOtaErrors.CODE_PACKAGE_INVALID,
                    ),
                )
                return
            }
        }

        FissionLogUtils.v(TAG, ">>>>>>>>>> startOtaBoth hasBt=$hasBt hasWifi=$hasWifi btVer=$btVer wifiZip=$wifiZipPath")

        if (!prepareDfuSession()) return
        if (!prepareSoftApAndWifi()) return

        inDfu.set(false)
        smartWearBinConfig.reset()
        var needActive = true

        // ── Push BT bin ──
        if (hasBt) {
            smartWearBinConfig.btFirmwareEnabled = true
            smartWearBinConfig.btFirmwareVersion = btVersionBytes!!
            val btOk = getSmartApClient()?.saveBtOtaFile(btFile!!, btVer) ?: false
            if (!btOk) {
                needActive = false
                FissionLogUtils.w(TAG, "push BT bin failed")
            }
            dfuConfig.binParameters = BinParameters.Builder().filePath(btFile!!.path).build()
        }

        // ── Push WiFi packages（遍历 ota.json 声明的所有包）──
        if (needActive && hasWifi && wifiManifest != null) {
            val pkgDir = wifiPackageDir!!
            val total = wifiManifest.packages.size.coerceAtLeast(1)
            for ((index, pkg) in wifiManifest.packages.withIndex()) {
                val bin = File(pkgDir, pkg.file)
                FissionLogUtils.d(TAG, "push WiFi package ${index + 1}/$total type=${pkg.type} file=${pkg.file} version=${pkg.version}")
                sendEvent(
                    RtkSdkShareEvent.OtaProgress(
                        ((index * 100) / total).coerceIn(0, 99),
                        GlassesConstant.OTAStage.VERIFY,
                    ),
                )
                val ok = pushPackage(pkg, bin)
                if (!ok) {
                    needActive = false
                    FissionLogUtils.w(TAG, "push WiFi package failed: ${pkg.file}")
                    break
                }
            }
            if (needActive) {
                sendEvent(RtkSdkShareEvent.OtaProgress(100, GlassesConstant.OTAStage.VERIFY))
            }
        }

        finishPushAndActivate(needActive)
    }

    /**
     * 从已解压目录执行完整 ZIP OTA（目录内必须有 ota.json 与声明的 bin）。
     */
    suspend fun startOtaFromPackageDir(extractedDirPath: String) {
        FissionLogUtils.v(TAG, ">>>>>>>>>> startOtaFromPackageDir $extractedDirPath")
        val workDir = File(extractedDirPath)
        if (!workDir.isDirectory) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    "OTA package dir missing",
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        val jsonFile = resolveOtaJson(workDir)
        if (jsonFile == null || !jsonFile.isFile) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    "ota.json missing",
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        val packageDir = jsonFile.parentFile ?: workDir
        val manifest = try {
            RtkOtaManifestParser.parse(jsonFile)
        } catch (e: Exception) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    "ota.json parse fail: ${e.message}",
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        val validateError = RtkOtaManifestParser.validate(packageDir, manifest)
        if (validateError != null) {
            FissionLogUtils.w(TAG, "OTA package validate fail: $validateError")
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    validateError,
                    RtkOtaErrors.CODE_PACKAGE_INVALID,
                ),
            )
            return
        }
        FissionLogUtils.d(
            TAG,
            "OTA package ok dir=${packageDir.absolutePath} total=${manifest.totalVersion} " +
                "mode=${manifest.mode} pkgs=${manifest.packages.size}",
        )

        sendEvent(RtkSdkShareEvent.OtaProgress(0, GlassesConstant.OTAStage.VERIFY))
        if (!prepareDfuSession()) return
        if (!prepareSoftApAndWifi()) return

        inDfu.set(false)
        smartWearBinConfig.reset()
        val total = manifest.packages.size.coerceAtLeast(1)
        var needActive = true
        for ((index, pkg) in manifest.packages.withIndex()) {
            val bin = File(packageDir, pkg.file)
            FissionLogUtils.d(TAG, "push package ${index + 1}/$total type=${pkg.type} file=${pkg.file} version: ${pkg.version}")
            sendEvent(
                RtkSdkShareEvent.OtaProgress(
                    ((index * 100) / total).coerceIn(0, 99),
                    GlassesConstant.OTAStage.VERIFY,
                ),
            )
            val ok = pushPackage(pkg, bin)
            if (!ok) {
                needActive = false
                FissionLogUtils.w(TAG, "push package failed: ${pkg.file}")
                break
            }
        }
        if (needActive) {
            sendEvent(RtkSdkShareEvent.OtaProgress(100, GlassesConstant.OTAStage.VERIFY))
        }
        finishPushAndActivate(needActive)
    }

    private fun pushPackage(pkg: RtkOtaPackageItem, bin: File): Boolean {
        val client = getSmartApClient() ?: return false
        return when (pkg.type) {
            RtkOtaPackageItem.TYPE_WIFI -> {
                val versionBytes = RtkOtaManifestParser.versionToBytes(pkg.version) ?: return false
                smartWearBinConfig.wifiFirmwareEnabled = true
                smartWearBinConfig.wifiFirmwareVersion = versionBytes
                client.saveWiFiOtaFile(bin, pkg.file)
            }
            RtkOtaPackageItem.TYPE_BOOT -> {
                smartWearBinConfig.wifiBootLoaderEnabled = true
                client.saveWiFiOtaFile(bin, pkg.file)
            }
            RtkOtaPackageItem.TYPE_NN -> {
                smartWearBinConfig.wifiNnLoaderEnabled = true
                client.saveWiFiOtaFile(bin, pkg.file)
            }
            RtkOtaPackageItem.TYPE_ISP_IQ -> {
                smartWearBinConfig.wifiIspIqEnabled = true
                client.saveWiFiOtaFile(bin, pkg.file)
            }
            else -> false
        }
    }

    private suspend fun prepareDfuSession(): Boolean {
        val deviceAddress = getDeviceAddress()
        if (deviceAddress.isBlank()) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_DEVICE_ADDRESS_EMPTY),
                    RtkOtaErrors.CODE_DEVICE_ADDRESS_EMPTY,
                ),
            )
            return false
        }
        val deferred = createDfuPreparedDeferred()
        val connectResult = dfuAdapter.connectDevice(
            ConnectParams.Builder().address(deviceAddress).build(),
        )
        if (!connectResult) {
            clearDfuPreparedDeferred(deferred)
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_DFU_CONNECT_FAILED),
                    RtkOtaErrors.CODE_DFU_CONNECT_FAILED,
                ),
            )
            return false
        }
        val otaDeviceInfo = withTimeoutOrNull(DFU_PREPARED_TIMEOUT_MS) { deferred.await() }
        clearDfuPreparedDeferred(deferred)
        if (otaDeviceInfo == null) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_DFU_PREPARE_FAILED),
                    RtkOtaErrors.CODE_DFU_PREPARE_FAILED,
                ),
            )
            return false
        }
        mOtaDeviceInfo = otaDeviceInfo
        return true
    }

    private suspend fun prepareSoftApAndWifi(): Boolean {
        FissionLogUtils.v(TAG, "Step 1: enable AP")
        if (!enableAp()) {
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkSoftApErrors.defaultReason(RtkSoftApErrors.CODE_AP_ENABLE_FAILED),
                    RtkSoftApErrors.CODE_AP_ENABLE_FAILED,
                ),
            )
            return false
        }
        FissionLogUtils.v(TAG, "Step 2: connect wifi")
        if (!connectWiFi()) {
            releaseOtaNetworkResources(fullCleanup = true)
            getSmartWearModelClient()?.setWifiModule(SmartWearConstants.WifiMode.WIFI_MODE_IDLE_OTA)
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkSoftApErrors.defaultReason(RtkSoftApErrors.CODE_WIFI_JOIN_FAILED),
                    RtkSoftApErrors.CODE_WIFI_JOIN_FAILED,
                ),
            )
            return false
        }
        return true
    }

    private fun finishPushAndActivate(needActive: Boolean) {
        if (!needActive) {
            FissionLogUtils.v("Step 5: disable AP")
            releaseOtaNetworkResources(fullCleanup = true)
            getSmartWearModelClient()?.setWifiModule(SmartWearConstants.WifiMode.WIFI_MODE_IDLE)
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_PUSH_FAILED),
                    RtkOtaErrors.CODE_PUSH_FAILED,
                ),
            )
            return
        }

        val needsWifiChannel = smartWearBinConfig.wifiFirmwareEnabled
            || smartWearBinConfig.wifiBootLoaderEnabled
            || smartWearBinConfig.wifiIspIqEnabled
            || smartWearBinConfig.wifiNnLoaderEnabled

        // 仅蓝牙包：先断 SoftAP 再激活（既有稳定路径）
        // WiFi/整包：激活完成前保持 SoftAP，避免 DFU(SPP+WiFi) 通道被掐断后无 Success
        if (!needsWifiChannel) {
            FissionLogUtils.v("Step 5: disable AP (BT-only, before activate)")
            releaseOtaNetworkResources(fullCleanup = false)
        } else {
            FissionLogUtils.v("Step 5: keep SoftAP until WiFi package activate done")
        }

        getSmartWearModelClient()?.setWifiModule(SmartWearConstants.WifiMode.WIFI_MODE_IDLE_OTA)
        FissionLogUtils.v("Step 6: active image: $smartWearBinConfig")
        inDfu.set(true)
        dfuConfig.isAutomaticActiveEnabled = true
        dfuConfig.isBatteryCheckEnabled = false
        dfuConfig.channelType = DfuConfig.CHANNEL_TYPE_SPP_AND_WIFI
        dfuConfig.address = getDeviceAddress()
        dfuConfig.primaryMtuSize = 256

        val ret = dfuAdapter.startOtaProcedure(dfuConfig, mOtaDeviceInfo, false, smartWearBinConfig)
        if (!ret) {
            FissionLogUtils.w("startOtaProcess failed")
            inDfu.set(false)
            releaseOtaNetworkResources(fullCleanup = true)
            sendEvent(
                RtkSdkShareEvent.OtaFailed(
                    RtkOtaErrors.defaultReason(RtkOtaErrors.CODE_ACTIVATE_FAILED),
                    RtkOtaErrors.CODE_ACTIVATE_FAILED,
                ),
            )
        } else {
            inDfu.set(true)
            sendEvent(RtkSdkShareEvent.OtaStart)
        }
    }

    /**
     * 释放 OTA 占用的 SoftAP / Wi‑Fi 资源。
     *
     * @param fullCleanup true：断开手机与眼镜 AP、关热点（OTA 结束/失败）；
     *                    false：仅更新 SDK 连接状态（BT-only 激活前暂断 SoftAP，激活仍走 SPP）。
     */
    private fun releaseOtaNetworkResources(fullCleanup: Boolean) {
        if (fullCleanup) {
            recoverNetworkHandle(true, true)
            return
        }

        runCatching { wifiAdapter.updateWifiConnectionState(false) }
            .onFailure { FissionLogUtils.w(TAG, "releaseOtaNetwork updateWifiConnectionState: ${it.message}") }
    }

    private fun onOtaTerminal() {
        inDfu.set(false)
        releaseOtaNetworkResources(fullCleanup = true)
        runCatching {
            getSmartWearModelClient()?.setWifiModule(SmartWearConstants.WifiMode.WIFI_MODE_IDLE)
        }
    }

    fun stopOta() {
        dfuAdapter.abort()
    }

    fun isOtaInProgress(): Boolean = inDfu.get()

    private fun createDfuPreparedDeferred(): CompletableDeferred<OtaDeviceInfo?> {
        val deferred = CompletableDeferred<OtaDeviceInfo?>()
        synchronized(dfuPreparedLock) {
            dfuPreparedDeferred = deferred
        }
        return deferred
    }

    private fun completeDfuPrepared(otaDeviceInfo: OtaDeviceInfo?) {
        synchronized(dfuPreparedLock) {
            dfuPreparedDeferred
        }?.complete(otaDeviceInfo)
    }

    private fun clearDfuPreparedDeferred(deferred: CompletableDeferred<OtaDeviceInfo?>) {
        synchronized(dfuPreparedLock) {
            if (dfuPreparedDeferred === deferred) {
                dfuPreparedDeferred = null
            }
        }
    }

    /**
     * 解压 WiFi OTA 压缩包到应用缓存目录，返回解压根目录；解压失败返回 null。
     * 解压目录固定为 cacheDir/rtk_ota_wifi/<压缩包名（去扩展名）>，重复升级会先清理旧目录。
     */
    private fun extractWifiZip(zipFile: File): File? {
        val targetDir = File(File(appContext.cacheDir, "rtk_ota_wifi"), zipFile.nameWithoutExtension)
        return try {
            if (targetDir.exists()) targetDir.deleteRecursively()
            targetDir.mkdirs()
            val canonicalRoot = targetDir.canonicalPath + File.separator
            ZipFile(zipFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val outFile = File(targetDir, entry.name)
                    // Zip Slip 防护：拒绝解压到目标目录之外
                    if (!outFile.canonicalPath.startsWith(canonicalRoot)) {
                        throw SecurityException("Illegal zip entry: ${entry.name}")
                    }
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        zip.getInputStream(entry).use { input ->
                            FileOutputStream(outFile).use { output -> input.copyTo(output) }
                        }
                    }
                }
            }
            FissionLogUtils.d(TAG, "WiFi zip extracted to ${targetDir.absolutePath}")
            targetDir
        } catch (e: Exception) {
            FissionLogUtils.w(TAG, "extract WiFi zip fail: ${e.message}")
            targetDir.deleteRecursively()
            null
        }
    }

    /** 兼容根目录或 ZIP 内单层子目录（如 AG188OTA/ota.json）。 */
    private fun resolveOtaJson(root: File): File? {
        val direct = File(root, "ota.json")
        if (direct.isFile) return direct
        return root.walkTopDown()
            .maxDepth(3)
            .filter { it.isFile && it.name.equals("ota.json", ignoreCase = true) }
            .sortedBy { it.absolutePath }
            .firstOrNull()
    }
}
