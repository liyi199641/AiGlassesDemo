package com.fission.wear.glasses.sdk.rtk.protocol

import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ActionSyncType

fun GlassesConstant.LedBrightnessLevel.toRtkCustomBrightness(): Int = when (this) {
    GlassesConstant.LedBrightnessLevel.LOW -> 0x00
    GlassesConstant.LedBrightnessLevel.MEDIUM -> 0x01
    GlassesConstant.LedBrightnessLevel.HIGH -> 0x02
}

fun rtkCustomBrightnessToLy(value: Int): GlassesConstant.LedBrightnessLevel? = when (value) {
    0x00 -> GlassesConstant.LedBrightnessLevel.LOW
    0x01 -> GlassesConstant.LedBrightnessLevel.MEDIUM
    0x02 -> GlassesConstant.LedBrightnessLevel.HIGH
    else -> null
}

fun rtkCustomSwitchToBoolean(value: Int): Boolean? = when (value) {
    0x00 -> false
    0x01 -> true
    else -> null
}

fun booleanToRtkCustomSwitch(enabled: Boolean): Byte =
    if (enabled) 0x01 else 0x00

fun enableStateToRtkCustomSwitch(state: GlassesConstant.EnableState): Byte =
    when(state){
        GlassesConstant.EnableState.ON  -> 0x00
        GlassesConstant.EnableState.OFF -> 0x01
    }

fun GlassesConstant.ScreenOrientation.toRtkShootingDirection(): Int = when (this) {
    GlassesConstant.ScreenOrientation.PORTRAIT -> 0x00
    GlassesConstant.ScreenOrientation.LANDSCAPE -> 0x01
}

fun rtkShootingDirectionToLy(value: Int): GlassesConstant.ScreenOrientation? = when (value) {
    0x00 -> GlassesConstant.ScreenOrientation.PORTRAIT
    0x01 -> GlassesConstant.ScreenOrientation.LANDSCAPE
    0x02, 0x03 -> null
    else -> null
}

fun intToUint16LeBytes(value: Int): ByteArray {
    val v = value and 0xFFFF
    return byteArrayOf((v and 0xFF).toByte(), (v shr 8).toByte())
}

fun parseUint16Le(payload: ByteArray?, offset: Int): Int {
    if (payload == null || payload.size <= offset + 1) return -1
    return (payload[offset].toInt() and 0xFF) or ((payload[offset + 1].toInt() and 0xFF) shl 8)
}

fun rtkWearingStatusToActionSyncActive(status: Int): Boolean? = when (status) {
    0x00 -> false
    0x01 -> true
    else -> null
}

fun rtkPhotoStatusToActionSyncActive(status: Int): Boolean? = when (status) {
    0x01 -> true
    0x00, 0x02, 0x03 -> false
    else -> null
}

fun rtkRecordingStatusToActionSyncActive(status: Int): Boolean? = when (status) {
    0x01, 0x02, 0x03 -> true
    0x00 -> false
    else -> null
}

/** 触摸板手势完成时映射为 LY 侧 [ActionSyncType] 一次性动作。 */
fun rtkTouchpadGestureToActionSync(gestureType: Int, action: Int): Pair<ActionSyncType, Boolean>? {
    if (action != 0x00) return null
    return when (gestureType) {
        0x00 -> ActionSyncType.SINGLE_TOUCH to true
        0x04 -> ActionSyncType.VOLUME_UP to true
        0x05 -> ActionSyncType.VOLUME_DOWN to true
        else -> null
    }
}
