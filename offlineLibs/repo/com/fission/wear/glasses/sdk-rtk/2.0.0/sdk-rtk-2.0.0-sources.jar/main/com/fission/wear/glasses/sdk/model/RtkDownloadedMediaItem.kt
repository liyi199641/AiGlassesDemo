package com.fission.wear.glasses.sdk.model

import com.fission.wear.glasses.sdk.rtk.RtkSyncedMediaClassifier.SyncedMediaKind
import com.realsil.sdk.audioconnect.smartwear.MediaListItem
import java.io.File

/** HTTP 下载落盘后的原始媒体项，尚未做畸变/降噪或格式转换。 */
data class RtkDownloadedMediaItem(
    val media: MediaListItem,
    val mediaKind: SyncedMediaKind,
    val localFile: File,
    val fileIndex: Int,
)

/** 后处理完成、可供上层展示/入库的导出结果。 */
data class RtkMediaExportResult(
    val exportFile: File,
    val mediaName: String,
    val fileIndex: Int,
)
