package com.fission.wear.glasses.sdk.util

import android.content.Context
import com.fission.wear.glasses.sdk.model.RtkDownloadedMediaItem
import com.fission.wear.glasses.sdk.rtk.RtkSmartWearWifiClientFactory
import com.fission.wear.glasses.sdk.rtk.RtkSyncedMediaClassifier
import com.fission.wear.glasses.sdk.rtk.RtkSyncedMediaClassifier.SyncedMediaKind
import com.realsil.sdk.audioconnect.smartwear.MediaImportConfigure
import com.realsil.sdk.audioconnect.smartwear.MediaListData
import com.realsil.sdk.audioconnect.smartwear.MediaListItem
import com.realsil.sdk.audioconnect.smartwear.SmartWearWifiClient
import com.realsil.sdk.core.utility.StringUtils
import java.io.File

/**
 * RTK 媒体 HTTP 下载器（对齐官方 Demo [GalleryDownloader]）：
 * - 内部独立 [SmartWearWifiClient]，与 ping-pong client 分离
 * - **仅负责** 拉取媒体列表与文件落盘；不做畸变/降噪/格式转换
 * - 后处理由 [RtkMediaExportQueue] 流水线或批量队列执行
 */
class GalleryDownloader(
    context: Context,
    var pictureDir: String = "",
    var videoDir: String = "",
    originalPictureDir: String = "",
    correctedPictureDir: String = "",
    private val ipAddress: String = DEFAULT_IP,
) {

    /** 同步 JPG 原图目录（未做畸变校正）。 */
    val originalPictureDir: String = originalPictureDir.ifBlank {
        if (pictureDir.isNotEmpty()) "$pictureDir/${SUBDIR_ORIGINAL}" else ""
    }

    /** 广角镜头畸变校正输出目录（供 [RtkMediaExportQueue] 使用）。 */
    val correctedPictureDir: String = correctedPictureDir.ifBlank {
        if (pictureDir.isNotEmpty()) "$pictureDir/${SUBDIR_CORRECTED}" else pictureDir
    }

    private val appContext = context.applicationContext

    /** 与官方 Demo 一致：下载专用 client，不复用 connectWiFi 时的 ping-pong client。 */
    private val downloadWifiClient: SmartWearWifiClient =
        RtkSmartWearWifiClientFactory.create(appContext, ipAddress)

    init {
        if (this.originalPictureDir.isNotEmpty()) {
            File(this.originalPictureDir).mkdirs()
        }
        if (this.correctedPictureDir.isNotEmpty()) {
            File(this.correctedPictureDir).mkdirs()
        }
    }

    @Volatile
    private var downloadAborted = true

    /**
     * 连续下载全部可用媒体；返回原始落盘列表，**不**回调上层成功事件。
     */
    fun downloadMediaFiles(
        ipAddress: String = this.ipAddress,
        onPrepared: (Int) -> Unit = {},
        onStarted: () -> Unit = {},
        onProgress: (Int) -> Unit = {},
        /** 单项 HTTP 落盘完成即回调，用于与 [RtkMediaExportQueue] 流水线并行。 */
        onItemDownloaded: (RtkDownloadedMediaItem) -> Unit = {},
    ): List<RtkDownloadedMediaItem> {
        if (StringUtils.isEmpty(ipAddress)) {
            FissionLogUtils.w("Invalid URL host:$ipAddress")
            return emptyList()
        }
        downloadAborted = false

        val mediaListData = downloadWifiClient.downloadMediaList()
        if (mediaListData.contents.isEmpty()) {
            downloadAborted = true
            return emptyList()
        }

        FissionLogUtils.d("wl", "rtk----Step 4: HTTP download only")
        val downloadTryTimes = 3
        val gallery8735MediaAutoDeleteEnabled = false
        val gallery8735MediaTimeStampSyncEnabled = false

        val availableMediaListItem = mediaListData.availableMediaListItem()
        onPrepared(availableMediaListItem.size)

        val downloaded = mutableListOf<RtkDownloadedMediaItem>()
        for ((fileIndex, media) in availableMediaListItem.withIndex()) {
            if (downloadAborted) {
                FissionLogUtils.v("$ipAddress download aborted")
                break
            }
            val mediaKind = RtkSyncedMediaClassifier.classify(media.name)
            val mediaImportConfigureBuilder = MediaImportConfigure.Builder()
                .retryTimes(downloadTryTimes)
                .assembleNameEnabled(true)
                .autoDeleteEnabled(gallery8735MediaAutoDeleteEnabled)
                .timeStampSyncEnabled(gallery8735MediaTimeStampSyncEnabled)

            when (mediaKind) {
                SyncedMediaKind.IMAGE -> {
                    val jpgSaveDir = originalPictureDir.ifEmpty { pictureDir }
                    mediaImportConfigureBuilder.folderPath(jpgSaveDir)
                }

                SyncedMediaKind.VIDEO, SyncedMediaKind.AUDIO -> {
                    mediaImportConfigureBuilder.folderPath(videoDir)
                }

                SyncedMediaKind.UNKNOWN -> continue
            }

            onStarted()
            val path = downloadWifiClient.downloadMediaFileCompat(
                media,
                mediaImportConfigureBuilder.build(),
            ) {
                if (downloadAborted) return@downloadMediaFileCompat
                onProgress((it * 100).toInt())
            }
            if (downloadAborted) break
            if (StringUtils.isEmpty(path)) continue
            val localFile = File(path)
            if (!localFile.exists()) continue
            val item = RtkDownloadedMediaItem(
                media = media,
                mediaKind = mediaKind,
                localFile = localFile,
                fileIndex = fileIndex,
            )
            downloaded.add(item)
            onItemDownloaded(item)
        }

        FissionLogUtils.d("wl", "rtk----HTTP download complete, count=${downloaded.size}")
        downloadAborted = true
        return downloaded
    }

    fun stopDownloadProcedure() {
        FissionLogUtils.v("stopDownloadProcedure")
        downloadAborted = true
        downloadWifiClient.cancelDownloadFile()
    }

    companion object {
        const val DEFAULT_IP = "192.168.43.1"
        const val SUBDIR_ORIGINAL = "original"
        const val SUBDIR_CORRECTED = "corrected"
    }
}

fun MediaListData.availableMediaListItem(): ArrayList<MediaListItem> {
    val result = ArrayList<MediaListItem>()
    for (media in contents) {
        when (RtkSyncedMediaClassifier.classify(media.name)) {
            SyncedMediaKind.IMAGE,
            SyncedMediaKind.VIDEO,
            SyncedMediaKind.AUDIO -> result.add(media)
            SyncedMediaKind.UNKNOWN -> Unit
        }
    }
    return result
}
