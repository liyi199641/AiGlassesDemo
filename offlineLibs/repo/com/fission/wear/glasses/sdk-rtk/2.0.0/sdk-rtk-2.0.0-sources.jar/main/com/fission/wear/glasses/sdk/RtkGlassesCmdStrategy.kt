package com.fission.wear.glasses.sdk

import android.content.Context
import com.blankj.utilcode.util.LogUtils
import com.fission.wear.glasses.sdk.config.BleComConfig
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ActionSyncType
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_IMAGE_RECOGNITION
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ERROR_CODE_IMAGE_SAVE
import com.fission.wear.glasses.sdk.data.cache.GlassesSpUtil
import com.fission.wear.glasses.sdk.data.dto.DeviceSettingsStateDTO
import com.fission.wear.glasses.sdk.data.dto.DeviceVersionInfoDTO
import com.fission.wear.glasses.sdk.data.model.BaseWsMessage
import com.fission.wear.glasses.sdk.data.model.LifePhotoConfig
import com.fission.wear.glasses.sdk.data.model.LiveStreamingConfig
import com.fission.wear.glasses.sdk.data.model.McpData
import com.fission.wear.glasses.sdk.data.model.WifiApConfig
import com.fission.wear.glasses.sdk.events.AgentEvent
import com.fission.wear.glasses.sdk.events.AiAssistantEvent
import com.fission.wear.glasses.sdk.events.AudioStateEvent
import com.fission.wear.glasses.sdk.events.AudioStateEvent.ReceivingAudioData
import com.fission.wear.glasses.sdk.events.CmdResultEvent
import com.fission.wear.glasses.sdk.events.CmdResultEvent.Fail
import com.fission.wear.glasses.sdk.events.CmdResultEvent.MediaFileCount
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent.Connected
import com.fission.wear.glasses.sdk.events.ConnectionStateEvent.Disconnected
import com.fission.wear.glasses.sdk.events.FileSyncEvent
import com.fission.wear.glasses.sdk.events.FileSyncEvent.BatchDownloadFinished
import com.fission.wear.glasses.sdk.events.FileSyncEvent.DownloadProgress
import com.fission.wear.glasses.sdk.events.FileSyncEvent.DownloadSuccess
import com.fission.wear.glasses.sdk.events.GlassesCmdStrategy
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.events.LiveEvent
import com.fission.wear.glasses.sdk.events.OTAEvent
import com.fission.wear.glasses.sdk.events.RtkSdkShareEvent
import com.fission.wear.glasses.sdk.manager.RtkSdkManager
import com.fission.wear.glasses.sdk.util.BluetoothUnpairHelper
import com.fission.wear.glasses.sdk.rtk.RtkMediaImportStateSimulator
import com.fission.wear.glasses.sdk.rtk.protocol.rtkCustomBrightnessToLy
import com.fission.wear.glasses.sdk.rtk.protocol.rtkPhotoStatusToActionSyncActive
import com.fission.wear.glasses.sdk.rtk.protocol.rtkRecordingStatusToActionSyncActive
import com.fission.wear.glasses.sdk.rtk.protocol.rtkShootingDirectionToLy
import com.fission.wear.glasses.sdk.rtk.protocol.rtkTouchpadGestureToActionSync
import com.fission.wear.glasses.sdk.rtk.protocol.rtkWearingStatusToActionSyncActive
import com.fission.wear.glasses.sdk.state.SdkBleConnectionState
import com.fission.wear.glasses.sdk.util.FissionLogUtils
import com.realsil.sdk.audioconnect.smartwear.ActionStateNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.collections.isNotEmpty

/**
 * describe:
 * author: wl
 * createTime: 2025/10/9
 */
class RtkGlassesCmdStrategy(
    private val context: Context,
    private val eventBus: MutableSharedFlow<GlassesEvent>,
    private val scope: CoroutineScope,
    private val sdkConfig: SdkConfig,
) : GlassesCmdStrategy {

    private val TAG = "RtkGlassesCmdStrategy"
    private var mDeviceAddress: String? = null
    private var mRtkSdkManager: RtkSdkManager = RtkSdkManager(context, scope, sdkConfig)
    private var aiAssistantBridgeJob: Job? = null
    /** AI 录音中（对齐 LY isAiRecording）。 */
    private var isAiRecording = false
    /** 与 LY lastActionStates 对齐，避免重复上报且保证状态切换可见。 */
    private val lastActionSyncStates = mutableMapOf<ActionSyncType, Boolean>()
    /** RTK 无固件导入状态位，媒体同步期间仿造 LY IMPORTING 动作同步。 */
    private val mediaImportStateSimulator = RtkMediaImportStateSimulator { type, active ->
        emitActionSyncIfChanged(type, active)
    }

    init {
        scope.launch {
            mRtkSdkManager.rtkEvent.collect { event ->
                when (event) {
                    is RtkSdkShareEvent.Connected                        -> {
                        emitEvent(Connected(event.device, event.isOtaMode))
                    }

                    is RtkSdkShareEvent.Connecting                       -> {
                        emitEvent(ConnectionStateEvent.Connecting)
                    }

                    is RtkSdkShareEvent.Disconnected                     -> {
                        emitDisconnected()
                    }

                    is RtkSdkShareEvent.OnSmartWearDeviceInitFail        -> {
                        emitDisconnected()
                    }

                    is RtkSdkShareEvent.OnActionStateNotificationChanged -> {
                        val notification = event.p0
                        val type = when (notification.action) {
                            ActionStateNotification.ACTION_SNAP_SHOT -> ActionSyncType.TAKE_PHOTO
                            ActionStateNotification.ACTION_RECORD_VIDEO -> ActionSyncType.RECORD_VIDEO
                            ActionStateNotification.ACTION_AI_VOICE -> ActionSyncType.RECORD_AUDIO
                            else -> return@collect
                        }
                        val active = (notification.state.toInt() and 0xFF) == 0x01
                        emitActionSyncIfChanged(type, active)
                    }
                    is RtkSdkShareEvent.OnDeviceTriggeredTakePhoto       -> {}
                    is RtkSdkShareEvent.OnFileStorageInfoChanged         -> {
                        emitEvent(MediaFileCount(event.fileStorageInfo.snapshotFileCount + event.fileStorageInfo.videoFileCount))
                    }

                    is RtkSdkShareEvent.OnDeviceCapacityInfo             -> {
                        emitEvent(CmdResultEvent.DeviceCapacityInfoEvent(event.data))
                    }

                    is RtkSdkShareEvent.OnReceivedLiveStreamingData      -> {}
                    is RtkSdkShareEvent.OnStartReceiveUserVoice          -> {
                        FissionLogUtils.d(TAG, "AI录音开始")
                        if (AiAssistantClient.getInstance().isListenBlockedByWsReconnect()) {
                            FissionLogUtils.w(TAG, "WS 重连中，禁止开听，通知眼镜停麦")
                            stopVadAudio()
                            return@collect
                        }
                        isAiRecording = true
                        AiAssistantClient.getInstance().notifyDeviceDialogueRecordingStarted()
                        emitEvent(AudioStateEvent.StartRecording)
                        startReceivingAudio(
                            vendorVoiceChatListenMode(),
                            AiAssistantClient.getInstance().getAiDialogueLanguage(),
                        )
                    }

                    is RtkSdkShareEvent.OnReceivedUserVoice              -> {
                        emitEvent(ReceivingAudioData(event.voiceData.toList()))
                        sendReceivingAudioData(vendorVoiceChatListenMode(), event.voiceData)
                    }

                    is RtkSdkShareEvent.OnStopReceiveUserVoice           -> {
                        // 对齐 LY VAD_STOP：仅通知取消录音，上行停流由本地 VAD 负责
                        FissionLogUtils.d(TAG, "AI录音停止")
                        isAiRecording = false
                        AiAssistantClient.getInstance().notifyDeviceDialogueCancelled()
                        GlassesManage.interruptAiAssistant()
                        emitEvent(AudioStateEvent.CancelRecording)
                    }

                    is RtkSdkShareEvent.OnSmartWearDeviceInitSuccess     -> {
                        emitEvent(ConnectionStateEvent.DeviceReady)
                    }

                    is RtkSdkShareEvent.OnStateChanged                   -> {}
                    is RtkSdkShareEvent.OnSyncConnectSuccess              -> {
                        emitEvent(FileSyncEvent.ConnectSuccess)
                    }

                    is RtkSdkShareEvent.OnSyncFileFail                   -> {
                        mediaImportStateSimulator.onMediaSyncFinished()
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(FileSyncEvent.Failed(event.msg, event.code))
                    }

                    is RtkSdkShareEvent.OnSyncFileProgress               -> {
                        // curFileIndex 已为 0-based，与 LY 一致
                        emitEvent(DownloadProgress(event.progress, event.curFileIndex, event.totalFileCount, ""))
                    }

                    is RtkSdkShareEvent.OnSyncFileSuccess                -> {
                        emitEvent(
                            DownloadSuccess(
                                event.filePath,
                                event.curFileIndex,
                                event.totalFileCount,
                                "",
                                event.fileSizeInBytes,
                                event.fileModifiedTime,
                                event.filePath,
                            ),
                        )
                    }

                    is RtkSdkShareEvent.OnSyncBatchDownloadFinished      -> {
                        mediaImportStateSimulator.onMediaSyncFinished()
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(
                            BatchDownloadFinished(
                                successCount = event.successCount,
                                totalFileCount = event.totalFileCount,
                            )
                        )
                    }

                    is RtkSdkShareEvent.OnTakePhotoFail                  -> {
                        emitEvent(Fail("图片保存或AI识别异常", ERROR_CODE_IMAGE_SAVE))
                    }

                    is RtkSdkShareEvent.OnLifePhotoConfigResult          -> {
                        emitEvent(CmdResultEvent.LifePhotoConfigResult(event.success))
                    }

                    is RtkSdkShareEvent.OnWifiApConfigResult             -> {
                        emitEvent(CmdResultEvent.WifiApConfigResult(event.success))
                    }

                    is RtkSdkShareEvent.OnTakePhotoSuccess               -> {
                        if (event.imgFiles.isNotEmpty()) {
                            emitEvent(CmdResultEvent.ImageFile(event.imgFiles[0].photoFile))
                            val isAiImageRecognitionStarted =
                                AiAssistantClient.getInstance()
                                    .aiImageRecognition(event.imgFiles[0].photoFile.absolutePath)
                            if (!isAiImageRecognitionStarted) {
                                FissionLogUtils.d("clx", "AI识图缺少MCP消息")
                                emitEvent(Fail("AI识图缺少MCP消息", ERROR_CODE_IMAGE_RECOGNITION))
                            }
                        }
                    }

                    is RtkSdkShareEvent.OnWifiApStateChanged             -> {
                        val info = event.wifiApInfo
                        if (info.isOk && !info.ssid.isNullOrBlank()) {
                            emitEvent(LiveEvent.WifiApReady(info.ssid, info.password.orEmpty()))
                        }
                    }
                    is RtkSdkShareEvent.CustomProtocolWifiApStatusChanged -> {
                        emitEvent(LiveEvent.WifiApStatusChanged(event.enabled))
                    }
                    is RtkSdkShareEvent.OnWifiStaStateChanged            -> {}
                    is RtkSdkShareEvent.RespFailed                       -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(LiveEvent.Failed(event.reason,event.code))
                    }
                    RtkSdkShareEvent.RespStop                            -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(LiveEvent.RespStop)
                    }
                    RtkSdkShareEvent.LiveStoppedByNotification         -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(LiveEvent.StoppedByNotification)
                    }
                    is RtkSdkShareEvent.RespSuccess                      -> {
                        emitEvent(LiveEvent.RespSuccess(event.rtsp))
                    }

                    RtkSdkShareEvent.PreviewStarted                      -> {
                        emitEvent(LiveEvent.PreviewStarted)
                    }

                    is RtkSdkShareEvent.PreviewFailed                    -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(LiveEvent.PreviewFailed(event.reason, event.code))
                    }

                    is RtkSdkShareEvent.LiveDisconnected               -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(LiveEvent.Disconnected(event.reason, event.code))
                    }

                    RtkSdkShareEvent.OtaIdle                             -> {
                        emitEvent(OTAEvent.Idle)
                    }

                    RtkSdkShareEvent.OtaStart                            -> {
                        emitEvent(OTAEvent.Start)
                    }

                    is RtkSdkShareEvent.OtaEnterOTAMode                  -> {
//                        emitEvent(OTAEvent.EnterOTAMode(event.macAddress))
                    }

                    is RtkSdkShareEvent.OtaProgress                      -> {
                        emitEvent(OTAEvent.Progress(event.percent, event.type))
                    }

                    RtkSdkShareEvent.OtaSuccess                          -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(OTAEvent.Success)
                    }

                    is RtkSdkShareEvent.OtaFailed                        -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(OTAEvent.Failed(event.reason, event.code))
                    }

                    RtkSdkShareEvent.OtaCancelled                        -> {
                        endAssistantAfterWifiExclusiveSession()
                        emitEvent(OTAEvent.Cancelled)
                    }

                    is RtkSdkShareEvent.OtaDeviceRebooting               -> {
                        emitEvent(OTAEvent.DeviceRebooting(event.remainSec))
                    }

                    is RtkSdkShareEvent.DevicePower -> {
                        emitEvent(CmdResultEvent.DevicePower(event.value, event.isCharging))
                    }

                    is RtkSdkShareEvent.CustomProtocolDeviceVersion -> {
                        FissionLogUtils.d(
                            "RtkGlassesCmdStrategy",
                            "DeviceVersion BLE=${event.bleVersion} WiFi=${event.wifiVersion}",
                        )
                        emitEvent(
                            CmdResultEvent.DeviceVersionInfoEvent(
                                DeviceVersionInfoDTO(
                                    firmwareVersion = event.bleVersion,
                                    wifiVersion = event.wifiVersion,
                                    hardwareVersion = ""
                                )
                            )
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolDeviceStatus -> {
                        if (event.batteryLevel != null || event.charging != null) {
                            emitEvent(CmdResultEvent.DevicePower(event.batteryLevel, event.charging))
                        }
                        emitEvent(
                            CmdResultEvent.DeviceSettingsStateEvent(
                                DeviceSettingsStateDTO(
                                    ledBrightness = event.ledBrightness?.let { rtkCustomBrightnessToLy(it) },
                                    recordDuration = event.recordDuration,
                                    audioRecordDuration = event.audioRecordDuration,
                                    wearDetectionEnabled = event.wearDetectionEnabled?.let {
                                        if (it) GlassesConstant.WearDetectionState.ON
                                        else GlassesConstant.WearDetectionState.OFF
                                    },
                                    voiceCommandEnabled = event.voiceWakeupEnabled,
                                    orientation = event.shootingDirection?.let { rtkShootingDirectionToLy(it) }
                                )
                            )
                        )
                        emitRealtimeActionSync(
                            wearingStatus = event.wearingStatus,
                            photoStatus = event.photoStatus,
                            audioStatus = event.audioRecordingStatus,
                            videoStatus = event.videoRecordingStatus
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolChargingStatus -> {
                        emitEvent(
                            CmdResultEvent.DevicePower(
                                event.batteryLevel,
                                event.isCharging,
                            )
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolLedBrightness -> {
                        // 0x0808 仅携带 LED 亮度，不能当成完整设备设置快照回抛，
                        // 否则上层会用一个“只有亮度”的 DTO 覆盖掉录像时长等其他设置项。
                        rtkCustomBrightnessToLy(event.brightness)?.let { level ->
                            FissionLogUtils.d(
                                TAG,
                                "Ignore partial LED settings snapshot, brightness=$level",
                            )
                        }
                    }

                    is RtkSdkShareEvent.CustomProtocolTouchpadGesture -> {
                        rtkTouchpadGestureToActionSync(event.gestureType, event.action)?.let { (type, state) ->
                            emitEvent(CmdResultEvent.ActionSync(type, state))
                        }
                    }

                    is RtkSdkShareEvent.CustomProtocolWearingStatus -> {
                        emitMappedActionSync(
                            ActionSyncType.WEAR,
                            event.status,
                            ::rtkWearingStatusToActionSyncActive,
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolPhotoStatus -> {
                        event.reason?.let { reason ->
                            FissionLogUtils.d(
                                TAG,
                                "event=0x0813 payload status=${event.status} reason=$reason",
                            )
                        }
                        emitMappedActionSync(
                            ActionSyncType.TAKE_PHOTO,
                            event.status,
                            ::rtkPhotoStatusToActionSyncActive,
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolAudioRecordingStatus -> {
                        event.reason?.let { reason ->
                            FissionLogUtils.d(
                                TAG,
                                "event=0x0814 payload status=${event.status} reason=$reason",
                            )
                        }
                        emitMappedActionSync(
                            ActionSyncType.RECORD_AUDIO,
                            event.status,
                            ::rtkRecordingStatusToActionSyncActive,
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolVideoRecordingStatus -> {
                        event.reason?.let { reason ->
                            FissionLogUtils.d(
                                TAG,
                                "event=0x0815 payload status=${event.status} reason=$reason",
                            )
                        }
                        emitMappedActionSync(
                            ActionSyncType.RECORD_VIDEO,
                            event.status,
                            ::rtkRecordingStatusToActionSyncActive,
                        )
                    }

                    is RtkSdkShareEvent.CustomProtocolCommandResult -> {
                        if (event.success) {
                            emitEvent(CmdResultEvent.Success())
                        } else {
                            emitEvent(
                                CmdResultEvent.Fail(
                                    "Custom protocol failed: cmd=0x${event.commandId.toString(16)}",
                                    event.errorCode
                                )
                            )
                        }
                    }

                    else                                            -> {}
                }
            }
        }

        aiAssistantBridgeJob = scope.launch {
            AiAssistantClient.getInstance().aiAgentEventFlow().collect { event ->
                when (event) {
                    is AiAssistantEvent.AiImageRecognition -> {
                        AiAssistantClient.getInstance().startAiImageRecognition(event.data)
                        takePicture(true)
                    }

                    // 仅全部 TTS 段播放完成后才会收到；MCP 识图多段时第一段结束不会停麦
                    AiAssistantEvent.AgentAudioPlaybackFinished -> {
                        if (AiAssistantClient.getInstance().isAwaitingMcpImageRecognitionFollowUp()) {
                            FissionLogUtils.i(TAG, "MCP 识图跟进中，暂不关闭 AI 录音")
                            return@collect
                        }
                        stopVadAudio()
                    }

                    is AgentEvent.AiAssistantConnectState -> {
                        if (event.state == GlassesConstant.WS_CONNECTION_STATE_DISCONNECTED &&
                            GlassesManage.currentConnectionState().bleState == SdkBleConnectionState.CONNECTED &&
                            isAiRecording
                        ) {
                            if (AiAssistantClient.getInstance().isListenBlockedByWsReconnect()) {
                                FissionLogUtils.d(TAG, "WS 重建中，忽略 DISCONNECTED 停麦")
                                return@collect
                            }
                            isAiRecording = false
                            stopVadAudio()
                        }
                    }

                    else -> Unit
                }
            }
        }
    }

    private fun emitDisconnected() {
        isAiRecording = false
        lastActionSyncStates.clear()
        mediaImportStateSimulator.reset()
        AiAssistantClient.getInstance().cancelWifiExclusiveSession()
        emitEvent(Disconnected)
    }

    /** 媒体同步 / OTA / 直播等 Wi-Fi 独占流程结束后恢复 AI WebSocket。 */
    private fun endAssistantAfterWifiExclusiveSession() {
        AiAssistantClient.getInstance().endWifiExclusiveSession()
    }

    private fun emitEvent(event: GlassesEvent) {
        scope.launch {
            eventBus.emit(event)
        }
    }

    private fun emitActionSyncIfChanged(type: ActionSyncType, active: Boolean) {
        if (lastActionSyncStates[type] == active) return
        lastActionSyncStates[type] = active
        FissionLogUtils.d(TAG, "ActionSync type=$type active=$active")
        val actionEvent = CmdResultEvent.ActionSync(type, active)
        if (!eventBus.tryEmit(actionEvent)) {
            scope.launch { eventBus.emit(actionEvent) }
        }
    }

    private fun emitMappedActionSync(
        type: ActionSyncType,
        status: Int,
        mapper: (Int) -> Boolean?,
    ) {
        val active = mapper(status) ?: return
        emitActionSyncIfChanged(type, active)
    }

    private fun emitRealtimeActionSync(
        wearingStatus: Int? = null,
        photoStatus: Int? = null,
        audioStatus: Int? = null,
        videoStatus: Int? = null
    ) {
        wearingStatus?.let {
            emitMappedActionSync(ActionSyncType.WEAR, it, ::rtkWearingStatusToActionSyncActive)
        }
        photoStatus?.let {
            emitMappedActionSync(ActionSyncType.TAKE_PHOTO, it, ::rtkPhotoStatusToActionSyncActive)
        }
        audioStatus?.let {
            emitMappedActionSync(ActionSyncType.RECORD_AUDIO, it, ::rtkRecordingStatusToActionSyncActive)
        }
        videoStatus?.let {
            emitMappedActionSync(ActionSyncType.RECORD_VIDEO, it, ::rtkRecordingStatusToActionSyncActive)
        }
    }


    override fun connect(params: Any) {
        if (params is BleComConfig) {
            mDeviceAddress = params.mac!!
            emitEvent(ConnectionStateEvent.Connecting)
            mRtkSdkManager.connectDevice(mDeviceAddress)
        }
    }

    override fun release() {
        aiAssistantBridgeJob?.cancel()
        aiAssistantBridgeJob = null
        mRtkSdkManager.release()
    }

    override fun disConnect(unpair: Boolean) {
        if (unpair) {
            unpairDeviceAsync()
        } else {
            mRtkSdkManager.disConnect()
        }
    }

    private fun unpairDeviceAsync() {
        BluetoothUnpairHelper.unpairAsync(
            context = context,
            deviceAddress = mDeviceAddress,
            disconnectSpp = { mRtkSdkManager.disConnect() },
            onComplete = { GlassesSpUtil.remove(GlassesSpUtil.KEY_MAC_ADDRESS) },
        )
    }

    override fun setVoiceDuration(times: Int) {
        mRtkSdkManager.setAudioRecordingDuration(times)
    }

    override fun setVideoDuration(times: Int) {
        mRtkSdkManager.setVideoDuration(times)
    }

    override fun rebootDevice() {
        mRtkSdkManager.rebootDevice()
    }

    override fun restoreFactorySettings() {
        mRtkSdkManager.restoreFactorySettings()
        unpairDeviceAsync()
    }

    override fun upVolume() {
        mRtkSdkManager.upVolume()
    }

    override fun downVolume() {
        mRtkSdkManager.downVolume()
    }

    override fun takePicture(takePhotoOnly: Boolean) {
       mRtkSdkManager.startTakePhotoProcess(takePhotoOnly)
    }

    override fun setLifePhotoConfig(config: LifePhotoConfig) {
        mRtkSdkManager.setLifePhotoConfig(config)
    }

    override fun setWifiApConfig(config: WifiApConfig) {
        mRtkSdkManager.setWifiApConfig(config)
    }

    override fun startVideoRecording() {
        mRtkSdkManager.startVideoRecording()
    }

    override fun stopVideoRecording() {
        mRtkSdkManager.stopVideoRecording()
    }

    private fun vendorVoiceChatListenMode(): String =
        GlassesConstant.AI_ASSISTANT_TYPE_LISTEN_MODE_AUTO

    private fun startReceivingAudio(mode: String, language: Int) {
        AiAssistantClient.getInstance().startListening(mode, language)
    }

    private fun sendReceivingAudioData(mode: String, byteArray: ByteArray) {
        AiAssistantClient.getInstance().sendAudio(mode, byteArray)
    }

    private fun stopReceivingAudio(mode: String) {
        AiAssistantClient.getInstance().stopListening(mode)
    }

    private fun cancelReceivingAudio() {
        AiAssistantClient.getInstance().abort()
    }

    override fun stopVadAudio() {
        mRtkSdkManager.stopUserVoiceInput()
    }

    override fun getBatteryLevel() {
        mRtkSdkManager.getBatteryLevel()
    }

    override fun startDeviceRecording() {
        mRtkSdkManager.startDeviceRecording()
    }

    override fun stopDeviceRecording() {
        mRtkSdkManager.stopDeviceRecording()
    }

    override fun deviceShutDown() {
        mRtkSdkManager.deviceShutDown()
    }

    override fun aiImageRecognitionTts(
        baseWsMessage: BaseWsMessage<McpData>
    ) {
        AiAssistantClient.getInstance().sendIotCommand(baseWsMessage)
    }

    override fun setTime() {
        FissionLogUtils.d(TAG,"Not supported for now: setTime")
    }

    override fun requestDeviceVersionInfo() {
        mRtkSdkManager.requestDeviceVersionInfo()
    }

    override fun setLedBrightness(level: GlassesConstant.LedBrightnessLevel) {
        mRtkSdkManager.setLedBrightness(level)
    }

    override fun setGestureShortcut(
        gesture: GlassesConstant.GestureType,
        action: GlassesConstant.GestureAction
    ) {
        FissionLogUtils.d(TAG,"Not supported for now：setGestureShortcut")
    }

    override fun setWearDetection(state: GlassesConstant.WearDetectionState) {
        mRtkSdkManager.setWearDetectionSwitch(state == GlassesConstant.WearDetectionState.ON)
    }

    override fun setScreenOrientation(orientation: GlassesConstant.ScreenOrientation) {
        mRtkSdkManager.setScreenOrientation(orientation)
    }

    override fun resetGestureShortcuts() {
        FissionLogUtils.d(TAG,"Not supported for now：resetGestureShortcuts")
    }

    override fun getDeviceSettingsState() {
        mRtkSdkManager.requestDeviceStatus()
    }

    override fun startOTA(filePath: String, otaType: GlassesConstant.OtaType, version: String) {
        FissionLogUtils.d(TAG,"Not supported for now：startOTA")
    }

    override fun startOTABoth(btPath: String?, btVersion: String?, wifiZipPath: String?) {
        scope.launch(Dispatchers.IO) {
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            mRtkSdkManager.startOtaBoth(btPath, btVersion, wifiZipPath)
        }
    }

    override fun startLiveStreaming(liveStreamingConfig: LiveStreamingConfig) {
        scope.launch(Dispatchers.IO) {
            if (isAiRecording) {
                isAiRecording = false
                mRtkSdkManager.stopUserVoiceInput()
            }
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            mRtkSdkManager.startLiveStreaming(liveStreamingConfig)
        }
    }

    override fun startPushLiveStreaming(liveUrl: String) {
        mRtkSdkManager.startPushLiveStreaming(liveUrl)
    }

    override fun stopLiveStreaming() {
        mRtkSdkManager.stopRtspStream()
        endAssistantAfterWifiExclusiveSession()
    }

    override fun setLivePreviewMicState(
        enableState: GlassesConstant.EnableState) {
        mRtkSdkManager.setLivePreviewMicState(enableState)
    }

    override fun setLivePreviewRotation(degrees: Int) {
        mRtkSdkManager.setLivePreviewRotation(degrees)
    }

    override fun getActionState() {
        mRtkSdkManager.requestDeviceStatus()
    }

    override fun setOfflineVoiceLanguage(language: GlassesConstant.OffLineLanguages) {
        FissionLogUtils.d(TAG,"Not supported for now：setOfflineVoiceLanguage")
    }

    override fun getDeviceStorage() {
        mRtkSdkManager.getDeviceCapacityInfo()
    }

    override fun controlMusic(enable: Boolean) {
        FissionLogUtils.d(TAG,"Not supported for now：controlMusic")
    }

    override fun switchMusic(action: GlassesConstant.MusicSwitchAction) {
        FissionLogUtils.d(TAG,"Not supported for now：switchMusic")
    }

    override fun getVoiceWakeUp() {
        mRtkSdkManager.getVoiceWakeupSwitch()
    }

    override fun setVoiceWakeUp(
        localOfflineEnabled: Boolean,
        opusPushEnabled: Boolean
    ) {
        // v0.2.0 协议仅支持单一语音唤醒开关，以本地离线唤醒为准
        mRtkSdkManager.setVoiceWakeupSwitch(opusPushEnabled)
    }

    override fun getGlassesVolume() {
    }

    override fun setGlassesVolume(
        type: GlassesConstant.AudioVolumeType,
        volume: Int) {
    }

    override fun getDeviceSupportedFeatures() {
        FissionLogUtils.d(TAG,"Not supported for now：getDeviceSupportedFeatures")
    }

    override fun answerPhoneCall() {
        FissionLogUtils.d(TAG,"Not supported for now：answerPhoneCall")
    }

    override fun hangUpPhoneCall() {
        FissionLogUtils.d(TAG,"Not supported for now：hangUpPhoneCall")
    }

    override fun reconnectBluetooth() {
//        val address = mDeviceAddress
//        if (address.isNullOrBlank()) {
//            FissionLogUtils.w("RtkGlassesCmdStrategy", "reconnectBluetooth skipped: no saved device address")
//            return
//        }
//        mRtkSdkManager.connectDevice(address, forceSmartWearReinit = true)
    }


    override fun getMediaFileCount() {
        mRtkSdkManager.getMediaFileCount() //onFileStorageInfoChanged返回
    }

    override fun syncAllMediaFile(wifiMode: GlassesConstant.WifiMode) {
        scope.launch(Dispatchers.IO) {
            AiAssistantClient.getInstance().beginWifiExclusiveSession()
            mediaImportStateSimulator.onMediaSyncStarted()
            mRtkSdkManager.syncMediaFile()
        }
    }


    override fun startAiAssistant() {
        mRtkSdkManager.startUserVoiceInput()
    }

    override fun stopAiAssistant() {
        mRtkSdkManager.stopUserVoiceInput()
    }

    override fun interruptAiAssistant() {
//        mRtkSdkManager.stopUserVoiceInput()
    }

}
