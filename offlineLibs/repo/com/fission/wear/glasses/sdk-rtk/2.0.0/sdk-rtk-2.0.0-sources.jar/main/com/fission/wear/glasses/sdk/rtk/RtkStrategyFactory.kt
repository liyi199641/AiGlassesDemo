package com.fission.wear.glasses.sdk.rtk

import com.fission.wear.glasses.sdk.RtkGlassesCmdStrategy
import com.fission.wear.glasses.sdk.config.SdkConfig
import com.fission.wear.glasses.sdk.constant.GlassesConstant.ChannelType
import com.fission.wear.glasses.sdk.events.GlassesCmdStrategy
import com.fission.wear.glasses.sdk.events.GlassesEvent
import com.fission.wear.glasses.sdk.strategy.AiUplinkProfile
import com.fission.wear.glasses.sdk.strategy.GlassesStrategyFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow

class RtkStrategyFactory : GlassesStrategyFactory {
    override val channel: ChannelType = ChannelType.RTK

    override val aiUplinkProfile: AiUplinkProfile = AiUplinkProfile(
        glassesUplinkFormat = "pcm",
        sampleRate = 16000,
        deviceChannel = 3,
    )

    override fun create(
        config: SdkConfig,
        eventFlow: MutableSharedFlow<GlassesEvent>,
        scope: CoroutineScope,
    ): GlassesCmdStrategy = RtkGlassesCmdStrategy(
        config.context.applicationContext,
        eventFlow,
        scope,
        config,
    )
}
