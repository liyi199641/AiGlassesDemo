package com.fission.wear.glasses.sdk.rtk.protocol

/**
 * Realtek custom vendor protocol command/event IDs (0x0800 ~ 0x08FF).
 * See: 瑞昱眼镜自定义协议说明 v0.3.0
 */
object CustomVendorProtocol {

    const val EVENT_CHARGING_STATUS_CHANGED = 0x0801
    const val CMD_GET_CHARGING_STATUS = 0x0802
    const val CMD_GET_DEVICE_VERSION = 0x0803
    const val EVENT_DEVICE_VERSION_REPORT = 0x0804
    const val CMD_REBOOT_DEVICE = 0x0805
    const val CMD_SET_LED_BRIGHTNESS = 0x0806
    const val CMD_GET_LED_BRIGHTNESS = 0x0807
    const val EVENT_LED_BRIGHTNESS_REPORT = 0x0808
    const val CMD_GET_DEVICE_STATUS = 0x0809
    const val EVENT_DEVICE_STATUS_REPORT = 0x080A
    const val EVENT_TOUCHPAD_GESTURE = 0x080B
    const val CMD_SET_SHOOTING_DIRECTION = 0x080C
    const val CMD_SET_VIDEO_RECORDING_DURATION = 0x080D
    const val CMD_SET_AUDIO_RECORDING_DURATION = 0x080E
    const val CMD_SET_VOICE_WAKEUP_SWITCH = 0x080F
    const val CMD_SET_WEARING_DETECTION_SWITCH = 0x0810
    const val CMD_FACTORY_RESET = 0x0811
    const val EVENT_WEARING_STATUS_CHANGED = 0x0812
    const val EVENT_PHOTO_STATUS_CHANGED = 0x0813
    const val EVENT_AUDIO_RECORDING_STATUS_CHANGED = 0x0814
    const val EVENT_VIDEO_RECORDING_STATUS_CHANGED = 0x0815
    const val CMD_SET_MIC_ENABLED_STATUS = 0x0818
    const val EVENT_LW_WIFI_AP_STATUS_CHANGED = 0x0819

    val PARAMS_EMPTY = ByteArray(0)

    fun isCustomCommand(commandId: Int): Boolean = commandId in 0x0800..0x08FF

    fun isCustomEvent(eventId: Int): Boolean =
        when (eventId) {
            EVENT_CHARGING_STATUS_CHANGED,
            EVENT_DEVICE_VERSION_REPORT,
            EVENT_LED_BRIGHTNESS_REPORT,
            EVENT_DEVICE_STATUS_REPORT,
            EVENT_TOUCHPAD_GESTURE,
            EVENT_WEARING_STATUS_CHANGED,
            EVENT_PHOTO_STATUS_CHANGED,
            EVENT_AUDIO_RECORDING_STATUS_CHANGED,
            EVENT_VIDEO_RECORDING_STATUS_CHANGED,
            EVENT_LW_WIFI_AP_STATUS_CHANGED -> true
            else -> false
        }

    fun eventToCommand(eventId: Int): Int =
        when (eventId) {
            EVENT_CHARGING_STATUS_CHANGED -> CMD_GET_CHARGING_STATUS
            EVENT_DEVICE_VERSION_REPORT -> CMD_GET_DEVICE_VERSION
            EVENT_LED_BRIGHTNESS_REPORT -> CMD_GET_LED_BRIGHTNESS
            EVENT_DEVICE_STATUS_REPORT -> CMD_GET_DEVICE_STATUS
            else -> -1
        }

    /** 查询类指令对应的上报 EVENT；设置类指令返回 -1（仅等 ACK）。 */
    fun commandToEvent(commandId: Int): Int =
        when (commandId) {
            CMD_GET_CHARGING_STATUS -> EVENT_CHARGING_STATUS_CHANGED
            CMD_GET_DEVICE_VERSION -> EVENT_DEVICE_VERSION_REPORT
            CMD_GET_LED_BRIGHTNESS -> EVENT_LED_BRIGHTNESS_REPORT
            CMD_GET_DEVICE_STATUS -> EVENT_DEVICE_STATUS_REPORT
            else -> -1
        }
}
