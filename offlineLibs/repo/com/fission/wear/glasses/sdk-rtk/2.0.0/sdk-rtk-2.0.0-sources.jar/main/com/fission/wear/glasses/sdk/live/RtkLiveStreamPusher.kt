package com.fission.wear.glasses.sdk.live

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.SessionState
import com.fission.wear.glasses.sdk.util.FissionLogUtils

/**
 * RTK 眼镜 RTSP → RTMP 转推（抖音等第三方直播平台）。
 * 依赖宿主 App 提供 ffmpeg-kit（compileOnly）。
 */
internal class RtkLiveStreamPusher {

    private var currentSession: FFmpegSession? = null

    fun start(
        rtspUrl: String,
        rtmpUrl: String,
        onFailed: ((String) -> Unit)? = null,
    ) {
        stop()
        val command = buildString {
            append("-rtsp_transport tcp ")
            append("-i ").append(rtspUrl.quoteForFFmpeg()).append(' ')
            append("-c:v copy ")
            append("-an ")
            append("-f flv ")
            append(rtmpUrl.quoteForFFmpeg())
        }
        FissionLogUtils.d(TAG, "FFmpeg push: $command")
        currentSession = FFmpegKit.executeAsync(command) { session ->
            val returnCode = session.returnCode
            when {
                ReturnCode.isSuccess(returnCode) -> FissionLogUtils.d(TAG, "FFmpeg push finished")
                ReturnCode.isCancel(returnCode) -> FissionLogUtils.d(TAG, "FFmpeg push cancelled")
                else -> {
                    val detail = session.failStackTrace?.takeIf { it.isNotBlank() }
                        ?: session.output?.takeIf { it.isNotBlank() }
                        ?: returnCode.toString()
                    FissionLogUtils.e(TAG, "FFmpeg push failed: $detail")
                    onFailed?.invoke(detail)
                }
            }
        }
    }

    fun stop() {
        currentSession?.let { session ->
            if (session.state == SessionState.RUNNING || session.state == SessionState.CREATED) {
                session.cancel()
            }
        }
        currentSession = null
    }

    private fun String.quoteForFFmpeg(): String = "'${replace("'", "'\\''")}'"

    companion object {
        private const val TAG = "RtkLiveStreamPusher"
    }
}
