package com.fission.wear.glasses.sdk.util

import com.fission.wear.glasses.sdk.data.model.MediaDownloadProgressInfo
import com.fission.wear.glasses.sdk.model.RtkMediaExportResult

/**
 * RTK 媒体同步专用回调。
 * 下载与后处理可流水线并行；[onFileExported] 单项处理完成后触发，上层此时才展示。
 */
interface RtkMediaSyncCallback {

    fun onConnectSuccess()

    fun onDownloadPrepared(totalFileCount: Int, progressInfo: MediaDownloadProgressInfo)

    fun onDownloadProgress(progressInfo: MediaDownloadProgressInfo)

    fun onFileExported(result: RtkMediaExportResult, totalFileCount: Int)

    /** Wi‑Fi 在同步过程中断开（[RtkWifiAdapter] onWifiConnectionStateChanged false）。 */
    fun onWifiDisconnectedDuringSync()

    fun onSyncFailed(code: Int, reason: String)

    fun onSyncFinished(successCount: Int, totalFileCount: Int)
}
