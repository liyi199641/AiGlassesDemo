package com.fission.wear.glasses.sdk.util

import android.content.Context
import android.graphics.BitmapFactory
import com.realsil.sdk.audioconnect.smartwear.image.ImageCorrectConfig
import com.realsil.sdk.audioconnect.smartwear.image.RTKImageToolkit
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.io.FileOutputStream

/**
 * RTK 同步图片畸变校正（对齐原厂 [ImageCorrectProcessor] 实现）。
 *
 * 关键点：
 * 1. 使用原厂 Demo 的 4032×3024 镜头标定参数
 * 2. 使用 [RTKImageToolkit.imageCorrect]（suspend）而非 imageCorrectAsync，避免与 Wi‑Fi 下载争用 SDK 内部异步通道
 * 3. 开启 Standard 降噪模型
 */
object RtkImageCorrector {

    private const val TAG = "RtkImageCorrector"
    /** Standard 效果最好（约 120s）；Lite 约 30s；Tiny 近无感。优先 Standard。 */
    const val DENOISE_MODEL_ASSET = "denoise_standard_v4.bin"
    const val DENOISE_MODEL_CACHE_DIR = "ImageModel"

    /** RTK 原厂 ImageCorrectProcessor DEFAULT_CORRECTION_PARAMS（始终下发，无分辨率分支）。 */
    private const val CALIBRATED_FX = 2067.8193
    private const val CALIBRATED_FY = 2062.6142
    private const val CALIBRATED_CX = 2003.5674
    private const val CALIBRATED_CY = 1546.6035
    private const val CALIBRATED_K0 = 0.21387498
    private const val CALIBRATED_K1 = 0.75066905
    private const val CALIBRATED_K2 = -0.56982254
    private const val CALIBRATED_K3 = -0.29913265
    private const val CALIBRATED_OUTPUT_SCALE = 1.0f

    @Volatile
    private var denoiseModelPath: String = ""

    /**
     * 在 IO 线程调用：从 assets 拷贝降噪模型。
     */
    fun prepareDefaultConfig(context: Context) {
        synchronized(this) {
            if (denoiseModelPath.isNotEmpty() && File(denoiseModelPath).exists()) {
                return
            }
            denoiseModelPath = copyAssetsFileToSdcard(
                context,
                DENOISE_MODEL_ASSET,
                DENOISE_MODEL_CACHE_DIR,
            )
            FissionLogUtils.dTag(TAG, "denoise model prepared, path=$denoiseModelPath")
        }
    }

    fun isPrepared(): Boolean = denoiseModelPath.isNotEmpty() && File(denoiseModelPath).exists()

    /**
     * 与原厂 ImageCorrectProcessor.processImage 一致：无条件写入 DEFAULT_CORRECTION_PARAMS。
     */
    private fun buildConfig(inputPath: String): ImageCorrectConfig {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(inputPath, options)
        val enableDenoise = denoiseModelPath.isNotEmpty() && File(denoiseModelPath).exists()
        if (!enableDenoise) {
            FissionLogUtils.wTag(TAG, "denoise model not ready, correction without denoise")
        }
        FissionLogUtils.dTag(
            TAG,
            "ImageCorrectProcessor config ${options.outWidth}x${options.outHeight} denoise=$enableDenoise",
        )
        return ImageCorrectConfig.Builder()
            .setEnableDenoise(enableDenoise)
            .setDenoiseModelPath(denoiseModelPath)
            .setFx(CALIBRATED_FX)
            .setFy(CALIBRATED_FY)
            .setCx(CALIBRATED_CX)
            .setCy(CALIBRATED_CY)
            .setK0(CALIBRATED_K0)
            .setK1(CALIBRATED_K1)
            .setK2(CALIBRATED_K2)
            .setK3(CALIBRATED_K3)
            .setOutputScale(CALIBRATED_OUTPUT_SCALE)
            .build()
    }

    private fun copyAssetsFileToSdcard(
        context: Context,
        assetsFileName: String,
        sdcardDirName: String
    ): String {
        val cacheDir = context.externalCacheDir ?: return ""
        val targetDir = File(cacheDir, sdcardDirName)

        if (!targetDir.exists()) {
            targetDir.mkdirs()
        }

        val outFile = File(targetDir, assetsFileName)
        if (outFile.exists()) {
            return outFile.absolutePath
        }

        return try {
            context.assets.open(assetsFileName).use { inputStream ->
                FileOutputStream(outFile).use { outputStream ->
                    val buffer = ByteArray(4096)
                    var len: Int
                    while (inputStream.read(buffer).also { len = it } != -1) {
                        outputStream.write(buffer, 0, len)
                    }
                    outputStream.flush()
                }
            }
            outFile.absolutePath
        } catch (e: Exception) {
            FissionLogUtils.wTag(TAG, "copyAssetsFileToSdcard failed: $assetsFileName, ${e.message}")
            ""
        }
    }

    /**
     * 协程封装 [RTKImageToolkit.imageCorrect]；在专用导出线程调用，不与 SmartWearWifiClient 共用 SDK 异步回调通道。
     */
    suspend fun correctImageAsync(
        context: Context,
        inputPath: String,
        outputPath: String? = null,
    ): String? {
        prepareDefaultConfig(context.applicationContext)
        val config = buildConfig(inputPath)
        return try {
            val resultPath = invokeImageCorrect(
                context.applicationContext,
                inputPath,
                config,
            )
            resolveOutput(resultPath, inputPath, outputPath)
        } catch (e: Exception) {
            FissionLogUtils.wTag(TAG, "imageCorrect failed for $inputPath: ${e.message}")
            null
        }
    }

    /**
     * vendor smartwear 的 imageCorrect 在 Kotlin 侧未暴露为 suspend，需手动传入 Continuation。
     */
    private suspend fun invokeImageCorrect(
        context: Context,
        inputPath: String,
        config: ImageCorrectConfig,
    ): String? = suspendCancellableCoroutine { cont ->
        RTKImageToolkit.imageCorrect(context, inputPath, config, cont)
    }

    private fun resolveOutput(
        toolkitResult: String?,
        inputPath: String,
        desiredOutputPath: String?,
    ): String? {
        val source = toolkitResult
            ?.takeIf { it.isNotBlank() }
            ?.let { File(it) }
            ?.takeIf { it.exists() }
            ?: return null

        if (desiredOutputPath.isNullOrBlank()) {
            return source.absolutePath
        }
        val target = File(desiredOutputPath)
        target.parentFile?.mkdirs()
        return try {
            if (source.absolutePath != target.absolutePath) {
                source.copyTo(target, overwrite = true)
            }
            target.absolutePath.takeIf { target.exists() }
        } catch (e: Exception) {
            FissionLogUtils.wTag(TAG, "copy corrected result failed: ${e.message}")
            source.absolutePath
        }
    }

    /**
     * 对同步下来的 JPG 做畸变校正；失败时返回原路径，不中断同步流程。
     */
    fun correctSyncedJpegBlocking(
        context: Context,
        inputPath: String,
        outputPath: String? = null,
    ): String {
        if (!inputPath.endsWith(".jpg", ignoreCase = true) &&
            !inputPath.endsWith(".jpeg", ignoreCase = true)
        ) {
            return inputPath
        }
        val inputFile = File(inputPath)
        if (!inputFile.exists()) {
            return inputPath
        }
        prepareDefaultConfig(context.applicationContext)
        if (!isPrepared()) {
            FissionLogUtils.wTag(TAG, "denoise model not ready, still try undistort for $inputPath")
        }
        return try {
            val correctedPath = runBlocking {
                correctImageAsync(context, inputPath, outputPath)
            }
            val resolved = correctedPath
                ?.takeIf { it.isNotBlank() && File(it).exists() }
                ?: inputPath
            if (resolved != inputPath) {
                FissionLogUtils.dTag(TAG, "image corrected: $inputPath -> $resolved")
            } else {
                FissionLogUtils.wTag(TAG, "image correct returned input path for $inputPath")
            }
            resolved
        } catch (e: Exception) {
            FissionLogUtils.wTag(TAG, "imageCorrect failed for $inputPath: ${e.message}")
            inputPath
        }
    }
}
