package com.fission.wear.glasses.sdk.rtk

import android.content.Context
import com.realsil.sdk.audioconnect.smartwear.SmartWearWifiClient
import com.realsil.sdk.audioconnect.smartwear.WifiClientConfigure
import com.realtek.sdk.core.net.wifi.WifiConfigurationInfo
import com.realtek.sdk.core.net.wifi.WifiConnectParameter

/**
 * 对齐官方 Demo：OTA / 媒体同步 / 直播各自使用独立的 [SmartWearWifiClient] 与 Wi‑Fi 连接会话，
 * 避免 ping-pong、推包、下载共用同一 client 产生状态串扰。
 */
internal object RtkSmartWearWifiClientFactory {

    fun create(context: Context, ipAddress: String): SmartWearWifiClient {
        return SmartWearWifiClient(context).also { client ->
            client.updateConfigure(
                WifiClientConfigure(
                    SmartWearWifiClient.SCHEME_HTTPS,
                    ipAddress,
                    true,
                    WifiClientConfigure.PROTOCOL_TLS_1_2,
                ),
            )
        }
    }
}

/** 单次 Wi‑Fi 连接流程（connect + ping-pong）的会话状态，按功能隔离。 */
internal class RtkWifiConnectSession(
    val featureTag: String,
    val pingClient: SmartWearWifiClient,
) {
    var oldWifiConfiguration: WifiConfigurationInfo? = null
    var wifiConnectParameter: WifiConnectParameter = WifiConnectParameter()
}

internal object RtkWifiFeatureTags {
    const val SYNC = "sync"
    const val OTA = "ota"
    const val LIVE = "live"
}
