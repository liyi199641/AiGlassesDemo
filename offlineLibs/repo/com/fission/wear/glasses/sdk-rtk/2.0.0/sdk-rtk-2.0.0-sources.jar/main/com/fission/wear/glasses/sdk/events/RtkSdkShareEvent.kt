package com.fission.wear.glasses.sdk.events

import android.bluetooth.BluetoothDevice
import com.fission.wear.glasses.sdk.constant.GlassesConstant
import com.fission.wear.glasses.sdk.data.dto.DeviceCapacityInfoDTO
import com.realsil.sdk.audioconnect.smartwear.ActionStateNotification
import com.realsil.sdk.audioconnect.smartwear.FileStorageInfo
import com.realsil.sdk.audioconnect.smartwear.WifiApInfo
import com.realsil.sdk.audioconnect.smartwear.WifiStaInfo
import com.realsil.sdk.audioconnect.smartwear.entity.ThumbnailPhoto
import com.realsil.sdk.audioconnect.smartwear.entity.WifiAccessInfo

sealed class RtkSdkShareEvent {
    data object Connecting : RtkSdkShareEvent()
    data class Connected(val device: BluetoothDevice?,val isOtaMode: Boolean) : RtkSdkShareEvent()
    data object Disconnected : RtkSdkShareEvent()

    data object OnSmartWearDeviceInitSuccess : RtkSdkShareEvent()
    data object OnSmartWearDeviceInitFail : RtkSdkShareEvent()
    data class OnFileStorageInfoChanged(val fileStorageInfo: FileStorageInfo) :RtkSdkShareEvent()
    data class OnDeviceCapacityInfo(val data: DeviceCapacityInfoDTO) : RtkSdkShareEvent()
    data class OnWifiApStateChanged(val wifiApInfo: WifiApInfo):RtkSdkShareEvent()
    data class OnWifiStaStateChanged(val wifiStaInfo: WifiStaInfo):RtkSdkShareEvent()
    data class OnReceivedUserVoice(val voiceData: ByteArray):RtkSdkShareEvent()
    data object OnStartReceiveUserVoice: RtkSdkShareEvent()
    data object OnStopReceiveUserVoice: RtkSdkShareEvent()
    data class OnTakePhotoSuccess(val imgFiles: MutableList<ThumbnailPhoto>):RtkSdkShareEvent()
    data object OnDeviceTriggeredTakePhoto:RtkSdkShareEvent()
    data class OnTakePhotoFail(val errorCode: Int):RtkSdkShareEvent()
    /** 高清拍照参数配置结果（对应 SmartWear `onUpdateWifiInfo` / 媒体配置 ACK）。 */
    data class OnLifePhotoConfigResult(val success: Boolean) : RtkSdkShareEvent()
    /** SoftAP 名称/密码配置结果（同样走 `onUpdateWifiInfo`）。 */
    data class OnWifiApConfigResult(val success: Boolean) : RtkSdkShareEvent()
    data class OnStartLiveStreaming(val liveChannel: Byte, val startResult: Boolean, val wifiAccessInfo: WifiAccessInfo?):RtkSdkShareEvent()
    data class OnReceivedLiveStreamingData(val liveData: ByteArray):RtkSdkShareEvent()
    data class OnActionStateNotificationChanged(val p0: ActionStateNotification):RtkSdkShareEvent()
    data class OnStateChanged(val p0: Int) : RtkSdkShareEvent()

    data class OnSyncFileFail(val code: Int, val msg: String) : RtkSdkShareEvent()
    data object OnSyncConnectSuccess : RtkSdkShareEvent()
    data class OnSyncFileProgress(val progress: Int, val curFileIndex: Int,val totalFileCount:Int,val speed:String) : RtkSdkShareEvent()
    data class OnSyncFileSuccess(val filePath: String,
                                 val curFileIndex: Int,
                                 val totalFileCount: Int,
                                 val remoteUrl: String,
                                 val fileSizeInBytes: Long,
                                 val fileModifiedTime: String) : RtkSdkShareEvent()
    /** 整批媒体下载结束；[successCount] 为实际成功数，与 LY [FileSyncEvent.BatchDownloadFinished] 对齐。 */
    data class OnSyncBatchDownloadFinished(
        val successCount: Int,
        val totalFileCount: Int,
    ) : RtkSdkShareEvent()

    data class RespSuccess(val rtsp: String) : RtkSdkShareEvent()
    data object RespStop : RtkSdkShareEvent()
    /** 通知栏关闭 RTKMediaPlayerService 前台服务。 */
    data object LiveStoppedByNotification : RtkSdkShareEvent()
    data class RespFailed(val reason: String, val code: Int = 0) : RtkSdkShareEvent()
    data class LiveDisconnected(val reason: String, val code: Int = 0) : RtkSdkShareEvent()
    data object PreviewStarted : RtkSdkShareEvent()
    data class PreviewFailed(val reason: String, val code: Int = 0) : RtkSdkShareEvent()
    data class DevicePower(val value: Int?, val isCharging: Boolean?) : RtkSdkShareEvent()

    /** RTK custom vendor protocol (0x0800~0x08FF) v0.3.0 */
    data class CustomProtocolDeviceVersion(
        val bleVersion: String,
        val wifiVersion: String
    ) : RtkSdkShareEvent()

    data class CustomProtocolDeviceStatus(
        val charging: Boolean?,
        val batteryLevel: Int?,
        val voiceWakeupEnabled: Boolean?,
        val ledBrightness: Int?,
        val recordDuration: Int?,
        val audioRecordDuration: Int?,
        val shootingDirection: Int?,
        val wearDetectionEnabled: Boolean?,
        val wearingStatus: Int? = null,
        val photoStatus: Int? = null,
        val audioRecordingStatus: Int? = null,
        val videoRecordingStatus: Int? = null
    ) : RtkSdkShareEvent()

    data class CustomProtocolWearingStatus(val status: Int) : RtkSdkShareEvent()

    data class CustomProtocolPhotoStatus(
        val status: Int,
        val reason: Int?
    ) : RtkSdkShareEvent()

    data class CustomProtocolAudioRecordingStatus(
        val status: Int,
        val reason: Int?
    ) : RtkSdkShareEvent()

    data class CustomProtocolVideoRecordingStatus(
        val status: Int,
        val reason: Int?
    ) : RtkSdkShareEvent()

    data class CustomProtocolLedBrightness(val brightness: Int) : RtkSdkShareEvent()

    data class CustomProtocolChargingStatus(
        val isCharging: Boolean,
        val batteryLevel: Int?,
    ) : RtkSdkShareEvent()

    data class CustomProtocolTouchpadGesture(
        val gestureType: Int,
        val action: Int,
        val summary: String
    ) : RtkSdkShareEvent()

    /** WiFi 热点状态上报（0x0819）：true=开启，false=关闭 */
    data class CustomProtocolWifiApStatusChanged(val enabled: Boolean) : RtkSdkShareEvent()

    data class CustomProtocolCommandResult(
        val commandId: Int,
        val success: Boolean,
        val errorCode: Int = 0
    ) : RtkSdkShareEvent()

    data object OtaIdle : RtkSdkShareEvent()
    data object OtaStart : RtkSdkShareEvent()
    data class OtaEnterOTAMode(val macAddress: String) : RtkSdkShareEvent()
    data class OtaProgress(val percent: Int, val type: GlassesConstant.OTAStage) : RtkSdkShareEvent()
    data object OtaSuccess : RtkSdkShareEvent()
    data class OtaFailed(val reason: String, val code: Int = 0) : RtkSdkShareEvent()
    data object OtaCancelled : RtkSdkShareEvent()
    data class OtaDeviceRebooting(val remainSec: Int) : RtkSdkShareEvent()
}
