package com.fission.wear.glasses.sdk.rtk

/**
 * RTK 眼镜 WiFi 同步媒体列表中，音频与视频均为 `.mp4` 容器，需通过文件名前缀区分。
 *
 * 示例：
 * - `AUDIO_0_0_20260803_184039_8.mp4`
 * - `VIDEO_0_0_20260803_184245_9.mp4`
 */
object RtkSyncedMediaClassifier {

    enum class SyncedMediaKind {
        IMAGE,
        VIDEO,
        AUDIO,
        UNKNOWN,
    }

    fun classify(fileName: String): SyncedMediaKind {
        val normalized = fileName.substringAfterLast('/').substringBeforeLast('.')
        val typePrefix = normalized.substringBefore('_').uppercase()
        return when (typePrefix) {
            "AUDIO" -> SyncedMediaKind.AUDIO
            "VIDEO" -> SyncedMediaKind.VIDEO
            else -> when (fileName.substringAfterLast('.').lowercase()) {
                "jpg", "jpeg" -> SyncedMediaKind.IMAGE
                "mp4", "mov" -> SyncedMediaKind.VIDEO
                else -> SyncedMediaKind.UNKNOWN
            }
        }
    }

    fun isAudio(fileName: String): Boolean = classify(fileName) == SyncedMediaKind.AUDIO

    fun isVideo(fileName: String): Boolean = classify(fileName) == SyncedMediaKind.VIDEO
}
