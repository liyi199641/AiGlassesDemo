package com.fission.wear.glasses.sdk.rtk.protocol

import com.fission.wear.glasses.sdk.events.RtkSdkShareEvent
import com.fission.wear.glasses.sdk.util.FissionLogUtils

internal object RtkCustomProtocolDispatcher {

    fun dispatchEvent(
        eventId: Int,
        payload: ByteArray?,
        emit: (RtkSdkShareEvent) -> Unit,
    ) {
        when (eventId) {
            CustomVendorProtocol.EVENT_CHARGING_STATUS_CHANGED -> {
                val info = RtkCustomProtocolParser.parseChargingStatus(payload) ?: return
                emit(
                    RtkSdkShareEvent.CustomProtocolChargingStatus(
                        isCharging = info.isCharging,
                        batteryLevel = info.batteryLevel.takeIf { it in 0..100 },
                    ),
                )
            }

            CustomVendorProtocol.EVENT_DEVICE_VERSION_REPORT -> {
                val version = RtkCustomProtocolParser.parseDeviceVersionReport(payload)
                if (version == null) {
                    FissionLogUtils.w(
                        "RtkCustomProtocol",
                        "0x0804 parse failed hex=${RtkCustomProtocolParser.bytesToHex(payload)}",
                    )
                    return
                }
                emit(
                    RtkSdkShareEvent.CustomProtocolDeviceVersion(
                        bleVersion = version.bleVersion,
                        wifiVersion = version.wifiVersion,
                    ),
                )
            }

            CustomVendorProtocol.EVENT_DEVICE_STATUS_REPORT -> {
                val status = RtkCustomProtocolParser.parseDeviceStatusPayload(payload) ?: return
                emit(
                    RtkSdkShareEvent.CustomProtocolDeviceStatus(
                        charging = rtkCustomSwitchToBoolean(status.charging),
                        batteryLevel = status.battery.takeIf { it in 0..100 },
                        voiceWakeupEnabled = rtkCustomSwitchToBoolean(status.voiceWakeup),
                        ledBrightness = status.led,
                        recordDuration = status.videoRecordingDuration.takeIf { it >= 0 && it != 0xFFFF },
                        audioRecordDuration = status.audioRecordingDuration.takeIf { it >= 0 && it != 0xFFFF },
                        shootingDirection = status.shootingDirection,
                        wearDetectionEnabled = rtkCustomSwitchToBoolean(status.wearingReminder),
                        wearingStatus = status.wearingStatus,
                        photoStatus = status.photoStatus,
                        audioRecordingStatus = status.audioRecordingStatus,
                        videoRecordingStatus = status.videoRecordingStatus,
                    ),
                )
            }

            CustomVendorProtocol.EVENT_LED_BRIGHTNESS_REPORT -> {
                val brightness = RtkCustomProtocolParser.parseLedBrightnessValue(payload) ?: return
                emit(RtkSdkShareEvent.CustomProtocolLedBrightness(brightness))
            }

            CustomVendorProtocol.EVENT_WEARING_STATUS_CHANGED -> {
                val status = RtkCustomProtocolParser.parseWearingStatus(payload) ?: return
                emit(RtkSdkShareEvent.CustomProtocolWearingStatus(status))
            }

            CustomVendorProtocol.EVENT_PHOTO_STATUS_CHANGED -> {
                val media = RtkCustomProtocolParser.parseMediaStatus(payload) ?: return
                emit(RtkSdkShareEvent.CustomProtocolPhotoStatus(media.status, media.reason.takeIf { it >= 0 }))
            }

            CustomVendorProtocol.EVENT_AUDIO_RECORDING_STATUS_CHANGED -> {
                val media = RtkCustomProtocolParser.parseMediaStatus(payload) ?: return
                emit(
                    RtkSdkShareEvent.CustomProtocolAudioRecordingStatus(
                        media.status,
                        media.reason.takeIf { it >= 0 },
                    ),
                )
            }

            CustomVendorProtocol.EVENT_VIDEO_RECORDING_STATUS_CHANGED -> {
                val media = RtkCustomProtocolParser.parseMediaStatus(payload) ?: return
                emit(
                    RtkSdkShareEvent.CustomProtocolVideoRecordingStatus(
                        media.status,
                        media.reason.takeIf { it >= 0 },
                    ),
                )
            }

            CustomVendorProtocol.EVENT_TOUCHPAD_GESTURE -> {
                val gesture = RtkCustomProtocolParser.parseTouchpadGesture(payload) ?: return
                emit(
                    RtkSdkShareEvent.CustomProtocolTouchpadGesture(
                        gestureType = gesture.gestureType,
                        action = gesture.action,
                        summary = RtkCustomProtocolParser.buildEventSummary(eventId, payload),
                    ),
                )
            }

            CustomVendorProtocol.EVENT_LW_WIFI_AP_STATUS_CHANGED -> {
                val enabled = RtkCustomProtocolParser.parseWifiApStatus(payload) ?: return
                emit(RtkSdkShareEvent.CustomProtocolWifiApStatusChanged(enabled))
            }
        }
    }
}
